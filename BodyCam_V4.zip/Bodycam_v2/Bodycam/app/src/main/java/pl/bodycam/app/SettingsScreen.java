package pl.bodycam.app;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

final class SettingsScreen extends Screen {

    private LinearLayout col;

    SettingsScreen(MainActivity a) {
        super(a);
    }

    @Override
    View view() {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(Ui.BG);
        col = Ui.col(a);
        col.setPadding(Ui.dp(20), Ui.dp(24), Ui.dp(20), Ui.dp(40));
        sv.addView(col);
        TextView back = Ui.btn(a, "◄ WSTECZ");
        back.setOnClickListener(v -> a.home());
        col.addView(back, Ui.lp(-2, -2, 0));
        col.addView(Ui.gap(a, 14));
        col.addView(Ui.text(a, "USTAWIENIA", 22, Ui.TEXT, Ui.MONO));

        head("NAKŁADKA");
        choice("Styl", "style", 0, "BODY 3 (prawy róg)", "KLASYCZNY (REC)");
        edit("Linia z modelem i numerem urządzenia (puste = z pliku nakladka.txt)", "model", App.s("model", ""));
        label("Logo w rogu nakładki (PNG z przezroczystym tłem, najlepiej 256×256)");
        LinearLayout lr = Ui.row(a);
        TextView pick = Ui.btn(a, "WYBIERZ LOGO");
        pick.setOnClickListener(v -> a.pickImage(uri -> {
            try (java.io.InputStream in = a.getContentResolver().openInputStream(uri)) {
                android.graphics.Bitmap b = android.graphics.BitmapFactory.decodeStream(in);
                if (b == null) { a.toast("To nie jest obraz"); return; }
                float sc = Math.min(1f, 512f / Math.max(b.getWidth(), b.getHeight()));
                if (sc < 1f) b = android.graphics.Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * sc), Math.round(b.getHeight() * sc), true);
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(new java.io.File(a.getFilesDir(), "logo.png"))) {
                    b.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o);
                }
                Look.loadLogo(a);
                a.toast("Logo ustawione");
            } catch (Exception e) {
                a.toast("Nie udało się wczytać logo");
            }
        }));
        TextView reset = Ui.btn(a, "DOMYŚLNE");
        reset.setOnClickListener(v -> {
            //noinspection ResultOfMethodCallIgnored
            new java.io.File(a.getFilesDir(), "logo.png").delete();
            Look.loadLogo(a);
            a.toast("Przywrócono logo z aplikacji");
        });
        lr.addView(pick, Ui.lpm(0, -2, 1, 0, 0, 4, 0));
        lr.addView(reset, Ui.lpm(0, -2, 1, 4, 0, 0, 0));
        col.addView(lr);
        edit("Funkcjonariusz (styl klasyczny)", "name", App.name());
        edit("Znak wywoławczy", "callsign", App.callsign());
        edit("Jednostka", "unit", App.unit());
        toggle("Współrzędne GPS na nagraniu", "gps", false);

        head("OBRAZ");
        choice("Jakość nagrania", "quality", 0, "720p (płynniej)", "1080p");
        toggle("Rybie oko (jak GoPro)", "fisheye", true);
        slider("Siła rybiego oka", "fishk", 40);
        slider("Ile zieleni w trybie nocnym i noktowizji", "green", 40);

        head("DŹWIĘKI I PRZYCISKI");
        toggle("Głos: „Nagrywanie rozpoczęte / zakończone”", "voice", true);
        toggle("Dwa piknięcia co 2 minuty w trakcie nagrywania", "beep2", true);
        toggle("Tryb wyciszenia (bez dźwięków, tylko wibracje)", "mute", false);
        label("Głos komunikatów (polskie głosy w telefonie)");
        Sound snd = Sound.get(a);
        TextView vname = Ui.text(a, snd.currentVoice(), 13, Ui.TEXT, Ui.MONO);
        col.addView(vname);
        LinearLayout vr = Ui.row(a);
        TextView next = Ui.btn(a, "NASTĘPNY GŁOS");
        next.setOnClickListener(v -> {
            java.util.List<String> vs = snd.voices();
            if (vs.isEmpty()) { a.toast("Brak polskich głosów – zainstaluj w Ustawieniach telefonu › Zamiana tekstu na mowę"); return; }
            int i = vs.indexOf(snd.currentVoice());
            String nv = vs.get((i + 1) % vs.size());
            snd.setVoice(nv);
            vname.setText(nv);
        });
        TextView test = Ui.btn(a, "POSŁUCHAJ");
        test.setOnClickListener(v -> snd.say(Sound.START));
        vr.addView(next, Ui.lpm(0, -2, 1, 0, 6, 4, 0));
        vr.addView(test, Ui.lpm(0, -2, 1, 4, 6, 0, 0));
        col.addView(vr);
        toggle("Przyciski głośności: głośniej = start, przytrzymaj = czy nagrywa; ciszej = stop, przytrzymaj = wyciszenie", "volkeys", true);

        head("PODGLĄD NA ŻYWO");
        TextView code = Ui.text(a, "Twój kod: " + Link.pretty(App.code()), 18, Ui.ACC, Ui.MONO);
        col.addView(code);
        TextView nc = Ui.btn(a, "NOWY KOD (stary przestanie działać)");
        nc.setOnClickListener(v -> {
            App.put("code", Link.newCode());
            code.setText("Twój kod: " + Link.pretty(App.code()));
        });
        col.addView(nc, Ui.lpm(-1, -2, 0, 0, 8, 0, 0));
        choice("Jakość podglądu", "streamq", 1, "OSZCZĘDNA", "NORMALNA", "WYSOKA");
        choice("Serwer pośredniczący (obie strony muszą mieć ten sam)", "server", 0,
                "AUTO", "EMQX", "HIVEMQ", "MOSQUITTO", "WŁASNY");
        edit("Własny serwer MQTT (host:port, TLS na 8883)", "custom", App.custom());
        TextView note = Ui.text(a, "Obraz i dźwięk są szyfrowane kluczem z kodu – serwer tylko przekazuje dane i nie widzi treści. "
                + "Podgląd zużywa ok. 4–8 MB na minutę i działa tylko wtedy, gdy ktoś ogląda.", 12, Ui.DIM, Ui.COND);
        note.setPadding(0, Ui.dp(10), 0, 0);
        col.addView(note);
        return sv;
    }

    private void head(String s) {
        TextView t = Ui.text(a, s, 12, Ui.ACC, Ui.MONO);
        t.setLetterSpacing(0.1f);
        t.setPadding(0, Ui.dp(26), 0, Ui.dp(8));
        col.addView(t);
    }

    private void label(String s) {
        TextView t = Ui.text(a, s, 13, Ui.DIM, Ui.COND);
        t.setPadding(0, Ui.dp(10), 0, Ui.dp(4));
        col.addView(t);
    }

    private void edit(String lbl, String key, String val) {
        label(lbl);
        EditText e = new EditText(a);
        e.setText(val);
        e.setTextColor(Ui.TEXT);
        e.setTypeface(Ui.MONO);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setBackground(Ui.box(Ui.PANEL_SOLID, Ui.LINE, 6));
        e.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int c, int af) { }

            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) { }

            @Override
            public void afterTextChanged(Editable s) {
                App.put(key, s.toString());
            }
        });
        col.addView(e);
    }

    private void toggle(String lbl, String key, boolean def) {
        LinearLayout r = Ui.row(a);
        r.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
        TextView t = Ui.text(a, lbl, 14, Ui.TEXT, Ui.COND);
        r.addView(t, Ui.lp(0, -2, 1));
        TextView b = Ui.btn(a, "");
        Runnable upd = () -> {
            boolean on = App.b(key, def);
            b.setText(on ? "WŁ." : "WYŁ.");
            Ui.on(b, on);
        };
        upd.run();
        b.setOnClickListener(v -> {
            App.put(key, !App.b(key, def));
            upd.run();
        });
        r.addView(b, Ui.lp(Ui.dp(76), -2, 0));
        col.addView(r);
    }

    private void choice(String lbl, String key, int def, String... opts) {
        label(lbl);
        LinearLayout r = Ui.row(a);
        TextView[] bs = new TextView[opts.length];
        for (int i = 0; i < opts.length; i++) {
            final int v = i;
            TextView b = Ui.btn(a, opts[i]);
            b.setTextSize(opts.length > 3 ? 10 : 12);
            b.setPadding(Ui.dp(4), Ui.dp(10), Ui.dp(4), Ui.dp(10));
            bs[i] = b;
            b.setOnClickListener(x -> {
                App.put(key, v);
                for (int k = 0; k < bs.length; k++) Ui.on(bs[k], k == v);
            });
            r.addView(b, Ui.lpm(0, -2, 1, i == 0 ? 0 : 3, 0, 0, 0));
        }
        int cur = App.i(key, def);
        for (int k = 0; k < bs.length; k++) Ui.on(bs[k], k == cur);
        col.addView(r);
    }

    private void slider(String lbl, String key, int def) {
        label(lbl + ": " + App.i(key, def) + "%");
        TextView l = (TextView) col.getChildAt(col.getChildCount() - 1);
        SeekBar s = new SeekBar(a);
        s.setMax(100);
        s.setProgress(App.i(key, def));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean u) {
                App.put(key, p);
                l.setText(lbl + ": " + p + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) { }

            @Override
            public void onStopTrackingTouch(SeekBar sb) { }
        });
        col.addView(s);
    }
}
