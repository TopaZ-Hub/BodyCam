package pl.bodycam.app;

import android.graphics.Rect;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.util.ArrayList;
import java.util.List;

/**
 * Wykrywanie głów (ML Kit, działa w telefonie, bez internetu). Wykryta twarz jest powiększana
 * do obszaru całej głowy (czoło, włosy, uszy). Wyniki w układzie współrzędnych klatki z aparatu.
 */
final class Faces {

    private final FaceDetector det;
    private volatile boolean busy;
    private byte[] small;
    private volatile float[][] last = new float[0][], prev = new float[0][];
    private volatile long lastAt, prevAt;

    Faces() {
        det = FaceDetection.getClient(new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setMinFaceSize(0.04f)
                .enableTracking()
                .build());
    }

    /** Wysyła klatkę do wykrywania (co najwyżej jedna naraz – reszta pomijana). */
    void submit(byte[] nv, int w, int h, int rot) {
        if (busy) return;
        busy = true;
        try {
            final int sw = (w / 2) & ~1, sh = (h / 2) & ~1;
            if (small == null || small.length != sw * sh * 3 / 2) small = new byte[sw * sh * 3 / 2];
            for (int y = 0; y < sh; y++) {
                int s = 2 * y * w, d = y * sw;
                for (int x = 0; x < sw; x++) small[d + x] = nv[s + 2 * x];
            }
            int so = w * h, dO = sw * sh;
            for (int y = 0; y < sh / 2; y++) {
                int s = so + 2 * y * w, d = dO + y * sw;
                for (int x = 0; x < sw / 2; x++) {
                    small[d + 2 * x] = nv[s + 4 * x];
                    small[d + 2 * x + 1] = nv[s + 4 * x + 1];
                }
            }
            InputImage img = InputImage.fromByteArray(small, sw, sh, rot, InputImage.IMAGE_FORMAT_NV21);
            det.process(img)
                    .addOnSuccessListener(list -> {
                        List<float[]> out = new ArrayList<>();
                        for (Face f : list) out.add(toHead(f.getBoundingBox(), sw, sh, rot));
                        prev = last;
                        prevAt = lastAt;
                        last = out.toArray(new float[0][]);
                        lastAt = System.currentTimeMillis();
                        busy = false;
                    })
                    .addOnFailureListener(e -> busy = false);
        } catch (Exception e) {
            busy = false;
        }
    }

    /** Twarz (w obrazie wyprostowanym) -> prostokąt głowy w klatce aparatu w pełnej rozdzielczości. */
    static float[] toHead(Rect r, int sw, int sh, int rot) {
        float cx = r.exactCenterX(), fw = r.width(), fh = r.height();
        // głowa: szerzej o 60 %, w górę o 65 % (włosy), w dół o 20 % (broda/szyja)
        float x0 = cx - fw * 0.8f, x1 = cx + fw * 0.8f;
        float y0 = r.top - fh * 0.65f, y1 = r.bottom + fh * 0.2f;
        float[] a = map(x0, y0, sw, sh, rot), b = map(x1, y1, sw, sh, rot);
        return new float[]{Math.min(a[0], b[0]) * 2, Math.min(a[1], b[1]) * 2, Math.max(a[0], b[0]) * 2, Math.max(a[1], b[1]) * 2};
    }

    /** Punkt z obrazu wyprostowanego (po obrocie o rot) do współrzędnych bufora aparatu. */
    static float[] map(float xu, float yu, int sw, int sh, int rot) {
        switch (rot) {
            case 90: return new float[]{yu, sh - 1 - xu};
            case 180: return new float[]{sw - 1 - xu, sh - 1 - yu};
            case 270: return new float[]{sw - 1 - yu, xu};
            default: return new float[]{xu, yu};
        }
    }

    /** Aktualne głowy: suma dwóch ostatnich wyników (mniej migania), stare wyniki wygasają. */
    float[][] current() {
        long now = System.currentTimeMillis();
        List<float[]> out = new ArrayList<>();
        if (now - lastAt < 900) for (float[] b : last) out.add(b);
        if (now - prevAt < 600) for (float[] b : prev) out.add(b);
        return out.toArray(new float[0][]);
    }

    void close() {
        try { det.close(); } catch (Exception ignored) { }
    }
}
