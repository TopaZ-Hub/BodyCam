package pl.bodycam.app;

import android.graphics.Rect;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Wykrywanie głów (ML Kit, w telefonie, bez internetu) + śledzenie, żeby zamazanie nie znikało:
 *  - tryb dokładny, pełna rozdzielczość do 1280 px – łapie małe i odwrócone bokiem twarze, wiele osób naraz,
 *  - każda głowa jest pamiętana ~1,8 s po ostatnim wykryciu (gdy na chwilę "zgubi" twarz, blur zostaje),
 *  - ruch głowy jest przewidywany (wykrywanie trwa ~0,1–0,2 s), a obszar rośnie, gdy głowa nie jest widziana.
 */
final class Faces {

    private static final long KEEP_MS = 1800;

    private static final class Track {
        float cx, cy, w, h;        // środek i rozmiar w klatce aparatu
        float vx, vy;              // prędkość (piksele/ms)
        long seen;
        int id;                    // identyfikator śledzenia ML Kit (-1 = brak)
    }

    private final FaceDetector det;
    private volatile boolean busy;
    private byte[] buf;
    private final List<Track> tracks = new ArrayList<>();
    private long busySince;

    Faces() {
        det = FaceDetection.getClient(new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setMinFaceSize(0.03f)
                .enableTracking()
                .build());
    }

    /** Wysyła klatkę do wykrywania (co najwyżej jedna naraz – reszta pomijana). */
    void submit(byte[] nv, int w, int h, int rot) {
        long now = System.currentTimeMillis();
        if (busy && now - busySince < 1500) return;
        busy = true;
        busySince = now;
        try {
            final int scale = w > 1280 ? 2 : 1;
            final int sw = (w / scale) & ~1, sh = (h / scale) & ~1;
            if (buf == null || buf.length != sw * sh * 3 / 2) buf = new byte[sw * sh * 3 / 2];
            if (scale == 1) {
                System.arraycopy(nv, 0, buf, 0, Math.min(nv.length, buf.length));
            } else {
                for (int y = 0; y < sh; y++) {
                    int s = 2 * y * w, d = y * sw;
                    for (int x = 0; x < sw; x++) buf[d + x] = nv[s + 2 * x];
                }
                int so = w * h, dO = sw * sh;
                for (int y = 0; y < sh / 2; y++) {
                    int s = so + 2 * y * w, d = dO + y * sw;
                    for (int x = 0; x < sw / 2; x++) {
                        buf[d + 2 * x] = nv[s + 4 * x];
                        buf[d + 2 * x + 1] = nv[s + 4 * x + 1];
                    }
                }
            }
            final long t0 = now;
            InputImage img = InputImage.fromByteArray(buf, sw, sh, rot, InputImage.IMAGE_FORMAT_NV21);
            det.process(img)
                    .addOnSuccessListener(list -> {
                        List<float[]> heads = new ArrayList<>();
                        List<Integer> ids = new ArrayList<>();
                        for (Face f : list) {
                            float[] b = toHead(f.getBoundingBox(), sw, sh, rot);
                            for (int i = 0; i < 4; i++) b[i] *= scale;
                            heads.add(b);
                            Integer tid = f.getTrackingId();
                            ids.add(tid == null ? -1 : tid);
                        }
                        update(heads, ids, t0);
                        busy = false;
                    })
                    .addOnFailureListener(e -> busy = false);
        } catch (Exception e) {
            busy = false;
        }
    }

    /** Dopasowanie nowych wykryć do śledzonych głów (po identyfikatorze albo nakładaniu się). */
    private synchronized void update(List<float[]> heads, List<Integer> ids, long t) {
        final int n0 = tracks.size();      // dopasowujemy tylko do głów sprzed tej klatki
        boolean[] used = new boolean[n0];
        for (int k = 0; k < heads.size(); k++) {
            float[] b = heads.get(k);
            int id = ids.get(k);
            float cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, w = b[2] - b[0], h = b[3] - b[1];
            int best = -1;
            float bestScore = 0;
            for (int i = 0; i < n0; i++) {
                if (used[i]) continue;
                Track tr = tracks.get(i);
                float sc;
                if (id >= 0 && tr.id == id) sc = 10f;
                else {
                    float dx = Math.abs(tr.cx - cx), dy = Math.abs(tr.cy - cy);
                    float lim = Math.max(tr.w, w) * 0.9f;
                    sc = dx < lim && dy < lim ? 1f - (dx + dy) / (2 * lim) : 0f;
                }
                if (sc > bestScore) { bestScore = sc; best = i; }
            }
            if (best >= 0) {
                Track tr = tracks.get(best);
                used[best] = true;
                float dt = Math.max(30, t - tr.seen);
                float nvx = (cx - tr.cx) / dt, nvy = (cy - tr.cy) / dt;
                tr.vx = tr.vx * 0.5f + nvx * 0.5f;
                tr.vy = tr.vy * 0.5f + nvy * 0.5f;
                tr.cx = cx;
                tr.cy = cy;
                tr.w = tr.w * 0.3f + w * 0.7f;
                tr.h = tr.h * 0.3f + h * 0.7f;
                tr.seen = t;
                if (id >= 0) tr.id = id;
            } else {
                Track tr = new Track();
                tr.cx = cx;
                tr.cy = cy;
                tr.w = w;
                tr.h = h;
                tr.seen = t;
                tr.id = id;
                tracks.add(tr);
            }
        }
        Iterator<Track> it = tracks.iterator();
        while (it.hasNext()) if (t - it.next().seen > KEEP_MS) it.remove();
    }

    /** Twarz (w obrazie wyprostowanym) -> prostokąt głowy w klatce aparatu. */
    static float[] toHead(Rect r, int sw, int sh, int rot) {
        float cx = r.exactCenterX(), fw = r.width(), fh = r.height();
        // głowa z włosami i uszami: szerzej o 90 %, w górę o 75 %, w dół o 30 %
        float x0 = cx - fw * 0.95f, x1 = cx + fw * 0.95f;
        float y0 = r.top - fh * 0.75f, y1 = r.bottom + fh * 0.3f;
        float[] a = map(x0, y0, sw, sh, rot), b = map(x1, y1, sw, sh, rot);
        return new float[]{Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1])};
    }

    /** Punkt z obrazu wyprostowanego (po obrocie o rot) do współrzędnych bufora aparatu. */
    static float[] map(float xu, float yu, int sw, int sh, int rot) {
        switch (rot) {
            case 90: return new float[]{yu, sh - 1 - xu};
            case 180: return new float[]{sw - 1 - xu, sh - 1 - yu};
            case 270: return new float[]{sw - 1 - yu, xu};
            default: return new float[]{xu, yu};
        }
    }

    /** Aktualne obszary do zamazania: przewidziana pozycja, powiększana, gdy głowa dawno nie widziana. */
    synchronized float[][] current() {
        long now = System.currentTimeMillis();
        List<float[]> out = new ArrayList<>();
        for (Track t : tracks) {
            long age = now - t.seen;
            if (age > KEEP_MS) continue;
            float pa = Math.min(age, 400);                          // przewidywanie ruchu do 0,4 s
            float cx = t.cx + t.vx * pa, cy = t.cy + t.vy * pa;
            float grow = 1.1f + Math.min(0.5f, age / 1000f * 0.4f); // zapas na ruch / opóźnienie
            float hw = t.w * grow / 2, hh = t.h * grow / 2;
            out.add(new float[]{cx - hw, cy - hh, cx + hw, cy + hh});
        }
        return out.toArray(new float[0][]);
    }

    void close() {
        try { det.close(); } catch (Exception ignored) { }
    }
}
