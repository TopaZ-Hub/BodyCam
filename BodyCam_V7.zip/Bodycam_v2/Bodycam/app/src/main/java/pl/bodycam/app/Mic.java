package pl.bodycam.app;

import android.media.AudioRecord;
import android.media.MediaRecorder;

/** Mikrofon 16 kHz mono: do nagrania (AAC) i do podglądu na żywo (ADPCM, paczki po 50 ms). */
final class Mic {

    interface Sink { void onPcm(short[] pcm, int n, long ptsUs); }

    private volatile boolean running;
    private Thread t;
    private final Sink sink;
    volatile float level;

    Mic(Sink s) {
        sink = s;
    }

    @SuppressWarnings("MissingPermission")
    void start() {
        if (running) return;
        running = true;
        t = new Thread(() -> {
            AudioRecord r = null;
            try {
                int min = AudioRecord.getMinBufferSize(16000, android.media.AudioFormat.CHANNEL_IN_MONO,
                        android.media.AudioFormat.ENCODING_PCM_16BIT);
                r = new AudioRecord(MediaRecorder.AudioSource.CAMCORDER, 16000, android.media.AudioFormat.CHANNEL_IN_MONO,
                        android.media.AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 16000));
                if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                    r.release();
                    r = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000, android.media.AudioFormat.CHANNEL_IN_MONO,
                            android.media.AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 16000));
                }
                r.startRecording();
                short[] buf = new short[800];
                while (running) {
                    int n = r.read(buf, 0, buf.length);
                    if (n <= 0) continue;
                    long pts = System.nanoTime() / 1000 - n * 1_000_000L / 16000;
                    long s = 0;
                    for (int i = 0; i < n; i++) s += Math.abs(buf[i]);
                    level = s / (float) n / 32768f;
                    sink.onPcm(buf, n, pts);
                }
            } catch (Exception ignored) {
            } finally {
                if (r != null) {
                    try { r.stop(); } catch (Exception ignored) { }
                    r.release();
                }
            }
        }, "mic");
        t.start();
    }

    void stop() {
        running = false;
    }
}
