package pl.bodycam.app;

import android.graphics.Rect;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.mlkit.vision.face.FaceLandmark;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Wykrywanie głów (ML Kit, w telefonie, bez internetu) + śledzenie.
 *  - szybki tryb, często (~10–15 razy/s) – płynne podążanie i bez zacinania aparatu,
 *  - odrzucanie fałszywych wykryć: twarz musi mieć oczy/nos, rozsądny kształt i rozmiar
 *    i musi się pojawić co najmniej 2 razy, zanim zostanie zamazana (ściany, nogi itp. odpadają),
 *  - potwierdzona głowa jest trzymana ~1,2 s po zgubieniu, z przewidywaniem ruchu,
 *  - zamazany obszar płynnie "dojeżdża" do głowy w każdej klatce, zamiast skakać.
 */
final class Faces {

    private static final long KEEP_MS = 1200, CONFIRM_MS = 700, MIN_GAP_MS = 60;

    private static final class Track {
        float cx, cy, w, h, vx, vy;            // ostatni pomiar + prędkość (px/ms)
        float dx, dy, dw, dh;                  // to, co jest rysowane (wygładzone)
        boolean drawn;
        long seen, first;
        int hits, id;
    }

    private final FaceDetector det;
    private final Executor exec = Executors.newSingleThreadExecutor();
    private volatile boolean busy;
    private long busySince, lastSubmit;
    private byte[] buf;
    private final List<Track> tracks = new ArrayList<>();

    Faces() {
        det = FaceDetection.getClient(new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setMinFaceSize(0.04f)
                .enableTracking()
                .build());
    }

    void submit(byte[] nv, int w, int h, int rot) {
        long now = System.currentTimeMillis();
        if ((busy && now - busySince < 1000) || now - lastSubmit < MIN_GAP_MS) return;
        busy = true;
        busySince = now;
        lastSubmit = now;
        try {
            final int scale = w > 1280 ? 2 : 1;
            final int sw = (w / scale) & ~1, sh = (h / scale) & ~1;
            if (buf == null || buf.length != sw * sh * 3 / 2) buf = new byte[sw * sh * 3 / 2];
            if (scale == 1) System.arraycopy(nv, 0, buf, 0, Math.min(nv.length, buf.length));
            else {
                for (int y = 0; y < sh; y++) {
                    int s = 2 * y * w, d = y * sw;
                    for (int x = 0; x < sw; x++) buf[d + x] = nv[s + 2 * x];
                }
                int so = w * h, dO = sw * sh;
                for (int y = 0; y < sh / 2; y++) {
                    int s = so + 2 * y * w, d = dO + y * sw;
                    for (int x = 0; x < sw / 2; x++) {
                        buf[d + 2 * x] = nv[s + 4 * x];
                        buf[d + 2 * x + 1] = nv[s + 4 * x + 1];
                    }
                }
            }
            final long t0 = now;
            InputImage img = InputImage.fromByteArray(buf, sw, sh, rot, InputImage.IMAGE_FORMAT_NV21);
            det.process(img)
                    .addOnSuccessListener(exec, list -> {
                        List<float[]> heads = new ArrayList<>();
                        List<Integer> ids = new ArrayList<>();
                        int upW = rot % 180 == 0 ? sw : sh, upH = rot % 180 == 0 ? sh : sw;
                        for (Face f : list) {
                            if (!plausible(f, upW, upH)) continue;
                            float[] b = toHead(f.getBoundingBox(), sw, sh, rot);
                            for (int i = 0; i < 4; i++) b[i] *= scale;
                            heads.add(b);
                            Integer tid = f.getTrackingId();
                            ids.add(tid == null ? -1 : tid);
                        }
                        update(heads, ids, t0);
                        busy = false;
                    })
                    .addOnFailureListener(exec, e -> busy = false);
        } catch (Exception e) {
            busy = false;
        }
    }

    /** Czy to naprawdę twarz: ma oczy albo nos, kształt zbliżony do kwadratu, nie jest ogromna. */
    static boolean plausible(Face f, int upW, int upH) {
        Rect r = f.getBoundingBox();
        if (r.width() <= 0 || r.height() <= 0) return false;
        float ratio = r.width() / (float) r.height();
        if (ratio < 0.6f || ratio > 1.5f) return false;
        if (r.height() > upH * 0.75f || r.width() > upW * 0.75f) return false;
        int marks = 0;
        if (f.getLandmark(FaceLandmark.LEFT_EYE) != null) marks++;
        if (f.getLandmark(FaceLandmark.RIGHT_EYE) != null) marks++;
        if (f.getLandmark(FaceLandmark.NOSE_BASE) != null) marks++;
        if (f.getLandmark(FaceLandmark.MOUTH_BOTTOM) != null) marks++;
        return marks >= 2;
    }

    private synchronized void update(List<float[]> heads, List<Integer> ids, long t) {
        final int n0 = tracks.size();
        boolean[] used = new boolean[n0];
        for (int k = 0; k < heads.size(); k++) {
            float[] b = heads.get(k);
            int id = ids.get(k);
            float cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, w = b[2] - b[0], h = b[3] - b[1];
            int best = -1;
            float bestScore = 0;
            for (int i = 0; i < n0; i++) {
                if (used[i]) continue;
                Track tr = tracks.get(i);
                float sc;
                if (id >= 0 && tr.id == id) sc = 10f;
                else {
                    float ddx = Math.abs(tr.cx - cx), ddy = Math.abs(tr.cy - cy);
                    float lim = Math.max(tr.w, w) * 0.8f;
                    sc = ddx < lim && ddy < lim ? 1f - (ddx + ddy) / (2 * lim) : 0f;
                }
                if (sc > bestScore) { bestScore = sc; best = i; }
            }
            Track tr;
            if (best >= 0) {
                tr = tracks.get(best);
                used[best] = true;
                float dt = Math.max(30, t - tr.seen);
                tr.vx = tr.vx * 0.6f + (cx - tr.cx) / dt * 0.4f;
                tr.vy = tr.vy * 0.6f + (cy - tr.cy) / dt * 0.4f;
                tr.w = tr.w * 0.5f + w * 0.5f;
                tr.h = tr.h * 0.5f + h * 0.5f;
                tr.hits++;
            } else {
                tr = new Track();
                tr.w = w;
                tr.h = h;
                tr.first = t;
                tr.hits = 1;
                tracks.add(tr);
            }
            tr.cx = cx;
            tr.cy = cy;
            tr.seen = t;
            if (id >= 0) tr.id = id;
        }
        Iterator<Track> it = tracks.iterator();
        while (it.hasNext()) {
            Track tr = it.next();
            boolean confirmed = tr.hits >= 2;
            if (t - tr.seen > (confirmed ? KEEP_MS : CONFIRM_MS)) it.remove();
        }
    }

    static float[] toHead(Rect r, int sw, int sh, int rot) {
        float cx = r.exactCenterX(), fw = r.width(), fh = r.height();
        // głowa z włosami i uszami
        float x0 = cx - fw * 0.85f, x1 = cx + fw * 0.85f;
        float y0 = r.top - fh * 0.6f, y1 = r.bottom + fh * 0.25f;
        float[] a = map(x0, y0, sw, sh, rot), b = map(x1, y1, sw, sh, rot);
        return new float[]{Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1])};
    }

    static float[] map(float xu, float yu, int sw, int sh, int rot) {
        switch (rot) {
            case 90: return new float[]{yu, sh - 1 - xu};
            case 180: return new float[]{sw - 1 - xu, sh - 1 - yu};
            case 270: return new float[]{sw - 1 - yu, xu};
            default: return new float[]{xu, yu};
        }
    }

    /** Wywoływane co klatkę: obszary do zamazania, płynnie podążające za głowami. */
    synchronized float[][] current() {
        long now = System.currentTimeMillis();
        List<float[]> out = new ArrayList<>();
        for (Track t : tracks) {
            if (t.hits < 2) continue;                              // jeszcze niepotwierdzona
            long age = now - t.seen;
            if (age > KEEP_MS) continue;
            float pa = Math.min(age, 250);                         // przewidywanie ruchu
            float px = t.cx + t.vx * pa, py = t.cy + t.vy * pa;
            float grow = 1.08f + Math.min(0.3f, age / 1000f * 0.3f);
            float pw = t.w * grow, ph = t.h * grow;
            if (!t.drawn) {
                t.dx = px; t.dy = py; t.dw = pw; t.dh = ph;
                t.drawn = true;
            } else {                                                // płynne dojeżdżanie
                t.dx += (px - t.dx) * 0.55f;
                t.dy += (py - t.dy) * 0.55f;
                t.dw += (pw - t.dw) * 0.35f;
                t.dh += (ph - t.dh) * 0.35f;
            }
            // obszar zawsze obejmuje i wygładzoną, i przewidzianą pozycję – głowa nie "wyjeżdża" spod blura
            float x0 = Math.min(t.dx - t.dw / 2, px - pw / 2), x1 = Math.max(t.dx + t.dw / 2, px + pw / 2);
            float y0 = Math.min(t.dy - t.dh / 2, py - ph / 2), y1 = Math.max(t.dy + t.dh / 2, py + ph / 2);
            out.add(new float[]{x0, y0, x1, y1});
        }
        return out.toArray(new float[0][]);
    }

    void close() {
        try { det.close(); } catch (Exception ignored) { }
    }
}
