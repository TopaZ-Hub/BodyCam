package pl.bodycam.app;

import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Kodowanie podglądu na żywo: mniejsza rozdzielczość, H.264, klatka kluczowa co 2 s i na żądanie
 * nowego widza. Każda klatka kluczowa ma dołączone SPS/PPS, więc widz może dołączyć w dowolnej chwili.
 */
final class Streamer {

    private final Link.Sender tx;
    final int w, h, rot;
    private final int fps;
    private final HandlerThread th = new HandlerThread("stream");
    private final Handler hd;
    private final AtomicInteger pending = new AtomicInteger();
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    private final Look look = new Look();
    private MediaCodec codec;
    private Surface surface;
    private byte[] csd = new byte[0];
    private volatile boolean dead;
    private long lastNs;
    volatile int sentKb;

    Streamer(Link.Sender tx, int bw, int bh, int rot, int quality) {
        this.tx = tx;
        this.rot = rot;
        int[] o = Look.outSize(bw, bh, rot);
        int longSide = quality == 0 ? 640 : quality == 1 ? 854 : 1280;
        float sc = (float) longSide / Math.max(o[0], o[1]);
        w = Math.round(o[0] * sc) & ~15;
        h = Math.round(o[1] * sc) & ~15;
        fps = quality == 0 ? 12 : 20;
        int bitrate = quality == 0 ? 450_000 : quality == 1 ? 900_000 : 1_800_000;
        th.start();
        hd = new Handler(th.getLooper());
        hd.post(() -> {
            try {
                MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
                f.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
                f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
                if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LATENCY, 1);
                f.setInteger(MediaFormat.KEY_PRIORITY, 0);
                codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
                codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                surface = codec.createInputSurface();
                codec.start();
            } catch (Exception e) {
                dead = true;
            }
        });
    }

    void requestKey() {
        hd.post(() -> {
            try {
                if (codec == null) return;
                Bundle b = new Bundle();
                b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                codec.setParameters(b);
            } catch (Exception ignored) { }
        });
    }

    void addFrame(Frame f, boolean rec) {
        long now = System.nanoTime();
        if (dead || pending.get() > 0 || now - lastNs < 1_000_000_000L / (fps + 1)) return;
        lastNs = now;
        f.retain();
        pending.incrementAndGet();
        hd.post(() -> {
            pending.decrementAndGet();
            try {
                if (dead || surface == null) return;
                Canvas c = surface.lockHardwareCanvas();
                c.drawColor(Color.BLACK);
                look.draw(c, f.bmp, f.time, 0, 0, w, h, rot, rec);
                surface.unlockCanvasAndPost(c);
                drain();
            } catch (Exception e) {
                dead = true;
            } finally {
                f.release();
            }
        });
    }

    private void drain() {
        while (true) {
            int idx = codec.dequeueOutputBuffer(info, 0);
            if (idx < 0) {
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) break;
                continue;
            }
            ByteBuffer bb = codec.getOutputBuffer(idx);
            if (bb != null && info.size > 0) {
                byte[] data = new byte[info.size];
                bb.position(info.offset);
                bb.get(data);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    csd = data;
                } else {
                    boolean key = (info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0;
                    if (key && csd.length > 0) {
                        byte[] all = new byte[csd.length + data.length];
                        System.arraycopy(csd, 0, all, 0, csd.length);
                        System.arraycopy(data, 0, all, csd.length, data.length);
                        data = all;
                    }
                    sentKb += data.length / 1024;
                    tx.video(data, key, System.currentTimeMillis(), w, h);
                }
            }
            codec.releaseOutputBuffer(idx, false);
        }
    }

    boolean dead() {
        return dead;
    }

    void stop() {
        dead = true;
        hd.post(() -> {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) { }
            if (surface != null) surface.release();
            th.quitSafely();
        });
    }
}
