package pl.bodycam.app;

import android.view.View;

abstract class Screen {
    final MainActivity a;

    Screen(MainActivity a) {
        this.a = a;
    }

    abstract View view();

    void onShow() { }
    void onHide() { }
    void onPause() { }
    void onResume() { }
    void onConfig() { }

    /** true = obsłużone. */
    boolean back() { return false; }

    boolean key(int code) { return false; }
}
