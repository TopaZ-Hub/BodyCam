package pl.bodycam.app;

import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Łącze przez internet: oba telefony łączą się z publicznym serwerem pośredniczącym (MQTT po TLS)
 * i spotykają się "na kodzie". Kod wyznacza kanał i klucz szyfrowania (AES-GCM) – serwer ani nikt
 * bez kodu nie zobaczy obrazu. Działa przez LTE/5G i dowolne Wi-Fi, bez parowania i bez tej samej sieci.
 */
final class Link {

    static final String[][] SERVERS = {
            {"broker.emqx.io", "8883", "EMQX (UE)"},
            {"broker.hivemq.com", "8883", "HiveMQ (UE)"},
            {"test.mosquitto.org", "8886", "Mosquitto (UK)"},
    };

    static final byte T_VIDEO = 'V', T_AUDIO = 'A';
    private static final SecureRandom RND = new SecureRandom();
    private static final String ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    final String code;
    final String base;
    private final SecretKeySpec key;

    Link(String code) {
        this.code = clean(code);
        byte[] k = sha("bodycam-key|" + this.code);
        key = new SecretKeySpec(k, 0, 16, "AES");
        base = "bcv1/" + hex(sha("bodycam-topic|" + this.code), 12);
    }

    static String newCode() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 8; i++) s.append(ALPHA.charAt(RND.nextInt(ALPHA.length())));
        return s.toString();
    }

    static String clean(String c) {
        StringBuilder s = new StringBuilder();
        for (char ch : c.toUpperCase(java.util.Locale.ROOT).toCharArray())
            if ((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) s.append(ch == 'O' ? '0' : ch == 'I' ? '1' : ch);
        return s.toString();
    }

    static String pretty(String c) {
        c = clean(c);
        return c.length() == 8 ? c.substring(0, 4) + "-" + c.substring(4) : c;
    }

    byte[] seal(byte[] plain) {
        try {
            byte[] iv = new byte[12];
            RND.nextBytes(iv);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
            byte[] ct = c.doFinal(plain);
            byte[] out = new byte[12 + ct.length];
            System.arraycopy(iv, 0, out, 0, 12);
            System.arraycopy(ct, 0, out, 12, ct.length);
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    byte[] open(byte[] sealed) {
        if (sealed == null || sealed.length < 28) return null;
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, sealed, 0, 12));
            return c.doFinal(sealed, 12, sealed.length - 12);
        } catch (Exception e) {
            return null;
        }
    }

    /** Serwery w kolejności prób – obie strony próbują w tej samej kolejności, więc trafiają na ten sam. */
    static List<String[]> servers(int choice, String custom) {
        List<String[]> l = new ArrayList<>();
        if (choice == 4 && custom != null && custom.contains(":")) {
            String[] p = custom.trim().split(":");
            l.add(new String[]{p[0], p[1], custom});
            return l;
        }
        if (choice >= 1 && choice <= SERVERS.length) {
            l.add(SERVERS[choice - 1]);
            return l;
        }
        for (String[] s : SERVERS) l.add(s);
        return l;
    }

    static Mqtt dial(List<String[]> list, String clientId, String willTopic, byte[] will, Mqtt.Listener l) {
        for (String[] s : list) {
            try {
                int port = Integer.parseInt(s[1].trim());
                boolean tls = port != 1883;
                return Mqtt.connect(s[0].trim(), port, tls, clientId, willTopic, will, l, 8000);
            } catch (Exception ignored) { }
        }
        return null;
    }

    static byte[] sha(String s) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static String hex(byte[] b, int n) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < n; i++) s.append(String.format("%02x", b[i]));
        return s.toString();
    }

    static String cid() {
        return "bc" + Long.toHexString(RND.nextLong() & 0xFFFFFFFFFFFFL);
    }

    // ===================================================================================== NADAJNIK

    /** Strona bodycama: nadaje obraz i dźwięk tylko wtedy, gdy ktoś ogląda (oszczędza transfer i baterię). */
    static final class Sender implements Mqtt.Listener {
        interface Events {
            void needKeyframe();
            void onState(String text);
        }

        final Link link;
        private final Events ev;
        private final List<String[]> servers;
        private volatile Mqtt m;
        private volatile boolean running = true;
        private final Map<String, Long> viewers = new HashMap<>();
        private int vSeq = 0, aSeq = 0;
        private volatile boolean dropToKey = false;
        final JSONObject status = new JSONObject();
        volatile String server = "";

        Sender(Link l, List<String[]> servers, Events e) {
            link = l;
            ev = e;
            this.servers = servers;
            Thread t = new Thread(this::loop, "link-tx");
            t.setDaemon(true);
            t.start();
        }

        private void loop() {
            int backoff = 1000;
            while (running) {
                ev.onState("łączenie…");
                byte[] off = link.seal(statusBytes(false));
                Mqtt c = dial(servers, cid(), link.base + "/s", off, this);
                if (c == null) {
                    ev.onState("brak internetu – ponawiam");
                    sleep(backoff);
                    backoff = Math.min(15000, backoff * 2);
                    continue;
                }
                backoff = 1000;
                m = c;
                server = c.server;
                c.subscribe(link.base + "/c");
                while (running && c.alive()) {
                    byte[] s = link.seal(statusBytes(true));
                    if (s != null) c.publish(link.base + "/s", s, true, false);
                    ev.onState("online · " + viewers() + " ogląda");
                    sleep(2000);
                }
                m = null;
                if (running) ev.onState("rozłączono – ponawiam");
            }
        }

        private byte[] statusBytes(boolean on) {
            try {
                JSONObject j;
                synchronized (status) { j = new JSONObject(status.toString()); }
                j.put("on", on ? 1 : 0);
                j.put("t", System.currentTimeMillis());
                return j.toString().getBytes(StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "{}".getBytes(StandardCharsets.UTF_8);
            }
        }

        synchronized int viewers() {
            long now = System.currentTimeMillis();
            Iterator<Map.Entry<String, Long>> it = viewers.entrySet().iterator();
            while (it.hasNext()) if (now - it.next().getValue() > 12_000) it.remove();
            return viewers.size();
        }

        boolean watching() {
            return m != null && viewers() > 0;
        }

        @Override
        public void onMessage(String topic, byte[] payload) {
            byte[] p = link.open(payload);
            if (p == null) return;
            try {
                JSONObject j = new JSONObject(new String(p, StandardCharsets.UTF_8));
                String id = j.optString("id");
                boolean isNew;
                synchronized (this) {
                    isNew = !viewers.containsKey(id);
                    viewers.put(id, System.currentTimeMillis());
                }
                if (isNew || j.optInt("key") == 1) ev.needKeyframe();
            } catch (Exception ignored) { }
        }

        @Override
        public void onLost() { }

        /** Pakiet wideo H.264 (Annex B). Gdy łącze nie nadąża – gubimy do następnej klatki kluczowej. */
        void video(byte[] h264, boolean key, long ptsMs, int w, int h) {
            Mqtt c = m;
            if (c == null) return;
            if (dropToKey && !key) return;
            ByteBuffer b = ByteBuffer.allocate(18 + h264.length);
            b.put(T_VIDEO).put((byte) (key ? 1 : 0)).putInt(vSeq++).putLong(ptsMs).putShort((short) w).putShort((short) h);
            b.put(h264);
            byte[] s = link.seal(b.array());
            if (s == null) return;
            boolean ok = c.publish(link.base + "/v", s, false, true);
            if (!ok) {
                dropToKey = true;
                ev.needKeyframe();
            } else if (key) dropToKey = false;
        }

        void audio(byte[] adpcm, long ptsMs) {
            Mqtt c = m;
            if (c == null) return;
            ByteBuffer b = ByteBuffer.allocate(13 + adpcm.length);
            b.put(T_AUDIO).putInt(aSeq++).putLong(ptsMs).put(adpcm);
            byte[] s = link.seal(b.array());
            if (s != null) c.publish(link.base + "/a", s, false, true);
        }

        void stop() {
            running = false;
            Mqtt c = m;
            if (c != null) {
                byte[] off = link.seal(statusBytes(false));
                if (off != null) c.publish(link.base + "/s", off, true, false);
                sleep(150);
                c.close();
            }
        }
    }

    // ===================================================================================== ODBIORNIK

    static final class Receiver implements Mqtt.Listener {
        interface Events {
            void onVideo(boolean key, int seq, long ptsMs, int w, int h, byte[] data, int off, int len);
            void onAudio(int seq, long ptsMs, byte[] data, int off, int len);
            void onStatus(JSONObject s);
            void onState(String text, boolean connected);
        }

        final Link link;
        private final Events ev;
        private final List<String[]> servers;
        private final String id = cid();
        private volatile Mqtt m;
        private volatile boolean running = true;
        private volatile boolean wantKey = false;
        volatile long bytes = 0;

        Receiver(Link l, List<String[]> servers, Events e) {
            link = l;
            ev = e;
            this.servers = servers;
            Thread t = new Thread(this::loop, "link-rx");
            t.setDaemon(true);
            t.start();
        }

        private void loop() {
            int backoff = 1000;
            while (running) {
                ev.onState("łączenie z serwerem…", false);
                Mqtt c = dial(servers, cid(), null, null, this);
                if (c == null) {
                    ev.onState("brak internetu – ponawiam", false);
                    sleep(backoff);
                    backoff = Math.min(15000, backoff * 2);
                    continue;
                }
                backoff = 1000;
                m = c;
                c.subscribe(link.base + "/s", link.base + "/v", link.base + "/a");
                ev.onState("połączono · " + c.server, true);
                long last = 0;
                while (running && c.alive()) {
                    long now = System.currentTimeMillis();
                    if (now - last > 4000 || wantKey) {
                        hello(c, wantKey);
                        wantKey = false;
                        last = now;
                    }
                    sleep(200);
                }
                m = null;
                if (running) ev.onState("rozłączono – ponawiam", false);
            }
        }

        private void hello(Mqtt c, boolean key) {
            try {
                JSONObject j = new JSONObject();
                j.put("id", id);
                j.put("key", key ? 1 : 0);
                byte[] s = link.seal(j.toString().getBytes(StandardCharsets.UTF_8));
                if (s != null) c.publish(link.base + "/c", s, false, false);
            } catch (Exception ignored) { }
        }

        void requestKey() {
            wantKey = true;
        }

        @Override
        public void onMessage(String topic, byte[] payload) {
            bytes += payload.length;
            byte[] p = link.open(payload);
            if (p == null) return;
            if (topic.endsWith("/s")) {
                try {
                    ev.onStatus(new JSONObject(new String(p, StandardCharsets.UTF_8)));
                } catch (Exception ignored) { }
                return;
            }
            ByteBuffer b = ByteBuffer.wrap(p);
            byte t = b.get();
            if (t == T_VIDEO && p.length > 18) {
                boolean key = b.get() == 1;
                int seq = b.getInt();
                long pts = b.getLong();
                int w = b.getShort() & 0xFFFF, h = b.getShort() & 0xFFFF;
                ev.onVideo(key, seq, pts, w, h, p, 18, p.length - 18);
            } else if (t == T_AUDIO && p.length > 13) {
                int seq = b.getInt();
                long pts = b.getLong();
                ev.onAudio(seq, pts, p, 13, p.length - 13);
            }
        }

        @Override
        public void onLost() { }

        void stop() {
            running = false;
            Mqtt c = m;
            if (c != null) c.close();
        }
    }

    static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) { }
    }
}
