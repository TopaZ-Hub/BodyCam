package pl.bodycam.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/**
 * Sygnały jak w kamerach nasobnych: piezo-brzęczyk (ok. 2,9 kHz) + komunikat głosowy.
 *  start: dwa krótkie piki + "Nagrywanie włączone"
 *  stop:  jeden długi pik + "Nagrywanie wyłączone"
 *  w trakcie: krótki pik co 2 minuty (przypomnienie, że kamera nagrywa).
 */
final class Sound {

    private static final int SR = 44100;
    private final Context ctx;
    private TextToSpeech tts;
    private boolean ttsOk;
    private final Handler main = new Handler(Looper.getMainLooper());

    Sound(Context c) {
        ctx = c.getApplicationContext();
        try {
            tts = new TextToSpeech(ctx, status -> {
                if (status != TextToSpeech.SUCCESS) return;
                int r = tts.setLanguage(new Locale("pl", "PL"));
                ttsOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setPitch(0.92f);
                tts.setSpeechRate(1.0f);
            });
        } catch (Exception ignored) { }
    }

    void recStart() {
        beeps(new int[]{110, 70, 110});
        vibrate(new long[]{0, 90, 70, 90});
        if (App.voice()) main.postDelayed(() -> say("Nagrywanie włączone"), 420);
    }

    void recStop() {
        beeps(new int[]{520});
        vibrate(new long[]{0, 400});
        if (App.voice()) main.postDelayed(() -> say("Nagrywanie wyłączone"), 650);
    }

    void reminder() {
        beeps(new int[]{70});
    }

    void say(String s) {
        if (tts != null && ttsOk) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "bc");
    }

    /** Naprzemiennie: czas dźwięku, przerwy, dźwięku… (ms). */
    private void beeps(int[] pattern) {
        new Thread(() -> {
            int total = 0;
            for (int p : pattern) total += p;
            int n = SR * (total + 30) / 1000;
            short[] pcm = new short[n];
            int pos = 0;
            for (int i = 0; i < pattern.length; i++) {
                int len = SR * pattern[i] / 1000;
                if (i % 2 == 0) {
                    for (int k = 0; k < len && pos + k < n; k++) {
                        double t = (double) k / SR;
                        double env = Math.min(1, k / (SR * 0.004)) * Math.min(1, (len - k) / (SR * 0.006));
                        // piezo: ton podstawowy + lekko "brzęczące" harmoniczne
                        double s = Math.sin(2 * Math.PI * 2900 * t) + 0.28 * Math.sin(2 * Math.PI * 5800 * t)
                                + 0.12 * Math.sin(2 * Math.PI * 8700 * t);
                        pcm[pos + k] = (short) (s * env * 9500);
                    }
                }
                pos += len;
            }
            try {
                AudioTrack t = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                        .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .setBufferSizeInBytes(n * 2).build();
                t.write(pcm, 0, n);
                t.play();
                Thread.sleep(total + 120);
                t.release();
            } catch (Exception ignored) { }
        }, "beep").start();
    }

    private void vibrate(long[] p) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(p, -1));
        } catch (Exception ignored) { }
    }

    void release() {
        if (tts != null) tts.shutdown();
    }
}
