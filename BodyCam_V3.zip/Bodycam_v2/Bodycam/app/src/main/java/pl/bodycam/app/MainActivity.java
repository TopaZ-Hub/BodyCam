package pl.bodycam.app;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private Screen cur;
    private Runnable permOk;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        App.init(this);
        Ui.init(this);
        Look.loadLogo(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        show(new HomeScreen(this));
    }

    void show(Screen s) {
        if (cur != null) cur.onHide();
        cur = s;
        setContentView(s.view());
        s.onShow();
    }

    void home() {
        show(new HomeScreen(this));
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    void withPerms(String[] perms, Runnable ok) {
        List<String> need = new ArrayList<>();
        for (String p : perms) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (need.isEmpty()) {
            ok.run();
            return;
        }
        permOk = ok;
        requestPermissions(need.toArray(new String[0]), 7);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean all = true;
        for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) all = false;
        Runnable r = permOk;
        permOk = null;
        if (all && r != null) r.run();
        else if (!all) toast("Bez uprawnień ta funkcja nie zadziała");
    }

    private ResultCb resultCb;

    interface ResultCb { void onResult(android.net.Uri uri); }

    void pickImage(ResultCb cb) {
        resultCb = cb;
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, 9);
    }

    @Override
    protected void onActivityResult(int req, int res, android.content.Intent data) {
        super.onActivityResult(req, res, data);
        ResultCb cb = resultCb;
        resultCb = null;
        if (req == 9 && res == RESULT_OK && data != null && data.getData() != null && cb != null) cb.onResult(data.getData());
    }

    @Override
    public void onBackPressed() {
        if (cur != null && cur.back()) return;
        if (!(cur instanceof HomeScreen)) home();
        else super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (cur != null && cur.key(code)) return true;
        return super.onKeyDown(code, e);
    }

    @Override
    public boolean onKeyUp(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (cur instanceof BodycamScreen && App.volKeys()) return true;
        }
        return super.onKeyUp(code, e);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cur != null) cur.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cur != null) cur.onResume();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (cur != null) cur.onConfig();
    }
}
