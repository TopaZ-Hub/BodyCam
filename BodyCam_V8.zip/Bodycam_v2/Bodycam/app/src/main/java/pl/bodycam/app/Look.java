package pl.bodycam.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Składa obraz jak z kamery nasobnej: obrót, szeroki kąt z efektem "rybiego oka" (jak GoPro),
 * winieta i nakładka z datą, godziną, strefą czasową i numerem urządzenia.
 * Każdy odbiorca (ekran, nagrywanie, nadawanie) ma własną instancję – Paint nie jest wielowątkowy.
 */
final class Look {

    static volatile String gpsText = null;
    /** Własne logo: Twój plik z zipa (app/src/main/assets/logo.png) albo wybrane w ustawieniach. */
    static volatile Bitmap customLogo = null;

    static void loadLogo(android.content.Context c) {
        Bitmap b = null;
        try {
            java.io.File f = new java.io.File(c.getFilesDir(), "logo.png");
            if (f.exists()) b = decodeSmall(new java.io.FileInputStream(f), new java.io.FileInputStream(f));
        } catch (Exception ignored) { }
        if (b == null) {
            try {
                b = decodeSmall(c.getAssets().open("logo.png"), c.getAssets().open("logo.png"));
            } catch (Exception ignored) { }
        }
        customLogo = b;
    }

    /** Wczytanie obrazka pomniejszonego do ok. 512 px (duże pliki nie zapchają pamięci). */
    private static Bitmap decodeSmall(java.io.InputStream probe, java.io.InputStream data) throws java.io.IOException {
        try {
            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeStream(probe, null, o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 512) s *= 2;
            android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
            o2.inSampleSize = s;
            return android.graphics.BitmapFactory.decodeStream(data, null, o2);
        } finally {
            probe.close();
            data.close();
        }
    }

    /** Szerokość logo przy wysokości s (własne logo zachowuje proporcje, max 2,5× wysokości). */
    static float logoW(float s) {
        Bitmap b = customLogo;
        if (b == null || b.getHeight() == 0) return s;
        return Math.min(2.5f * s, s * b.getWidth() / b.getHeight());
    }

    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint logo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint vig = new Paint();
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SimpleDateFormat fDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US);
    private final SimpleDateFormat fClassic = new SimpleDateFormat("MMM dd yyyy  HH:mm:ss z", Locale.US);
    private final Date date = new Date();
    private final Path hex = new Path();

    private float[] mesh;
    private int meshW, meshH, meshK = -1;
    private float vigW, vigH;
    static final int MW = 28, MH = 16;

    Look() {
        txt.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        txt.setColor(0xFFF4F4F4);
        edge.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        edge.setColor(0xFF000000);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeJoin(Paint.Join.ROUND);
        logo.setColor(0xFFF5C400);
        dot.setColor(0xFFE0201B);
    }

    /** Rozmiar wyjściowy (szer., wys.) po obrocie. */
    static int[] outSize(int bw, int bh, int rot) {
        return rot % 180 == 0 ? new int[]{bw, bh} : new int[]{bh, bw};
    }

    void draw(Canvas c, Bitmap b, long timeMs, float dx, float dy, float dw, float dh, int rot, boolean rec) {
        int bw = b.getWidth(), bh = b.getHeight();
        c.save();
        c.clipRect(dx, dy, dx + dw, dy + dh);
        c.translate(dx + dw / 2f, dy + dh / 2f);
        c.rotate(rot);
        if (rot % 180 == 0) c.scale(dw / bw, dh / bh);
        else c.scale(dh / bw, dw / bh);
        c.translate(-bw / 2f, -bh / 2f);
        int k = App.fisheye() ? App.fishStrength() : 0;
        if (k > 0) {
            ensureMesh(bw, bh, k);
            c.drawBitmapMesh(b, MW, MH, mesh, 0, null, 0, bmpPaint);
        } else {
            c.drawBitmap(b, 0, 0, bmpPaint);
        }
        c.restore();

        // winieta – ciemniejsze rogi jak w kamerach z szerokim obiektywem
        if (k > 0) {
            if (vigW != dw || vigH != dh) {
                vigW = dw;
                vigH = dh;
                float r = (float) Math.hypot(dw, dh) / 2f;
                vig.setShader(new RadialGradient(0, 0, r, new int[]{0, 0, 0x22000000, 0x99000000},
                        new float[]{0f, 0.62f, 0.82f, 1f}, Shader.TileMode.CLAMP));
            }
            c.save();
            c.translate(dx + dw / 2f, dy + dh / 2f);
            c.drawRect(-dw / 2f, -dh / 2f, dw / 2f, dh / 2f, vig);
            c.restore();
        }
        overlay(c, timeMs, dx, dy, dw, dh, rec);
    }

    private void ensureMesh(int bw, int bh, int k) {
        if (mesh != null && meshW == bw && meshH == bh && meshK == k) return;
        meshW = bw;
        meshH = bh;
        meshK = k;
        mesh = new float[(MW + 1) * (MH + 1) * 2];
        float kk = k / 100f * 0.6f;
        float cx = bw / 2f, cy = bh / 2f, asp = (float) bh / bw;
        float rc2 = 1 + asp * asp;
        int i = 0;
        for (int y = 0; y <= MH; y++) {
            for (int x = 0; x <= MW; x++) {
                float sx = (float) x / MW * bw, sy = (float) y / MH * bh;
                float nx = (sx - cx) / cx, ny = (sy - cy) / cx;
                float r2 = (nx * nx + ny * ny) / rc2;
                float f = (1 + kk) / (1 + kk * r2);   // środek powiększony, rogi na miejscu = beczka
                mesh[i++] = cx + (sx - cx) * f;
                mesh[i++] = cy + (sy - cy) * f;
            }
        }
    }

    private void overlay(Canvas c, long t, float dx, float dy, float dw, float dh, boolean rec) {
        float m = Math.min(dw, dh);
        float ts = m * (App.style() == 0 ? 0.046f : 0.036f);
        txt.setTextSize(ts);
        edge.setTextSize(ts);
        edge.setStrokeWidth(ts * 0.16f);
        date.setTime(t);
        String gps = App.gps() ? gpsText : null;
        if (App.style() == 0) {
            // styl "Body 3": prawy górny róg, dwie linie + znak urządzenia
            float L = m * 0.105f;
            float right = dx + dw - dw * 0.03f;
            float top = dy + m * 0.045f;
            float lw = logoW(L);
            drawLogo(c, right - lw, top - L * 0.12f, L);
            txt.setTextAlign(Paint.Align.RIGHT);
            edge.setTextAlign(Paint.Align.RIGHT);
            float tx = right - lw - m * 0.03f;
            float line = ts * 1.18f;
            text(c, fDate.format(date), tx, top + ts * 0.9f, txt);
            text(c, App.model(), tx, top + ts * 0.9f + line, txt);
            if (gps != null) text(c, gps, tx, top + ts * 0.9f + 2 * line, txt);
        } else {
            // styl klasyczny: lewy górny róg, REC + dane funkcjonariusza
            float L = m * 0.1f;
            float left = dx + dw * 0.025f, top = dy + m * 0.04f;
            drawLogo(c, left, top, L);
            txt.setTextAlign(Paint.Align.LEFT);
            edge.setTextAlign(Paint.Align.LEFT);
            float tx = left + logoW(L) + m * 0.03f, line = ts * 1.22f, y = top + ts * 0.9f;
            String head = (rec ? "REC " : "STBY ");
            text(c, head, tx, y, txt);
            float hw = txt.measureText(head);
            if (rec && (t / 750) % 2 == 0) c.drawCircle(tx + hw + ts * 0.35f, y - ts * 0.33f, ts * 0.32f, dot);
            text(c, App.model(), tx + hw + ts * 1.1f, y, txt);
            text(c, App.name() + " [" + App.callsign() + "]", tx, y + line, txt);
            text(c, App.unit(), tx, y + 2 * line, txt);
            text(c, fClassic.format(date).toUpperCase(Locale.US), tx, y + 3 * line, txt);
            if (gps != null) text(c, gps, tx, y + 4 * line, txt);
        }
    }

    /** Biały tekst z czarnym obrysem – czytelny na każdym tle, jak w kamerach nasobnych. */
    private void text(Canvas c, String s, float x, float y, Paint p) {
        edge.setTextSize(p.getTextSize());
        edge.setTextAlign(p.getTextAlign());
        edge.setStrokeWidth(p.getTextSize() * 0.16f);
        c.drawText(s, x, y, edge);
        c.drawText(s, x, y, p);
    }

    /** Własny znak (żółty sześciokąt z obiektywem) – nie logo producenta. */
    void drawLogo(Canvas c, float x, float y, float s) {
        Bitmap cl = customLogo;
        if (cl != null) {
            c.drawBitmap(cl, null, new android.graphics.RectF(x, y, x + logoW(s), y + s), bmpPaint);
            return;
        }
        float cx = x + s / 2, cy = y + s / 2, r = s / 2;
        hex.reset();
        for (int i = 0; i < 6; i++) {
            double a = Math.PI / 3 * i + Math.PI / 6;
            float px = cx + (float) (Math.cos(a) * r), py = cy + (float) (Math.sin(a) * r);
            if (i == 0) hex.moveTo(px, py);
            else hex.lineTo(px, py);
        }
        hex.close();
        logo.setStyle(Paint.Style.STROKE);
        logo.setStrokeWidth(s * 0.11f);
        logo.setStrokeJoin(Paint.Join.ROUND);
        logo.setShadowLayer(2f, 0, 0, 0x88000000);
        c.drawPath(hex, logo);
        logo.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, s * 0.17f, logo);
        logo.setColor(Color.BLACK);
        c.drawCircle(cx + s * 0.05f, cy - s * 0.05f, s * 0.045f, logo);
        logo.setColor(0xFFF5C400);
    }
}
