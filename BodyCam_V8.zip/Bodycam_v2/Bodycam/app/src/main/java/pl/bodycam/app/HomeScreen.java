package pl.bodycam.app;

import android.Manifest;
import android.content.Context;
import android.graphics.Canvas;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

final class HomeScreen extends Screen {

    HomeScreen(MainActivity a) {
        super(a);
    }

    static final class LogoView extends View {
        private final Look look = new Look();

        LogoView(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight());
            look.drawLogo(c, (getWidth() - s) / 2f, (getHeight() - s) / 2f, s);
        }
    }

    @Override
    View view() {
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);
        LinearLayout col = Ui.col(a);
        col.setPadding(Ui.dp(22), Ui.dp(36), Ui.dp(22), Ui.dp(24));
        sv.addView(col);

        LinearLayout head = Ui.row(a);
        LogoView logo = new LogoView(a);
        head.addView(logo, Ui.lp(Ui.dp(46), Ui.dp(46), 0));
        LinearLayout ht = Ui.col(a);
        ht.setPadding(Ui.dp(14), 0, 0, 0);
        ht.addView(Ui.text(a, "BODYCAM", 26, Ui.TEXT, Ui.MONO));
        ht.addView(Ui.text(a, App.model(), 12, Ui.DIM, Ui.MONO));
        head.addView(ht);
        col.addView(head);
        col.addView(Ui.gap(a, 28));

        col.addView(tile("NAGRYWAJ", "Bodycam: nagrywanie z nakładką, tryb nocny i noktowizja. Nadaje podgląd na żywo.",
                true, () -> a.withPerms(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO},
                        () -> a.show(new BodycamScreen(a)))));
        col.addView(Ui.gap(a, 12));
        col.addView(tile("PODGLĄD", "Oglądaj czyjś bodycam na żywo z dźwiękiem. Wystarczy wpisać jego kod – działa przez internet z każdej sieci.",
                false, () -> a.show(new WatchScreen(a))));
        col.addView(Ui.gap(a, 12));
        col.addView(tile("USTAWIENIA", "Nakładka, numer urządzenia, dane funkcjonariusza, obraz, dźwięki, serwer.",
                false, () -> a.show(new SettingsScreen(a))));

        col.addView(Ui.gap(a, 26));
        TextView code = Ui.text(a, "KOD TWOJEGO BODYCAMA", 11, Ui.DIM, Ui.MONO);
        col.addView(code);
        TextView big = Ui.text(a, Link.pretty(App.code()), 30, Ui.ACC, Ui.MONO);
        big.setLetterSpacing(0.12f);
        col.addView(big);
        col.addView(Ui.text(a, "Podaj go osobie, która ma oglądać. Zmienisz go w ustawieniach.", 12, Ui.DIM, Ui.COND));
        return sv;
    }

    private View tile(String title, String sub, boolean main, Runnable r) {
        LinearLayout t = Ui.col(a);
        t.setPadding(Ui.dp(18), Ui.dp(18), Ui.dp(18), Ui.dp(18));
        t.setBackground(Ui.box(main ? Ui.ACC : Ui.PANEL_SOLID, main ? Ui.ACC : Ui.LINE, 10));
        TextView h = Ui.text(a, title, 20, main ? 0xFF111111 : Ui.TEXT, Ui.MONO);
        h.setLetterSpacing(0.08f);
        t.addView(h);
        TextView s = Ui.text(a, sub, 13, main ? 0xFF2A2A2A : Ui.DIM, Ui.COND);
        s.setPadding(0, Ui.dp(4), 0, 0);
        t.addView(s);
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        t.setGravity(Gravity.START);
        return t;
    }
}
