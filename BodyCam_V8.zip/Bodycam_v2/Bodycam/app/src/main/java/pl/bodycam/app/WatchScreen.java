package pl.bodycam.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

/** Podgląd cudzego bodycama: tylko oglądanie i słuchanie, bez sterowania. */
final class WatchScreen extends Screen {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private Link.Receiver rx;
    private Player player;
    private TextureView tv;
    private AspectFrame frame;
    private TextView top, info, muteBtn;
    private String code;
    private EditText manualIpField;
    private android.net.wifi.WifiManager.MulticastLock mlock;
    private volatile JSONObject st;
    private volatile long stAt;
    private volatile String conn = "";
    private long lastBytes, lastT;
    private int lastFps;

    WatchScreen(MainActivity a) {
        super(a);
    }

    /** Ramka zachowująca proporcje obrazu (pion albo poziom – zależnie od nadającego). */
    static final class AspectFrame extends FrameLayout {
        float ratio = 16f / 9f;

        AspectFrame(Context c) {
            super(c);
        }

        @Override
        protected void onMeasure(int ws, int hs) {
            int W = MeasureSpec.getSize(ws), H = MeasureSpec.getSize(hs);
            int w = W, h = Math.round(W / ratio);
            if (h > H) {
                h = H;
                w = Math.round(H * ratio);
            }
            super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
        }
    }

    @Override
    View view() {
        root = new FrameLayout(a);
        root.setBackgroundColor(Ui.BG);
        root.addView(entry());
        return root;
    }

    // ================================================================ wpisanie kodu

    private View entry() {
        ScrollView sv = new ScrollView(a);
        LinearLayout col = Ui.col(a);
        col.setPadding(Ui.dp(22), Ui.dp(30), Ui.dp(22), Ui.dp(22));
        sv.addView(col);
        TextView back = Ui.btn(a, "◄ WSTECZ");
        back.setOnClickListener(v -> a.home());
        col.addView(back, Ui.lp(-2, -2, 0));
        col.addView(Ui.gap(a, 22));
        col.addView(Ui.text(a, "PODGLĄD NA ŻYWO", 22, Ui.TEXT, Ui.MONO));
        col.addView(Ui.text(a, "Wpisz kod bodycama, który chcesz oglądać. Działa przez internet (LTE, 5G, dowolne Wi-Fi) – nie musicie być w tej samej sieci ani nic parować.", 13, Ui.DIM, Ui.COND));
        col.addView(Ui.gap(a, 18));
        EditText et = new EditText(a);
        et.setTextSize(28);
        et.setTypeface(Ui.MONO);
        et.setTextColor(Ui.ACC);
        et.setHint("XXXX-XXXX");
        et.setHintTextColor(0xFF3A3D42);
        et.setGravity(Gravity.CENTER);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setBackground(Ui.box(Ui.PANEL_SOLID, Ui.LINE, 8));
        et.setPadding(Ui.dp(10), Ui.dp(14), Ui.dp(10), Ui.dp(14));
        String last = App.s("lastwatch", "");
        if (!last.isEmpty()) et.setText(Link.pretty(last.split(",")[0]));
        col.addView(et);

        // --- sposób łączenia
        TextView cl = Ui.text(a, "POŁĄCZENIE", 11, Ui.DIM, Ui.MONO);
        cl.setPadding(0, Ui.dp(14), 0, Ui.dp(6));
        col.addView(cl);
        LinearLayout modes = Ui.row(a);
        String[] mn = {"AUTO", "SIEĆ / HOTSPOT", "INTERNET"};
        TextView[] mb = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int m = i;
            mb[i] = Ui.btn(a, mn[i]);
            mb[i].setTextSize(11);
            mb[i].setPadding(Ui.dp(4), Ui.dp(10), Ui.dp(4), Ui.dp(10));
            mb[i].setOnClickListener(v -> {
                App.put("conn", m);
                for (int k = 0; k < 3; k++) Ui.on(mb[k], k == m);
            });
            modes.addView(mb[i], Ui.lpm(0, -2, 1, i == 0 ? 0 : 3, 0, 0, 0));
        }
        for (int k = 0; k < 3; k++) Ui.on(mb[k], k == App.i("conn", 0));
        col.addView(modes);
        TextView ch = Ui.text(a, "AUTO – łączy się wszystkimi drogami naraz i bierze najszybszą: ta sama sieć Wi-Fi lub hotspot (najmniejsze opóźnienie), "
                + "bezpośrednio przez internet (P2P), a jak się nie da – przez serwer.", 12, Ui.DIM, Ui.COND);
        ch.setPadding(0, Ui.dp(6), 0, 0);
        col.addView(ch);
        EditText ip = new EditText(a);
        ip.setTextSize(15);
        ip.setTypeface(Ui.MONO);
        ip.setTextColor(Ui.TEXT);
        ip.setHint("IP bodycama (opcjonalnie, np. 192.168.1.23)");
        ip.setHintTextColor(0xFF4A4D52);
        ip.setSingleLine(true);
        ip.setText(App.s("manualip", ""));
        ip.setBackground(Ui.box(Ui.PANEL_SOLID, Ui.LINE, 8));
        ip.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        col.addView(ip, Ui.lpm(-1, -2, 0, 0, 8, 0, 0));
        manualIpField = ip;

        col.addView(Ui.gap(a, 12));
        TextView go = Ui.btn(a, "OGLĄDAJ");
        go.setTextSize(16);
        Ui.on(go, true);
        go.setOnClickListener(v -> {
            String c = Link.clean(et.getText().toString());
            if (c.length() < 6) {
                a.toast("Wpisz pełny kod");
                return;
            }
            App.put("manualip", ip.getText().toString().trim());
            remember(c);
            watch(c);
        });
        col.addView(go);

        if (!last.isEmpty()) {
            col.addView(Ui.gap(a, 22));
            col.addView(Ui.text(a, "OSTATNIO OGLĄDANE", 11, Ui.DIM, Ui.MONO));
            for (String c : last.split(",")) {
                if (c.isEmpty()) continue;
                TextView b = Ui.btn(a, Link.pretty(c));
                b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                b.setOnClickListener(v -> {
                    remember(c);
                    watch(c);
                });
                col.addView(b, Ui.lpm(-1, -2, 0, 0, 6, 0, 0));
            }
        }
        return sv;
    }

    private void remember(String c) {
        StringBuilder s = new StringBuilder(c);
        int n = 1;
        for (String o : App.s("lastwatch", "").split(","))
            if (!o.isEmpty() && !o.equals(c) && n++ < 5) s.append(',').append(o);
        App.put("lastwatch", s.toString());
    }

    // ================================================================ oglądanie

    private void watch(String c) {
        code = c;
        a.getWindow().getDecorView().clearFocus();
        root.removeAllViews();
        root.setBackgroundColor(Color.BLACK);

        frame = new AspectFrame(a);
        tv = new TextureView(a);
        frame.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        root.addView(frame, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        LinearLayout topBar = Ui.col(a);
        topBar.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(8));
        topBar.setBackground(Ui.box(0x99000000, 0, 0));
        LinearLayout tr = Ui.row(a);
        TextView back = Ui.btn(a, "◄");
        back.setOnClickListener(v -> stopWatch());
        tr.addView(back, Ui.lpm(Ui.dp(44), -2, 0, 0, 0, 8, 0));
        top = Ui.text(a, "", 14, Ui.TEXT, Ui.MONO);
        tr.addView(top, Ui.lp(0, -2, 1));
        topBar.addView(tr);
        info = Ui.text(a, "", 11, Ui.DIM, Ui.MONO);
        info.setPadding(0, Ui.dp(6), 0, 0);
        topBar.addView(info);
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout bot = Ui.row(a);
        bot.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(12));
        bot.setBackground(Ui.box(0x99000000, 0, 0));
        muteBtn = Ui.btn(a, "DŹWIĘK WŁ.");
        muteBtn.setOnClickListener(v -> {
            player.muted = !player.muted;
            muteBtn.setText(player.muted ? "DŹWIĘK WYŁ." : "DŹWIĘK WŁ.");
            Ui.on(muteBtn, player.muted);
        });
        TextView shot = Ui.btn(a, "ZRZUT EKRANU");
        shot.setOnClickListener(v -> snapshot());
        bot.addView(muteBtn, Ui.lpm(0, -2, 1, 0, 0, 4, 0));
        bot.addView(shot, Ui.lpm(0, -2, 1, 4, 0, 0, 0));
        root.addView(bot, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        player = new Player(new Player.Events() {
            @Override
            public void onSize(int w, int h) {
                ui.post(() -> {
                    frame.ratio = (float) w / h;
                    frame.requestLayout();
                });
            }

            @Override
            public void needKey() {
                Link.Receiver r = rx;
                if (r != null) r.requestKey();
            }
        });
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) {
                player.setSurface(new Surface(s));
                Link.Receiver r = rx;
                if (r != null) r.requestKey();
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s) {
                player.setSurface(null);
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture s) { }
        });

        try {   // odbiór rozgłoszeń w sieci Wi-Fi (wykrywanie bodycama)
            android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                mlock = wm.createMulticastLock("bodycam");
                mlock.acquire();
            }
        } catch (Exception ignored) { }
        rx = new Link.Receiver(new Link(c), Link.servers(App.server(), App.custom()), new Link.Receiver.Events() {
            @Override
            public void onVideo(boolean key, int seq, long pts, int w, int h, byte[] d, int off, int len) {
                player.video(key, seq, pts, w, h, d, off, len);
            }

            @Override
            public void onAudio(int seq, long pts, byte[] d, int off, int len) {
                player.audio(d, off, len);
            }

            @Override
            public void onStatus(JSONObject s) {
                st = s;
                stAt = System.currentTimeMillis();
            }

            @Override
            public void onState(String text, boolean connected) {
                conn = text;
            }
        }, App.i("conn", 0), App.s("manualip", ""));
        lastT = System.currentTimeMillis();
        tick();
    }

    private void tick() {
        if (rx == null) return;
        long now = System.currentTimeMillis();
        JSONObject s = st;
        StringBuilder t = new StringBuilder(Link.pretty(code));
        if (s == null) t.append("  · czekam na bodycam…");
        else if (s.optInt("on", 0) == 0) t.append("  · BODYCAM OFFLINE");
        else {
            t.append("  · ").append(s.optString("mode", ""));
            if (s.optInt("rec", 0) == 1) t.append("  ● REC");
        }
        top.setText(t);
        top.setTextColor(s != null && s.optInt("rec", 0) == 1 ? Ui.RED : Ui.TEXT);
        if (now - lastT >= 1000) {
            float sec = (now - lastT) / 1000f;
            long b = rx.bytes;
            int kbps = (int) ((b - lastBytes) * 8 / 1000 / sec);
            int fps = Math.round((player.fpsCount - lastFps) / sec);
            lastFps = player.fpsCount;
            lastBytes = b;
            lastT = now;
            StringBuilder i = new StringBuilder(conn);
            i.append(" · ").append(fps).append(" kl/s · ").append(kbps).append(" kb/s");
            long d = player.delayMs;
            if (d >= 0 && d < 30_000 && fps > 0) i.append(String.format(Locale.US, " · opóźn. ~%.1f s", d / 1000f));
            if (s != null && s.optInt("bat", -1) >= 0) i.append(" · bat ").append(s.optInt("bat", -1)).append('%');
            info.setText(i);
        }
        ui.postDelayed(this::tick, 300);
    }

    private void snapshot() {
        Bitmap b = tv.getBitmap();
        if (b == null) {
            a.toast("Brak obrazu");
            return;
        }
        new Thread(() -> {
            boolean ok = Store.photo(a, b);
            ui.post(() -> a.toast(ok ? "Zapisano: Obrazy › Bodycam" : "Nie udało się zapisać"));
        }).start();
    }

    private void releaseLock() {
        try { if (mlock != null && mlock.isHeld()) mlock.release(); } catch (Exception ignored) { }
        mlock = null;
    }

    private void stopWatch() {
        releaseLock();
        Link.Receiver r = rx;
        rx = null;
        if (r != null) new Thread(r::stop).start();
        if (player != null) player.stop();
        player = null;
        ui.removeCallbacksAndMessages(null);
        root.removeAllViews();
        root.setBackgroundColor(Ui.BG);
        root.addView(entry());
    }

    @Override
    boolean back() {
        if (rx != null) {
            stopWatch();
            return true;
        }
        return false;
    }

    @Override
    void onHide() {
        releaseLock();
        Link.Receiver r = rx;
        rx = null;
        if (r != null) new Thread(r::stop).start();
        if (player != null) player.stop();
        ui.removeCallbacksAndMessages(null);
    }
}
