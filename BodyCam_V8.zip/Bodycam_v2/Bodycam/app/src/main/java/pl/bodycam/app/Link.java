package pl.bodycam.app;

import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Łącze przez internet: oba telefony łączą się z publicznym serwerem pośredniczącym (MQTT po TLS)
 * i spotykają się "na kodzie". Kod wyznacza kanał i klucz szyfrowania (AES-GCM) – serwer ani nikt
 * bez kodu nie zobaczy obrazu. Działa przez LTE/5G i dowolne Wi-Fi, bez parowania i bez tej samej sieci.
 */
final class Link {

    static final String[][] SERVERS = {
            {"broker.emqx.io", "8883", "EMQX (UE)"},
            {"broker.hivemq.com", "8883", "HiveMQ (UE)"},
            {"test.mosquitto.org", "8886", "Mosquitto (UK)"},
    };

    static final byte T_VIDEO = 'V', T_AUDIO = 'A';
    private static final SecureRandom RND = new SecureRandom();
    private static final String ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    final String code;
    final String base;
    private final SecretKeySpec key;

    Link(String code) {
        this.code = clean(code);
        byte[] k = sha("bodycam-key|" + this.code);
        key = new SecretKeySpec(k, 0, 16, "AES");
        base = "bcv1/" + hex(sha("bodycam-topic|" + this.code), 12);
    }

    static String newCode() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 8; i++) s.append(ALPHA.charAt(RND.nextInt(ALPHA.length())));
        return s.toString();
    }

    static String clean(String c) {
        StringBuilder s = new StringBuilder();
        for (char ch : c.toUpperCase(java.util.Locale.ROOT).toCharArray())
            if ((ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')) s.append(ch == 'O' ? '0' : ch == 'I' ? '1' : ch);
        return s.toString();
    }

    static String pretty(String c) {
        c = clean(c);
        return c.length() == 8 ? c.substring(0, 4) + "-" + c.substring(4) : c;
    }

    byte[] seal(byte[] plain) {
        try {
            byte[] iv = new byte[12];
            RND.nextBytes(iv);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
            byte[] ct = c.doFinal(plain);
            byte[] out = new byte[12 + ct.length];
            System.arraycopy(iv, 0, out, 0, 12);
            System.arraycopy(ct, 0, out, 12, ct.length);
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    byte[] open(byte[] sealed) {
        if (sealed == null || sealed.length < 28) return null;
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, sealed, 0, 12));
            return c.doFinal(sealed, 12, sealed.length - 12);
        } catch (Exception e) {
            return null;
        }
    }

    /** Serwery w kolejności prób – obie strony próbują w tej samej kolejności, więc trafiają na ten sam. */
    static List<String[]> servers(int choice, String custom) {
        List<String[]> l = new ArrayList<>();
        if (choice == 4 && custom != null && custom.contains(":")) {
            String[] p = custom.trim().split(":");
            l.add(new String[]{p[0], p[1], custom});
            return l;
        }
        if (choice >= 1 && choice <= SERVERS.length) {
            l.add(SERVERS[choice - 1]);
            return l;
        }
        for (String[] s : SERVERS) l.add(s);
        return l;
    }

    static Mqtt dial(List<String[]> list, String clientId, String willTopic, byte[] will, Mqtt.Listener l) {
        for (String[] s : list) {
            try {
                int port = Integer.parseInt(s[1].trim());
                boolean tls = port != 1883;
                return Mqtt.connect(s[0].trim(), port, tls, clientId, willTopic, will, l, 8000);
            } catch (Exception ignored) { }
        }
        return null;
    }

    static byte[] sha(String s) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static String hex(byte[] b, int n) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < n; i++) s.append(String.format("%02x", b[i]));
        return s.toString();
    }

    static String cid() {
        return "bc" + Long.toHexString(RND.nextLong() & 0xFFFFFFFFFFFFL);
    }

    // ===================================================================================== NADAJNIK

    /**
     * Strona bodycama: nadaje jednocześnie przez sieć lokalną/hotspot, P2P i serwer – każdemu widzowi
     * najszybszą drogą, jaką ma. Przez serwer wysyła tylko, gdy jakiś widz nie ma lepszej drogi.
     */
    static final class Sender implements Mqtt.Listener, Direct.Sink {
        interface Events {
            void needKeyframe();
            void onState(String text);
            default void onNewViewer() { }
        }

        final Link link;
        private final Events ev;
        private final List<String[]> servers;
        private volatile Mqtt m;
        private volatile boolean running = true;
        private final Map<String, Object[]> viewers = new HashMap<>();   // id -> {lastSeen, via}
        private int vSeq = 0, aSeq = 0;
        private volatile boolean dropToKey = false;
        private volatile long lastDrop = 0;
        final JSONObject status = new JSONObject();
        volatile String server = "";
        final Direct.Server direct;

        Sender(Link l, List<String[]> servers, Events e) {
            link = l;
            ev = e;
            this.servers = servers;
            direct = new Direct.Server(l.base, this, () -> {
                lastDrop = System.currentTimeMillis();
                e.needKeyframe();
            });
            Thread t = new Thread(this::loop, "link-tx");
            t.setDaemon(true);
            t.start();
        }

        private void loop() {
            int backoff = 1000;
            while (running) {
                byte[] off = link.seal(statusBytes(false));
                Mqtt c = servers.isEmpty() ? null : dial(servers, cid(), link.base + "/s", off, this);
                if (c == null) {
                    // bez internetu działa dalej sieć lokalna / hotspot
                    long until = System.currentTimeMillis() + backoff;
                    while (running && System.currentTimeMillis() < until) {
                        sendStatusDirect();
                        ev.onState("bez serwera · " + describe());
                        sleep(2000);
                    }
                    backoff = Math.min(20000, backoff * 2);
                    continue;
                }
                backoff = 1000;
                m = c;
                server = c.server;
                c.subscribe(link.base + "/c");
                while (running && c.alive()) {
                    byte[] s = link.seal(statusBytes(true));
                    if (s != null) c.publish(link.base + "/s", s, true, false);
                    sendStatusDirect();
                    ev.onState("online · " + describe());
                    for (int i = 0; i < (viewers() > 0 ? 4 : 10) && running && c.alive(); i++) sleep(500);
                }
                m = null;
            }
        }

        private void sendStatusDirect() {
            byte[] s = link.seal(statusBytes(true));
            if (s != null) direct.send(Direct.K_STATUS, s, false, false);
        }

        String describe() {
            int n = viewers();
            StringBuilder b = new StringBuilder();
            b.append(n).append(n == 1 ? " ogląda" : " ogląda");
            int lan = direct.tcp.size(), p2p = direct.udpPeers.size();
            if (lan > 0) b.append(" · LAN ").append(lan);
            if (p2p > 0) b.append(" · P2P ").append(p2p);
            if (mqttNeeded()) b.append(" · serwer");
            return b.toString();
        }

        private byte[] statusBytes(boolean on) {
            try {
                JSONObject j;
                synchronized (status) { j = new JSONObject(status.toString()); }
                j.put("on", on ? 1 : 0);
                j.put("t", System.currentTimeMillis());
                String ep = direct.publicEp();
                if (ep != null) j.put("p2p", ep);
                return j.toString().getBytes(StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "{}".getBytes(StandardCharsets.UTF_8);
            }
        }

        synchronized int viewers() {
            long now = System.currentTimeMillis();
            Iterator<Map.Entry<String, Object[]>> it = viewers.entrySet().iterator();
            while (it.hasNext()) if (now - (Long) it.next().getValue()[0] > 12_000) it.remove();
            return viewers.size();
        }

        synchronized boolean mqttNeeded() {
            if (m == null) return false;
            long now = System.currentTimeMillis();
            for (Object[] v : viewers.values())
                if (now - (Long) v[0] < 12_000 && ("mqtt".equals(v[1]) || "any".equals(v[1]))) return true;
            return false;
        }

        boolean watching() {
            return viewers() > 0;
        }

        /** Łącze się zapycha – czas obniżyć jakość. */
        boolean congested() {
            Mqtt c = m;
            if (c != null && mqttNeeded() && c.queuedBytes() > 120_000) return true;
            if (direct.congested()) return true;
            return System.currentTimeMillis() - lastDrop < 2500;
        }

        private void hello(byte[] payload, String defVia, Object peer) {
            byte[] p = link.open(payload);
            if (p == null) return;
            try {
                JSONObject j = new JSONObject(new String(p, StandardCharsets.UTF_8));
                String id = j.optString("id");
                String via = j.optString("via", defVia);
                boolean isNew;
                synchronized (this) {
                    isNew = !viewers.containsKey(id);
                    viewers.put(id, new Object[]{System.currentTimeMillis(), via.isEmpty() ? defVia : via});
                }
                String ep = j.optString("p2p", "");
                if (!ep.isEmpty()) direct.punch(ep);
                if (peer != null) direct.setWanted(peer, via.isEmpty() || via.equals("any") || via.equals(defVia));
                if (isNew || j.optInt("key") == 1) ev.needKeyframe();
                if (isNew) ev.onNewViewer();
                if (isNew && peer != null) {
                    byte[] s = link.seal(statusBytes(true));
                    if (s != null) direct.reply(peer, Direct.K_STATUS, s);
                }
            } catch (Exception ignored) { }
        }

        @Override
        public void onMessage(String topic, byte[] payload) {
            hello(payload, "mqtt", null);
        }

        @Override
        public void onPacket(byte kind, byte[] sealed, String via, Object peer) {
            if (kind == Direct.K_CTL) hello(sealed, via, peer);
        }

        @Override
        public void onLost() { }

        /** Pakiet wideo H.264 (Annex B). Gdy łącze nie nadąża – gubimy do następnej klatki kluczowej. */
        void video(byte[] h264, boolean key, long ptsMs, int w, int h) {
            ByteBuffer b = ByteBuffer.allocate(18 + h264.length);
            b.put(T_VIDEO).put((byte) (key ? 1 : 0)).putInt(vSeq++).putLong(ptsMs).putShort((short) w).putShort((short) h);
            b.put(h264);
            byte[] s = link.seal(b.array());
            if (s == null) return;
            direct.send(Direct.K_VIDEO, s, true, key);
            Mqtt c = m;
            if (c == null || !mqttNeeded()) return;
            if (dropToKey && !key) return;
            boolean ok = c.publish(link.base + "/v", s, false, true);
            if (!ok) {
                dropToKey = true;
                lastDrop = System.currentTimeMillis();
                ev.needKeyframe();
            } else if (key) dropToKey = false;
        }

        void audio(byte[] adpcm, long ptsMs) {
            ByteBuffer b = ByteBuffer.allocate(13 + adpcm.length);
            b.put(T_AUDIO).putInt(aSeq++).putLong(ptsMs).put(adpcm);
            byte[] s = link.seal(b.array());
            if (s == null) return;
            direct.send(Direct.K_AUDIO, s, true, false);
            Mqtt c = m;
            if (c != null && mqttNeeded()) c.publish(link.base + "/a", s, false, true);
        }

        void stop() {
            running = false;
            direct.stop();
            Mqtt c = m;
            if (c != null) {
                byte[] off = link.seal(statusBytes(false));
                if (off != null) c.publish(link.base + "/s", off, true, false);
                sleep(150);
                c.close();
            }
        }
    }

    // ===================================================================================== ODBIORNIK

    /**
     * Strona podglądu: łączy się wszystkimi dozwolonymi drogami naraz i bierze obraz z najszybszej:
     * LAN/hotspot > P2P > serwer. Przełącza się sama, bez przerywania.
     */
    static final class Receiver implements Mqtt.Listener, Direct.Sink {
        interface Events {
            void onVideo(boolean key, int seq, long ptsMs, int w, int h, byte[] data, int off, int len);
            void onAudio(int seq, long ptsMs, byte[] data, int off, int len);
            void onStatus(JSONObject s);
            void onState(String text, boolean connected);
        }

        final Link link;
        private final Events ev;
        private final List<String[]> servers;
        private final String id = cid();
        private volatile Mqtt m;
        private volatile boolean running = true;
        private volatile boolean wantKey = false;
        volatile long bytes = 0;
        final Direct.Client direct;
        private final boolean useServer;
        private final long[] lastVideo = new long[4];   // 1 serwer, 2 P2P, 3 LAN
        volatile String serverState = "";

        /** mode: 0 = wszystko, 1 = tylko sieć lokalna/hotspot, 2 = tylko internet. */
        Receiver(Link l, List<String[]> servers, Events e, int mode, String manualIp) {
            link = l;
            ev = e;
            this.servers = servers;
            useServer = mode != 1;
            direct = new Direct.Client(l.base, this, mode != 2, mode != 1, manualIp);
            if (useServer) {
                Thread t = new Thread(this::loop, "link-rx");
                t.setDaemon(true);
                t.start();
            }
            Thread h = new Thread(this::helloLoop, "hello");
            h.setDaemon(true);
            h.start();
        }

        private void loop() {
            int backoff = 1000;
            while (running) {
                serverState = "serwer: łączenie…";
                Mqtt c = dial(servers, cid(), null, null, this);
                if (c == null) {
                    serverState = "serwer: brak połączenia";
                    sleep(backoff);
                    backoff = Math.min(15000, backoff * 2);
                    continue;
                }
                backoff = 1000;
                m = c;
                c.subscribe(link.base + "/s", link.base + "/v", link.base + "/a");
                serverState = "serwer " + c.server;
                while (running && c.alive()) sleep(300);
                m = null;
            }
        }

        private void helloLoop() {
            long lastMqtt = 0, lastStun = System.currentTimeMillis();
            while (running) {
                long now = System.currentTimeMillis();
                boolean key = wantKey;
                wantKey = false;
                int bst = best();
                if (bst != chosen) {          // zmiana drogi – od razu powiedz bodycamowi i poproś o klatkę kluczową
                    chosen = bst;
                    key = true;
                }
                byte[] h = helloBytes(key);
                if (h != null) direct.sendCtl(h);
                Mqtt c = m;
                if (c != null && h != null && (now - lastMqtt > 4000 || key)) {
                    c.publish(link.base + "/c", h, false, false);
                    lastMqtt = now;
                }
                if (now - lastStun > 20000) {
                    direct.restun();
                    lastStun = now;
                }
                ev.onState(describe(), best() > 0 || c != null);
                for (int i = 0; i < 10 && running && !wantKey; i++) sleep(100);
            }
        }

        private byte[] helloBytes(boolean key) {
            try {
                JSONObject j = new JSONObject();
                j.put("id", id);
                j.put("key", key ? 1 : 0);
                int b = chosen;
                j.put("via", b == 3 ? "lan" : b == 2 ? "p2p" : b == 1 ? "mqtt" : "any");   // any = jeszcze nie wiem – ślij wszędzie
                String ep = direct.publicEp();
                if (ep != null) j.put("p2p", ep);
                return link.seal(j.toString().getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                return null;
            }
        }

        // --- ocena dróg: 1 serwer, 2 P2P, 3 LAN
        private final long[] lastKey = new long[4], badUntil = new long[4], gapAt = new long[4];
        private final int[] lastSeqP = {-1, -1, -1, -1}, gaps = new int[4];
        private volatile int chosen = 0;

        /** Najlepsza działająca droga: dostarczyła klatkę kluczową w ostatnich 5 s i nie gubi pakietów. */
        int best() {
            long now = System.currentTimeMillis();
            for (int i = 3; i >= 2; i--)
                if (now - lastKey[i] < 5000 && now >= badUntil[i]) return i;
            if (now - lastVideo[1] < 5000 || m != null) return 1;
            return 0;
        }

        String describe() {
            int b = chosen;
            String via = b == 3 ? "LAN " + (direct.lanAddr == null ? "" : direct.lanAddr)
                    : b == 2 ? "P2P (bezpośrednio)" : b == 1 ? "przez serwer" : "czekam na obraz";
            StringBuilder s = new StringBuilder(via);
            if (b != 3 && direct.lanUp()) s.append(" · LAN połączony");
            if (System.currentTimeMillis() < badUntil[2]) s.append(" · P2P słabe – pominięte");
            if (useServer && b != 1) s.append(" · ").append(serverState);
            return s.toString();
        }

        void requestKey() {
            wantKey = true;
        }

        @Override
        public void onMessage(String topic, byte[] payload) {
            String k = topic.substring(topic.length() - 1);
            handle(k.charAt(0), payload, 1);
        }

        @Override
        public void onPacket(byte kind, byte[] sealed, String via, Object peer) {
            if (kind == Direct.K_PUNCH || kind == Direct.K_CTL) return;
            handle((char) kind, sealed, via.equals("lan") ? 3 : 2);
        }

        @Override
        public void onLost() { }

        private void handle(char kind, byte[] payload, int pri) {
            bytes += payload.length;
            byte[] p = link.open(payload);
            if (p == null) return;
            if (kind == 's') {
                try {
                    JSONObject j = new JSONObject(new String(p, StandardCharsets.UTF_8));
                    String ep = j.optString("p2p", "");
                    if (!ep.isEmpty()) direct.camEndpoint(ep);
                    ev.onStatus(j);
                } catch (Exception ignored) { }
                return;
            }
            long now = System.currentTimeMillis();
            ByteBuffer b = ByteBuffer.wrap(p);
            byte t = b.get();
            if (t == T_VIDEO && p.length > 18) {
                boolean key = b.get() == 1;
                int seq = b.getInt();
                long pts = b.getLong();
                int w = b.getShort() & 0xFFFF, h = b.getShort() & 0xFFFF;
                lastVideo[pri] = now;
                if (key) lastKey[pri] = now;
                // gubienie pakietów na oglądanej drodze P2P (UDP) -> pomijamy ją na minutę
                if (pri == 2 && chosen == 2 && lastSeqP[2] >= 0 && seq != lastSeqP[2] + 1 && !key) {
                    if (now - gapAt[2] > 10_000) gaps[2] = 0;
                    gapAt[2] = now;
                    if (++gaps[2] >= 3) {
                        badUntil[2] = now + 60_000;
                        gaps[2] = 0;
                        wantKey = true;
                    }
                }
                lastSeqP[pri] = seq;
                int c = chosen;
                if (c != 0 && pri != c) return;               // obraz tylko z wybranej drogi
                ev.onVideo(key, seq, pts, w, h, p, 18, p.length - 18);
            } else if (t == T_AUDIO && p.length > 13) {
                int c = chosen;
                if (c != 0 && pri != c) return;
                int seq = b.getInt();
                long pts = b.getLong();
                ev.onAudio(seq, pts, p, 13, p.length - 13);
            }
        }

        void stop() {
            running = false;
            direct.stop();
            Mqtt c = m;
            if (c != null) c.close();
        }
    }

    static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) { }
    }
}
