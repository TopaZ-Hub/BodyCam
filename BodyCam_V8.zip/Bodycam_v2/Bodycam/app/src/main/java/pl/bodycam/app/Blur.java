package pl.bodycam.app;

/**
 * Mocne rozmycie owalnego obszaru (głowy) bezpośrednio w pikselach klatki – trafia do nagrania,
 * podglądu na żywo i na ekran. Średnie z bloków + płynne przejścia między nimi + miękka krawędź.
 */
final class Blur {

    static void apply(int[] px, int w, int h, float[][] boxes) {
        for (float[] b : boxes) one(px, w, h, b);
    }

    private static void one(int[] px, int w, int h, float[] b) {
        int x0 = Math.max(0, (int) b[0]), y0 = Math.max(0, (int) b[1]);
        int x1 = Math.min(w - 1, (int) b[2]), y1 = Math.min(h - 1, (int) b[3]);
        int bw = x1 - x0 + 1, bh = y1 - y0 + 1;
        if (bw < 6 || bh < 6) return;
        int bs = Math.max(6, Math.min(bw, bh) / 7);                    // rozmiar bloku
        int gw = (bw + bs - 1) / bs, gh = (bh + bs - 1) / bs;
        int[] gr = new int[gw * gh], gg = new int[gw * gh], gb = new int[gw * gh];
        for (int gy = 0; gy < gh; gy++) {
            for (int gx = 0; gx < gw; gx++) {
                long r = 0, g = 0, bb = 0;
                int n = 0;
                int ys = y0 + gy * bs, ye = Math.min(y1 + 1, ys + bs), xs = x0 + gx * bs, xe = Math.min(x1 + 1, xs + bs);
                for (int y = ys; y < ye; y += 2) {
                    int row = y * w;
                    for (int x = xs; x < xe; x += 2) {
                        int c = px[row + x];
                        r += (c >> 16) & 255;
                        g += (c >> 8) & 255;
                        bb += c & 255;
                        n++;
                    }
                }
                int i = gy * gw + gx;
                if (n == 0) n = 1;
                gr[i] = (int) (r / n);
                gg[i] = (int) (g / n);
                gb[i] = (int) (bb / n);
            }
        }
        float cx = (x0 + x1) / 2f, cy = (y0 + y1) / 2f, rx = bw / 2f, ry = bh / 2f;
        for (int y = y0; y <= y1; y++) {
            float dy = (y - cy) / ry;
            float fy = (y - y0) / (float) bs - 0.5f;
            int iy = Math.max(0, Math.min(gh - 1, (int) Math.floor(fy)));
            int iy2 = Math.min(gh - 1, iy + 1);
            float ty = Math.max(0, Math.min(1, fy - iy));
            int row = y * w;
            for (int x = x0; x <= x1; x++) {
                float dx = (x - cx) / rx;
                float d = dx * dx + dy * dy;
                if (d > 1f) continue;
                float fx = (x - x0) / (float) bs - 0.5f;
                int ix = Math.max(0, Math.min(gw - 1, (int) Math.floor(fx)));
                int ix2 = Math.min(gw - 1, ix + 1);
                float tx = Math.max(0, Math.min(1, fx - ix));
                int a = iy * gw + ix, bI = iy * gw + ix2, c = iy2 * gw + ix, e = iy2 * gw + ix2;
                float r = lerp(lerp(gr[a], gr[bI], tx), lerp(gr[c], gr[e], tx), ty);
                float g = lerp(lerp(gg[a], gg[bI], tx), lerp(gg[c], gg[e], tx), ty);
                float bl = lerp(lerp(gb[a], gb[bI], tx), lerp(gb[c], gb[e], tx), ty);
                float al = d > 0.8f ? (1f - d) / 0.2f : 1f;              // miękka krawędź owalu
                int o = px[row + x];
                int orr = (o >> 16) & 255, og = (o >> 8) & 255, ob = o & 255;
                int nr = (int) (orr + (r - orr) * al), ng = (int) (og + (g - og) * al), nb = (int) (ob + (bl - ob) * al);
                px[row + x] = 0xFF000000 | nr << 16 | ng << 8 | nb;
            }
        }
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
}
