package pl.bodycam.app;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Range;
import android.util.Rational;
import android.util.Size;

import java.nio.ByteBuffer;
import java.util.Collections;

/**
 * Tylny aparat przez Camera2. Daje surowe klatki YUV do własnej obróbki.
 * Szeroki kąt: najszerszy obiektyw / zoom < 1× (ultraszeroki w Samsungach), stabilizacja obrazu.
 * Noc: ręczny długi czas naświetlania i maksymalna czułość, gdy telefon na to pozwala.
 */
final class Cam {

    interface FrameCb { void onFrame(byte[] nv21, int w, int h); }

    private final CameraManager cm;
    private HandlerThread th;
    private Handler bg;
    private CameraDevice dev;
    private CameraCaptureSession ses;
    private ImageReader reader;
    private CameraCharacteristics ch;
    private volatile boolean closing;
    private FrameCb cb;
    private byte[] nv;

    int width, height, sensorOr = 90;
    volatile int mode = Proc.DAY;
    volatile boolean torch = false, wide = true;
    volatile float ev = 0;
    float minZoom = 1f;
    String error;

    Cam(Context c) {
        cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
    }

    /** Tylny aparat o najkrótszej ogniskowej (najszerszy kąt). */
    private String pickBack() throws Exception {
        String best = null;
        float bestF = 1e9f;
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics c = cm.getCameraCharacteristics(id);
            Integer f = c.get(CameraCharacteristics.LENS_FACING);
            if (f == null || f != CameraMetadata.LENS_FACING_BACK) continue;
            if (torch) {   // latarka włączona – tylko obiektyw, który ma lampę
                Boolean fl = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (fl == null || !fl) continue;
            }
            float[] fl = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
            float v = fl != null && fl.length > 0 ? fl[0] : 100;
            if (best == null) { best = id; bestF = v; continue; }  // pierwszy tylny = główny (logiczny)
            if (wide && v < bestF * 0.8f && !hasZoomBelow1(cm.getCameraCharacteristics(best))) { best = id; bestF = v; }
        }
        if (best == null && torch) {      // żaden tylny z lampą – bierzemy jakikolwiek
            boolean t = torch;
            torch = false;
            best = pickBack();
            torch = t;
        }
        if (best == null) best = cm.getCameraIdList()[0];
        return best;
    }

    private String fallbackId;

    /** Gdy bieżący obiektyw nie ma lampy: zapal lampę innego aparatu (działa na wielu telefonach). */
    boolean torchFallback(boolean on) {
        try {
            if (!on) {
                if (fallbackId != null) cm.setTorchMode(fallbackId, false);
                fallbackId = null;
                return true;
            }
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Boolean fl = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer f = c.get(CameraCharacteristics.LENS_FACING);
                if (fl != null && fl && f != null && f == CameraMetadata.LENS_FACING_BACK) {
                    cm.setTorchMode(id, true);
                    fallbackId = id;
                    return true;
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    private static boolean hasZoomBelow1(CameraCharacteristics c) {
        if (Build.VERSION.SDK_INT < 30) return false;
        Range<Float> r = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
        return r != null && r.getLower() < 0.99f;
    }

    @SuppressWarnings("MissingPermission")
    void open(int maxW, FrameCb frameCb) {
        close();
        closing = false;
        cb = frameCb;
        th = new HandlerThread("cam");
        th.start();
        bg = new Handler(th.getLooper());
        try {
            String id = pickBack();
            ch = cm.getCameraCharacteristics(id);
            Integer or = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
            sensorOr = or == null ? 90 : or;
            minZoom = 1f;
            if (Build.VERSION.SDK_INT >= 30) {
                Range<Float> zr = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
                if (zr != null) minZoom = Math.max(0.5f, zr.getLower());
            }
            StreamConfigurationMap map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size best = null;
            Size[] sizes = map == null ? new Size[0] : map.getOutputSizes(ImageFormat.YUV_420_888);
            for (Size s : sizes) {   // 16:9 nie większy niż maxW
                if (s.getWidth() * 9 != s.getHeight() * 16 || s.getWidth() > maxW) continue;
                if (best == null || s.getWidth() > best.getWidth()) best = s;
            }
            if (best == null) for (Size s : sizes) {
                if (s.getWidth() > maxW) continue;
                if (best == null || s.getWidth() * s.getHeight() > best.getWidth() * best.getHeight()) best = s;
            }
            width = best != null ? best.getWidth() : 1280;
            height = best != null ? best.getHeight() : 720;
            reader = ImageReader.newInstance(width, height, ImageFormat.YUV_420_888, 3);
            reader.setOnImageAvailableListener(this::onImage, bg);
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice d) {
                    if (closing) { d.close(); return; }
                    dev = d;
                    try {
                        d.createCaptureSession(Collections.singletonList(reader.getSurface()), new CameraCaptureSession.StateCallback() {
                            @Override
                            public void onConfigured(CameraCaptureSession s) {
                                if (closing) return;
                                ses = s;
                                update();
                            }

                            @Override
                            public void onConfigureFailed(CameraCaptureSession s) {
                                error = "Nie udało się uruchomić aparatu";
                            }
                        }, bg);
                    } catch (Exception e) {
                        error = "Błąd aparatu";
                    }
                }

                @Override
                public void onDisconnected(CameraDevice d) { d.close(); }

                @Override
                public void onError(CameraDevice d, int e) {
                    error = "Aparat zajęty przez inną aplikację";
                    d.close();
                }
            }, bg);
        } catch (Exception e) {
            error = "Brak dostępu do aparatu";
        }
    }

    boolean manual() {
        if (ch == null) return false;
        int[] caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps == null) return false;
        for (int c : caps) if (c == CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) return true;
        return false;
    }

    boolean hasFlash() {
        Boolean f = ch == null ? null : ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
        return f != null && f;
    }

    void update() {
        CameraDevice d = dev;
        CameraCaptureSession s = ses;
        if (d == null || s == null || closing || ch == null) return;
        try {
            CaptureRequest.Builder b = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
            b.set(CaptureRequest.FLASH_MODE, torch ? CaptureRequest.FLASH_MODE_TORCH : CaptureRequest.FLASH_MODE_OFF);
            if (Build.VERSION.SDK_INT >= 30 && wide && minZoom < 0.99f)
                b.set(CaptureRequest.CONTROL_ZOOM_RATIO, minZoom);
            int[] vs = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
            if (vs != null) for (int v : vs)
                if (v == CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
                    b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON);
            int[] ois = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
            if (ois != null) for (int v : ois)
                if (v == CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)
                    b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON);

            Range<Integer>[] ranges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (mode == Proc.DAY || !manual()) {
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                Range<Integer> ec = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
                Rational st = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP);
                if (ec != null && st != null && st.floatValue() > 0) {
                    float want = mode == Proc.DAY ? ev : 2f + ev;  // w nocy bez ręcznego trybu – maksymalnie jasno
                    int idx = Math.round(want / st.floatValue());
                    b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, Math.max(ec.getLower(), Math.min(ec.getUpper(), idx)));
                }
                if (ranges != null) {
                    Range<Integer> pick = null;
                    for (Range<Integer> r : ranges) {
                        if (mode == Proc.DAY) { // płynne 30 kl./s, ale pozwól zwolnić do 15 przy słabym świetle
                            if (r.getUpper() == 30 && (pick == null || r.getLower() < pick.getLower()) && r.getLower() >= 10) pick = r;
                        } else if (pick == null || r.getLower() < pick.getLower()) pick = r;
                    }
                    if (pick != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pick);
                }
            } else {
                Range<Long> er = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
                Range<Integer> ir = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
                Integer maxAnalog = ch.get(CameraCharacteristics.SENSOR_MAX_ANALOG_SENSITIVITY);
                // NOC: ~1/20 s (płynny ruch), NOKTO: ~1/10 s (więcej światła). EV przesuwa czas.
                double base = mode == Proc.NV ? 1 / 10.0 : 1 / 20.0;
                long exp = (long) (base * Math.pow(2, ev * 0.75) * 1e9);
                exp = Math.max(1_000_000L, Math.min(250_000_000L, exp));
                if (er != null) exp = Math.max(er.getLower(), Math.min(er.getUpper(), exp));
                int iso = ir != null ? ir.getUpper() : 3200;
                if (mode == Proc.NIGHT && maxAnalog != null && maxAnalog > 0) iso = Math.min(iso, Math.max(maxAnalog * 2, 800));
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp);
                b.set(CaptureRequest.SENSOR_SENSITIVITY, iso);
                b.set(CaptureRequest.SENSOR_FRAME_DURATION, Math.max(exp, 33_333_333L));
            }
            if (mode != Proc.DAY) {
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY);
                b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF);
            }
            s.setRepeatingRequest(b.build(), null, bg);
        } catch (Exception ignored) { }
    }

    private void onImage(ImageReader r) {
        Image img = r.acquireLatestImage();
        if (img == null) return;
        try {
            int w = img.getWidth(), h = img.getHeight();
            if (nv == null || nv.length != w * h * 3 / 2) nv = new byte[w * h * 3 / 2];
            toNv21(img, nv, w, h);
            img.close();
            img = null;
            if (cb != null) cb.onFrame(nv, w, h);
        } catch (Exception ignored) {
        } finally {
            if (img != null) img.close();
        }
    }

    private static void toNv21(Image img, byte[] out, int w, int h) {
        Image.Plane[] p = img.getPlanes();
        ByteBuffer y = p[0].getBuffer(), u = p[1].getBuffer(), v = p[2].getBuffer();
        int yRow = p[0].getRowStride();
        if (yRow == w) y.get(out, 0, Math.min(w * h, y.remaining()));
        else for (int r = 0; r < h; r++) {
            y.position(r * yRow);
            y.get(out, r * w, w);
        }
        int uvRow = p[1].getRowStride(), uvPix = p[1].getPixelStride();
        int o = w * h;
        for (int r = 0; r < h / 2; r++) {
            for (int c = 0; c < w / 2; c++) {
                int i = r * uvRow + c * uvPix;
                out[o++] = v.get(i);
                out[o++] = u.get(i);
            }
        }
    }

    void close() {
        closing = true;
        torchFallback(false);
        try { if (ses != null) ses.close(); } catch (Exception ignored) { }
        ses = null;
        try { if (dev != null) dev.close(); } catch (Exception ignored) { }
        dev = null;
        try { if (reader != null) reader.close(); } catch (Exception ignored) { }
        reader = null;
        if (th != null) {
            th.quitSafely();
            th = null;
        }
    }
}
