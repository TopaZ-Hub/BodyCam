package pl.bodycam.app;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Zapis nagrań i zdjęć prosto do galerii (Filmy/Bodycam, Obrazy/Bodycam). */
final class Store {

    static final class Video {
        Uri uri;
        ParcelFileDescriptor pfd;
        File file;
        String name;
    }

    static String stamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }

    static Video newVideo(Context c) {
        Video v = new Video();
        v.name = "BODYCAM_" + stamp() + ".mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Video.Media.DISPLAY_NAME, v.name);
                cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                cv.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Bodycam");
                cv.put(MediaStore.Video.Media.IS_PENDING, 1);
                v.uri = c.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
                if (v.uri != null) {
                    v.pfd = c.getContentResolver().openFileDescriptor(v.uri, "rw");
                    if (v.pfd != null) return v;
                }
            } catch (Exception ignored) { }
        }
        File dir = c.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (dir == null) dir = c.getFilesDir();
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        v.uri = null;
        v.pfd = null;
        v.file = new File(dir, v.name);
        return v;
    }

    static void finish(Context c, Video v, boolean ok) {
        try { if (v.pfd != null) v.pfd.close(); } catch (Exception ignored) { }
        if (v.uri != null) {
            try {
                if (ok) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Video.Media.IS_PENDING, 0);
                    c.getContentResolver().update(v.uri, cv, null, null);
                } else c.getContentResolver().delete(v.uri, null, null);
            } catch (Exception ignored) { }
        } else if (!ok && v.file != null) {
            //noinspection ResultOfMethodCallIgnored
            v.file.delete();
        }
    }

    static boolean photo(Context c, Bitmap b) {
        try {
            String name = "BODYCAM_" + stamp() + ".jpg";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Bodycam");
                Uri u = c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (u == null) return false;
                try (OutputStream os = c.getContentResolver().openOutputStream(u)) {
                    if (os == null) return false;
                    b.compress(Bitmap.CompressFormat.JPEG, 92, os);
                }
                return true;
            }
            File dir = c.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (dir == null) return false;
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            try (OutputStream os = new java.io.FileOutputStream(new File(dir, name))) {
                b.compress(Bitmap.CompressFormat.JPEG, 92, os);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
