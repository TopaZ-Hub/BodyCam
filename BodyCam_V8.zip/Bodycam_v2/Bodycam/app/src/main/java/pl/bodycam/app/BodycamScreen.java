package pl.bodycam.app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

final class BodycamScreen extends Screen {

    private static final String[] MODES = {"AUTO", "DZIEŃ", "NOC", "NOKTO"};

    private final Cam cam;
    private final Proc proc = new Proc();
    private final Frame.Pool pool = new Frame.Pool();
    private final Sound sound;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Adpcm adpcm = new Adpcm();
    private Mic mic;
    private Link.Sender tx;
    private volatile Streamer streamer;
    private volatile Recorder recorder;
    private Store.Video video;
    private long recStart, lastReminder, lastWatch;
    private volatile int rot = 90;
    private volatile boolean dark, livePending;
    private boolean started;

    private int userMode = 0;           // 0 AUTO, 1 DZIEŃ, 2 NOC, 3 NOKTO
    private volatile int autoMode = Proc.DAY;
    private long autoSince;
    private int autoWant = -1;

    private LiveView live;
    private TextView[] modeBtn = new TextView[4];
    private TextView status, recBadge, evText, torchBtn, wideBtn, txText, txBtn, blurBtn;
    private Faces faces;
    private TextView bannerView;
    private final Runnable hideBanner = () -> { if (bannerView != null) bannerView.setVisibility(View.GONE); };

    private void banner(String t) {
        ui.post(() -> {
            if (bannerView == null) return;
            bannerView.setText(t);
            bannerView.setTextColor(t.startsWith("●") ? Ui.RED : 0xFFF5C400);
            bannerView.setVisibility(View.VISIBLE);
            ui.removeCallbacks(hideBanner);
            ui.postDelayed(hideBanner, 2500);
        });
    }
    private RecButton recBtn;
    private View darkView;
    private LocationManager lm;
    private LocationListener ll;

    BodycamScreen(MainActivity a) {
        super(a);
        cam = new Cam(a);
        sound = Sound.get(a);
        cam.wide = App.wide();
        userMode = App.i("umode", 0);
    }

    // ================================================================ widok

    final class LiveView extends View {
        private final Look look = new Look();
        private Frame cur;

        LiveView(Context c) {
            super(c);
            setBackgroundColor(Color.BLACK);
        }

        void set(Frame f) {
            if (cur != null) cur.release();
            cur = f;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            Frame f = cur;
            if (f == null) return;
            int[] o = Look.outSize(f.bmp.getWidth(), f.bmp.getHeight(), rot);
            float sc = Math.min((float) getWidth() / o[0], (float) getHeight() / o[1]);
            float dw = o[0] * sc, dh = o[1] * sc;
            look.draw(c, f.bmp, f.time, (getWidth() - dw) / 2f, (getHeight() - dh) / 2f, dw, dh, rot, recorder != null);
        }
    }

    static final class RecButton extends View {
        boolean rec;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        RecButton(Context c) {
            super(c);
            setClickable(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()), cx = getWidth() / 2f, cy = getHeight() / 2f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.07f);
            p.setColor(0xFFECEAE4);
            c.drawCircle(cx, cy, s * 0.44f, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.RED);
            if (rec) {
                float h = s * 0.2f;
                c.drawRoundRect(new RectF(cx - h, cy - h, cx + h, cy + h), s * 0.05f, s * 0.05f, p);
            } else c.drawCircle(cx, cy, s * 0.34f, p);
        }
    }

    @Override
    View view() {
        FrameLayout root = new FrameLayout(a) {
            @Override
            public boolean onInterceptTouchEvent(android.view.MotionEvent e) {
                lastTouch = System.currentTimeMillis();
                return false;
            }
        };
        root.setBackgroundColor(Color.BLACK);
        live = new LiveView(a);
        root.addView(live, new FrameLayout.LayoutParams(-1, -1));

        // --- góra: tryby + status
        LinearLayout top = Ui.col(a);
        top.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), 0);
        LinearLayout modes = Ui.row(a);
        TextView back = Ui.btn(a, "◄");
        back.setOnClickListener(v -> a.onBackPressed());
        modes.addView(back, Ui.lpm(Ui.dp(44), -2, 0, 0, 0, 6, 0));
        for (int i = 0; i < 4; i++) {
            final int m = i;
            TextView b = Ui.btn(a, MODES[i]);
            b.setTextSize(12);
            b.setPadding(Ui.dp(4), Ui.dp(10), Ui.dp(4), Ui.dp(10));
            b.setOnClickListener(v -> setUserMode(m));
            modeBtn[i] = b;
            modes.addView(b, Ui.lpm(0, -2, 1, 2, 0, 2, 0));
        }
        top.addView(modes);
        LinearLayout info = Ui.row(a);
        recBadge = Ui.text(a, "", 14, Color.WHITE, Ui.MONO);
        recBadge.setPadding(Ui.dp(8), Ui.dp(3), Ui.dp(8), Ui.dp(3));
        recBadge.setBackground(Ui.box(Ui.RED, 0, 4));
        recBadge.setVisibility(View.GONE);
        info.addView(recBadge);
        status = Ui.text(a, "", 11, Ui.DIM, Ui.MONO);
        status.setPadding(Ui.dp(8), 0, 0, 0);
        info.addView(status, Ui.lp(0, -2, 1));
        info.setPadding(0, Ui.dp(8), 0, 0);
        top.addView(info);
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // --- dół: panel sterowania
        LinearLayout bot = Ui.col(a);
        bot.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(12));
        bot.setBackground(Ui.box(Ui.PANEL, 0, 0));

        LinearLayout r1 = Ui.row(a);
        TextView evm = Ui.btn(a, "EV−");
        evm.setOnClickListener(v -> setEv(cam.ev - 0.5f));
        evText = Ui.text(a, "", 13, Ui.TEXT, Ui.MONO);
        evText.setGravity(Gravity.CENTER);
        TextView evp = Ui.btn(a, "EV+");
        evp.setOnClickListener(v -> setEv(cam.ev + 0.5f));
        torchBtn = Ui.btn(a, "LATARKA");
        torchBtn.setOnClickListener(v -> {
            cam.torch = !cam.torch;
            Ui.on(torchBtn, cam.torch);
            if (cam.torch && !cam.hasFlash()) {
                if (recorder != null) {
                    // w trakcie nagrywania nie przełączamy obiektywu – próbujemy lampą innego aparatu
                    if (!cam.torchFallback(true)) a.toast("Ten obiektyw nie ma lampy – włącz latarkę przed nagrywaniem");
                } else {
                    a.toast("Przełączam na obiektyw z lampą");
                    restartCam();
                }
            } else {
                cam.torchFallback(false);
                cam.update();
            }
        });
        wideBtn = Ui.btn(a, "SZEROKI");
        wideBtn.setOnClickListener(v -> {
            if (recorder != null) { a.toast("Zmień po zakończeniu nagrywania"); return; }
            cam.wide = !cam.wide;
            App.put("wide", cam.wide);
            Ui.on(wideBtn, cam.wide);
            restartCam();
        });
        r1.addView(evm, Ui.lpm(0, -2, 1, 0, 0, 3, 0));
        r1.addView(evText, Ui.lp(0, -2, 1));
        r1.addView(evp, Ui.lpm(0, -2, 1, 3, 0, 6, 0));
        r1.addView(torchBtn, Ui.lpm(0, -2, 1.4f, 0, 0, 3, 0));
        r1.addView(wideBtn, Ui.lpm(0, -2, 1.4f, 3, 0, 3, 0));
        blurBtn = Ui.btn(a, "BLUR");
        blurBtn.setOnClickListener(v -> {
            boolean on = !App.b("blur", false);
            App.put("blur", on);
            Ui.on(blurBtn, on);
            a.toast(on ? "Zamazywanie głów: WŁ." : "Zamazywanie głów: WYŁ.");
        });
        r1.addView(blurBtn, Ui.lpm(0, -2, 1.1f, 3, 0, 0, 0));
        bot.addView(r1);

        LinearLayout r2 = Ui.row(a);
        r2.setPadding(0, Ui.dp(8), 0, 0);
        txText = Ui.text(a, "", 12, Ui.TEXT, Ui.MONO);
        r2.addView(txText, Ui.lp(0, -2, 1));
        TextView share = Ui.btn(a, "WYŚLIJ KOD");
        share.setTextSize(11);
        share.setOnClickListener(v -> shareCode());
        r2.addView(share, Ui.lpm(-2, -2, 0, 4, 0, 4, 0));
        txBtn = Ui.btn(a, "NADAWAJ");
        txBtn.setTextSize(11);
        txBtn.setOnClickListener(v -> {
            boolean on = !App.b("tx", true);
            App.put("tx", on);
            if (on) startTx();
            else stopTx();
            Ui.on(txBtn, on);
        });
        r2.addView(txBtn);
        bot.addView(r2);

        LinearLayout r3 = Ui.row(a);
        r3.setPadding(0, Ui.dp(10), 0, 0);
        TextView photo = Ui.btn(a, "ZDJĘCIE");
        photo.setOnClickListener(v -> photo());
        recBtn = new RecButton(a);
        recBtn.setOnClickListener(v -> { if (recorder == null) startRec(); else stopRec(); });
        TextView dim = Ui.btn(a, "WYGAŚ");
        dim.setOnClickListener(v -> setDark(true));
        r3.addView(photo, Ui.lp(0, -2, 1));
        r3.addView(recBtn, Ui.lpm(Ui.dp(76), Ui.dp(76), 0, 14, 0, 14, 0));
        r3.addView(dim, Ui.lp(0, -2, 1));
        bot.addView(r3);
        root.addView(bot, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        // --- napis przy komunikatach głosowych
        bannerView = Ui.text(a, "", 20, 0xFFF5C400, Ui.MONO);
        bannerView.setGravity(Gravity.CENTER);
        bannerView.setLetterSpacing(0.06f);
        bannerView.setPadding(Ui.dp(18), Ui.dp(10), Ui.dp(18), Ui.dp(10));
        bannerView.setBackground(Ui.box(0xCC000000, 0xFFF5C400, 6));
        bannerView.setVisibility(View.GONE);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        blp.topMargin = Ui.dp(120);
        root.addView(bannerView, blp);

        // --- wygaszony ekran (kamera dalej nagrywa)
        FrameLayout dv = new FrameLayout(a);
        dv.setBackgroundColor(Color.BLACK);
        TextView hint = Ui.text(a, "Ekran wygaszony – kamera pracuje.\nDotknij dwa razy, aby wybudzić.\nGłośniej = start, ciszej = stop.", 12, 0xFF2A2A2A, Ui.MONO);
        hint.setGravity(Gravity.CENTER);
        dv.addView(hint, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        final long[] lastTap = {0};
        dv.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                long now = System.currentTimeMillis();
                if (now - lastTap[0] < 400) setDark(false);
                lastTap[0] = now;
            }
            return true;
        });
        dv.setVisibility(View.GONE);
        darkView = dv;
        root.addView(dv, new FrameLayout.LayoutParams(-1, -1));

        refreshButtons();
        return root;
    }

    private void refreshButtons() {
        for (int i = 0; i < 4; i++) Ui.on(modeBtn[i], i == userMode);
        evText.setText(String.format(Locale.US, "%+.1f", cam.ev));
        Ui.on(torchBtn, cam.torch);
        Ui.on(wideBtn, cam.wide);
        Ui.on(txBtn, App.b("tx", true));
        Ui.on(blurBtn, App.b("blur", false));
    }

    // ================================================================ cykl życia

    @Override
    void onShow() {
        Sound.banner = this::banner;
        sound.powerOn();
        start();
        tick();
    }

    @Override
    void onResume() {
        start();
    }

    @Override
    void onPause() {
        stopAll();
    }

    @Override
    void onHide() {
        stopAll();
        sound.release();
        ui.removeCallbacksAndMessages(null);
    }

    @Override
    void onConfig() {
        updateRot();
    }

    private void start() {
        if (started) return;
        started = true;
        openCam();
        updateRot();
        mic = new Mic(this::onPcm);   // włączany w tick(), tylko gdy nagrywa albo ktoś ogląda
        if (App.b("tx", true)) startTx();
        if (App.gps()) startGps();
    }

    private void stopAll() {
        if (!started) return;
        started = false;
        if (recorder != null) stopRec();
        cam.close();
        if (mic != null) mic.stop();
        micOn = false;
        stopTx();
        stopGps();
        if (dark) setDark(false);
    }

    private void openCam() {
        int maxW = App.quality() == 1 ? 1920 : 1280;
        cam.mode = resolved();
        cam.open(maxW, this::onFrame);
    }

    private void restartCam() {
        cam.close();
        openCam();
    }

    private void updateRot() {
        int dr = a.getWindowManager().getDefaultDisplay().getRotation() * 90;
        rot = (cam.sensorOr - dr + 360) % 360;
    }

    // ================================================================ obraz

    private int resolved() {
        switch (userMode) {
            case 1: return Proc.DAY;
            case 2: return Proc.NIGHT;
            case 3: return Proc.NV;
            default: return autoMode;
        }
    }

    private long lastProc;

    private void onFrame(byte[] nv, int w, int h) {
        // oszczędzanie baterii: 25 kl./s normalnie, 6 kl./s gdy ekran wygaszony, nic nie nagrywa i nikt nie ogląda
        long nowF = System.currentTimeMillis();
        Link.Sender tw = tx;
        boolean idle = dark && recorder == null && (tw == null || !tw.watching());
        int fpsCap = idle ? 6 : 25;
        if (nowF - lastProc < 1000 / fpsCap - 4) return;
        lastProc = nowF;
        int m = resolved();
        proc.green = App.green() / 100f;
        proc.ev = cam.ev;
        proc.run(nv, w, h, m);
        if (userMode == 0) autoStep(m);
        if (App.b("blur", false)) {
            if (faces == null) faces = new Faces();
            faces.submit(proc.out, w, h, rot);   // rozjaśniony obraz – twarze widać też w nocy
            Blur.apply(proc.out, w, h, faces.current());
        }

        Frame f = pool.get(w, h);
        if (f == null) return;
        try {
            f.bmp.setPixels(proc.out, 0, w, 0, 0, w, h);
            f.time = System.currentTimeMillis();
            f.mode = m;
            Recorder r = recorder;
            if (r != null) r.addFrame(f);
            Link.Sender t = tx;
            if (t != null && t.watching()) {
                lastWatch = f.time;
                Streamer s = streamer;
                if (s == null || s.rot != rot || s.dead()) {
                    if (s != null) s.stop();
                    s = new Streamer(t, w, h, rot, App.streamQ());
                    streamer = s;
                }
                s.addFrame(f, r != null);
            } else if (streamer != null && f.time - lastWatch > 15_000) {
                streamer.stop();
                streamer = null;
            }
            if (!dark && !livePending) {
                livePending = true;
                f.retain();
                ui.post(() -> {
                    livePending = false;
                    live.set(f);
                });
            }
        } finally {
            f.release();
        }
    }

    /** AUTO: zmiana trybu po utrzymaniu się warunku (bez migania). */
    private void autoStep(int cur) {
        float mean = proc.rawMean;
        int want = cur;
        if (cur == Proc.DAY && mean < 45) want = Proc.NIGHT;
        else if (cur == Proc.NIGHT && mean > 165) want = Proc.DAY;
        else if (cur == Proc.NIGHT && mean < 14) want = Proc.NV;
        else if (cur == Proc.NV && mean > 70) want = Proc.NIGHT;
        long now = System.currentTimeMillis();
        if (want == cur) {
            autoWant = -1;
            return;
        }
        if (want != autoWant) {
            autoWant = want;
            autoSince = now;
            return;
        }
        if (now - autoSince > 1600) {
            autoMode = want;
            autoWant = -1;
            cam.mode = want;
            cam.update();
        }
    }

    private void setUserMode(int m) {
        userMode = m;
        App.put("umode", m);
        if (m == 0) autoMode = Proc.DAY;
        cam.mode = resolved();
        cam.update();
        refreshButtons();
    }

    private void setEv(float ev) {
        cam.ev = Math.max(-2f, Math.min(2f, ev));
        cam.update();
        refreshButtons();
    }

    // ================================================================ nagrywanie

    private void startRec() {
        if (recorder != null) return;
        if (pool == null || cam.width == 0) { a.toast("Aparat jeszcze się uruchamia"); return; }
        a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
        video = Store.newVideo(a);
        int[] o = Look.outSize(cam.width, cam.height, rot);
        int bitrate = App.quality() == 1 ? 12_000_000 : 6_000_000;
        recorder = new Recorder(video.pfd != null ? video.pfd.getFileDescriptor() : null,
                video.file != null ? video.file.getAbsolutePath() : null, o[0], o[1], rot, bitrate, 25);
        recStart = System.currentTimeMillis();
        lastTouch = recStart;
        lastReminder = recStart;
        recBtn.rec = true;
        recBtn.invalidate();
        sound.recStart();
    }

    private void stopRec() {
        Recorder r = recorder;
        if (r == null) return;
        recorder = null;
        final Store.Video v = video;
        recBtn.rec = false;
        recBtn.invalidate();
        sound.recStop();
        r.stop(ok -> {
            Store.finish(a, v, ok);
            a.toast(ok ? "Zapisano: Galeria › Filmy › Bodycam" : "Nagrywanie nie powiodło się");
        });
        a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void onPcm(short[] pcm, int n, long ptsUs) {
        Recorder r = recorder;
        if (r != null) r.addAudio(pcm, n, ptsUs);
        Link.Sender t = tx;
        if (t != null && t.watching()) t.audio(adpcm.encode(pcm, n), System.currentTimeMillis());
    }

    private void photo() {
        Frame f = live.cur;
        if (f == null) return;
        int[] o = Look.outSize(f.bmp.getWidth(), f.bmp.getHeight(), rot);
        Bitmap out = Bitmap.createBitmap(o[0], o[1], Bitmap.Config.ARGB_8888);
        new Look().draw(new Canvas(out), f.bmp, f.time, 0, 0, o[0], o[1], rot, recorder != null);
        sound.click();
        new Thread(() -> {
            boolean ok = Store.photo(a, out);
            ui.post(() -> a.toast(ok ? "Zdjęcie zapisane: Obrazy › Bodycam" : "Nie udało się zapisać zdjęcia"));
        }).start();
    }

    // ================================================================ nadawanie

    private void startTx() {
        if (tx != null) return;
        tx = new Link.Sender(new Link(App.code()), Link.servers(App.server(), App.custom()), new Link.Sender.Events() {
            @Override
            public void needKeyframe() {
                Streamer s = streamer;
                if (s != null) s.requestKey();
            }

            @Override
            public void onState(String text) {
                ui.post(() -> txState = text);
            }

            @Override
            public void onNewViewer() {
                ui.post(sound::pairing);
            }
        });
    }

    private String txState = "";
    private long lastCongest, lastRaise;
    private int lowWarned = 100;
    private boolean micOn;
    private long micNeedAt, lastTouch = System.currentTimeMillis();

    private void stopTx() {
        Link.Sender t = tx;
        tx = null;
        if (t != null) new Thread(t::stop).start();
        Streamer s = streamer;
        streamer = null;
        if (s != null) s.stop();
        txState = "";
    }

    private void shareCode() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, "Podgląd mojego bodycama na żywo: otwórz aplikację Bodycam › PODGLĄD i wpisz kod "
                + Link.pretty(App.code()));
        a.startActivity(Intent.createChooser(i, "Wyślij kod"));
    }

    // ================================================================ różne

    private void setDark(boolean on) {
        dark = on;
        darkView.setVisibility(on ? View.VISIBLE : View.GONE);
        WindowManager.LayoutParams lp = a.getWindow().getAttributes();
        lp.screenBrightness = on ? 0.0f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        a.getWindow().setAttributes(lp);
    }

    @Override
    boolean back() {
        if (dark) {
            setDark(false);
            return true;
        }
        if (recorder != null) {
            a.toast("Najpierw zatrzymaj nagrywanie");
            return true;
        }
        return false;
    }

    // Głośniej: krótko = start nagrywania, przytrzymanie = komunikat "Nagrywam" / "Nie nagrywam".
    // Ciszej: stop nagrywania.
    private boolean upLong;

    @Override
    boolean keyDown(int code, KeyEvent e) {
        lastTouch = System.currentTimeMillis();
        if (!App.volKeys()) return false;
        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            if (e.getRepeatCount() == 0) {
                upLong = false;
                e.startTracking();
            }
            return true;
        }
        if (code == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (e.getRepeatCount() == 0) {
                downLong = false;
                e.startTracking();
            }
            return true;
        }
        return false;
    }

    private boolean downLong;

    @Override
    boolean keyLong(int code, KeyEvent e) {
        if (!App.volKeys()) return false;
        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            upLong = true;
            sound.status(recorder != null);
            return true;
        }
        if (code == KeyEvent.KEYCODE_VOLUME_DOWN) {   // przytrzymanie "ciszej" = tryb wyciszenia
            downLong = true;
            boolean m = !App.b("mute", false);
            App.put("mute", m);
            sound.muteToggle();
            a.toast(m ? "Tryb wyciszenia: WŁ." : "Tryb wyciszenia: WYŁ.");
            return true;
        }
        return false;
    }

    @Override
    boolean keyUp(int code, KeyEvent e) {
        if (!App.volKeys()) return false;
        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            if (!upLong && !e.isCanceled() && recorder == null) startRec();
            upLong = false;
            return true;
        }
        if (code == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (!downLong && !e.isCanceled() && recorder != null) stopRec();
            downLong = false;
            return true;
        }
        return false;
    }

    private int battery() {
        try {
            BatteryManager bm = (BatteryManager) a.getSystemService(Context.BATTERY_SERVICE);
            return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        } catch (Exception e) {
            return -1;
        }
    }

    private void tick() {
        long now = System.currentTimeMillis();
        String[] mn = {"DZIEŃ", "NOC", "NOKTO"};
        int m = resolved();
        StringBuilder s = new StringBuilder();
        if (cam.error != null) s.append(cam.error);
        else {
            s.append(mn[m]);
            if (userMode == 0) s.append(" (auto)");
            if (m != Proc.DAY) s.append(cam.manual() ? " · długi czas" : " · max jasność");
            s.append(" · ").append(cam.width).append('×').append(cam.height);
            int b = battery();
            if (b >= 0) s.append(" · bat ").append(b).append('%');
        }
        status.setText(s);
        Link.Sender txw = tx;
        boolean needMic = recorder != null || (txw != null && txw.watching());
        if (needMic) {
            micNeedAt = now;
            if (mic != null && !micOn) { mic.start(); micOn = true; }
        } else if (micOn && now - micNeedAt > 5000 && mic != null) {
            mic.stop();
            micOn = false;
        }
        if (App.b("autodim", true) && recorder != null && !dark && now - lastTouch > 90_000) setDark(true);
        int bat = battery();
        if (bat > 0) {
            if (bat > 11) lowWarned = 100;
            if (bat <= 10 && lowWarned > 10) { lowWarned = 10; sound.lowBattery(); }
            if (bat <= 5 && lowWarned > 5) { lowWarned = 5; sound.lowBattery(); }
        }
        Recorder r = recorder;
        if (r != null) {
            long t = (now - recStart) / 1000;
            recBadge.setText(String.format(Locale.US, "● REC %02d:%02d:%02d", t / 3600, t / 60 % 60, t % 60));
            recBadge.setVisibility(View.VISIBLE);
            if (App.beep2() && now - lastReminder > 120_000) {
                lastReminder = now;
                sound.reminder();
            }
        } else recBadge.setVisibility(View.GONE);
        Link.Sender t = tx;
        Streamer stm = streamer;
        if (t != null && stm != null) {
            if (t.congested()) {
                if (now - lastCongest > 1000) stm.setBitrate((int) (stm.bitrate * 0.7f));
                lastCongest = now;
            } else if (now - lastCongest > 4000 && now - lastRaise > 2000) {
                stm.setBitrate((int) (stm.bitrate * 1.12f));
                lastRaise = now;
            }
        }
        if (t != null) {
            String ips = String.join(", ", Direct.localIps());
            txText.setText("KOD " + Link.pretty(App.code()) + (ips.isEmpty() ? "" : "  ·  IP " + ips) + "\n" + txState
                    + (stm != null ? " · " + stm.bitrate / 1000 + " kb/s" : ""));
            try {
                synchronized (t.status) {
                t.status.put("rec", r != null ? 1 : 0);
                t.status.put("mode", mn[m]);
                t.status.put("bat", battery());
                t.status.put("model", App.model());
                }
            } catch (Exception ignored) { }
        } else txText.setText("NADAWANIE WYŁ.\n—");
        ui.postDelayed(this::tick, 500);
    }

    @SuppressWarnings("MissingPermission")
    private void startGps() {
        a.withPerms(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, () -> {
            try {
                lm = (LocationManager) a.getSystemService(Context.LOCATION_SERVICE);
                ll = new LocationListener() {
                    @Override
                    public void onLocationChanged(Location l) {
                        double la = l.getLatitude(), lo = l.getLongitude();
                        Look.gpsText = String.format(Locale.US, "%s%.5f %s%.5f", la >= 0 ? "N" : "S", Math.abs(la),
                                lo >= 0 ? "E" : "W", Math.abs(lo));
                    }

                    @Override
                    public void onStatusChanged(String p, int s, android.os.Bundle e) { }

                    @Override
                    public void onProviderEnabled(String p) { }

                    @Override
                    public void onProviderDisabled(String p) { }
                };
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 0, ll);
                try {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 0, ll);
                } catch (Exception ignored) { }
            } catch (Exception ignored) { }
        });
    }

    private void stopGps() {
        try { if (lm != null && ll != null) lm.removeUpdates(ll); } catch (Exception ignored) { }
        lm = null;
        ll = null;
    }
}
