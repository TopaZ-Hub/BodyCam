package pl.bodycam.app;

import android.graphics.Bitmap;

import java.util.concurrent.atomic.AtomicInteger;

/** Przetworzona klatka współdzielona przez ekran, nagrywanie i nadawanie (licznik odwołań). */
final class Frame {
    final Bitmap bmp;
    final AtomicInteger refs = new AtomicInteger();
    long time;
    int mode;

    Frame(int w, int h) {
        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    }

    Frame retain() {
        refs.incrementAndGet();
        return this;
    }

    void release() {
        refs.decrementAndGet();
    }

    static final class Pool {
        private final Frame[] f = new Frame[7];
        private int w, h;

        synchronized Frame get(int w, int h) {
            if (w != this.w || h != this.h) {
                this.w = w;
                this.h = h;
                for (int i = 0; i < f.length; i++) f[i] = null;
            }
            for (int i = 0; i < f.length; i++) {
                if (f[i] == null) f[i] = new Frame(w, h);
                if (f[i].refs.compareAndSet(0, 1)) return f[i];
            }
            return null; // wszystkie zajęte – pomijamy klatkę
        }
    }
}
