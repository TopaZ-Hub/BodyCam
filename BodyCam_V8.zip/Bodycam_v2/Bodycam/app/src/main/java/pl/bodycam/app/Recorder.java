package pl.bodycam.app;

import android.graphics.Canvas;
import android.graphics.Color;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.Surface;

import java.io.FileDescriptor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Nagrywanie do MP4: obraz z nakładką (H.264, sprzętowo) + dźwięk AAC 16 kHz.
 * Obraz i dźwięk w tym samym zegarze (System.nanoTime).
 */
final class Recorder {

    static final int AUDIO_RATE = 16000;

    interface Done { void onDone(boolean ok); }

    private final int vw, vh, rot, fps;
    private final FileDescriptor fd;
    private final String path;
    private boolean audio;
    private final HandlerThread th = new HandlerThread("rec");
    private final Handler h;
    private final AtomicInteger pending = new AtomicInteger();
    private final MediaCodec.BufferInfo vInfo = new MediaCodec.BufferInfo(), aInfo = new MediaCodec.BufferInfo();
    private final Look look = new Look();
    private MediaCodec vCodec, aCodec;
    private MediaMuxer mux;
    private Surface surface;
    private MediaFormat vFmt, aFmt;
    private long vFmtAt;
    private int vTrack = -1, aTrack = -1, frames;
    private boolean muxing;
    private volatile boolean failed;
    private long lastAPts = -1, lastFrameNs;

    Recorder(FileDescriptor fd, String path, int w, int h, int rot, int bitrate, int fps) {
        this.fd = fd;
        this.path = path;
        vw = w & ~1;
        vh = h & ~1;
        this.rot = rot;
        this.fps = fps;
        audio = true;
        th.start();
        this.h = new Handler(th.getLooper());
        this.h.post(() -> init(bitrate));
    }

    private void init(int bitrate) {
        try {
            MediaFormat fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            vCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            vCodec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = vCodec.createInputSurface();
            vCodec.start();
            mux = fd != null ? new MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    : new MediaMuxer(path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        } catch (Exception e) {
            failed = true;
            return;
        }
        try {
            MediaFormat af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_RATE, 1);
            af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            af.setInteger(MediaFormat.KEY_BIT_RATE, 64000);
            af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            aCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            aCodec.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            aCodec.start();
        } catch (Exception e) {
            audio = false;
            aCodec = null;
        }
    }

    boolean failed() {
        return failed;
    }

    void addFrame(Frame f) {
        long now = System.nanoTime();
        if (failed || pending.get() > 1 || now - lastFrameNs < 1_000_000_000L / (fps + 2)) return;
        lastFrameNs = now;
        f.retain();
        pending.incrementAndGet();
        h.post(() -> {
            pending.decrementAndGet();
            try {
                if (failed || surface == null) return;
                Canvas c = surface.lockHardwareCanvas();
                c.drawColor(Color.BLACK);
                look.draw(c, f.bmp, f.time, 0, 0, vw, vh, rot, true);
                surface.unlockCanvasAndPost(c);
                frames++;
                drain(vCodec, vInfo, true, false);
            } catch (Exception e) {
                failed = true;
            } finally {
                f.release();
            }
        });
    }

    void addAudio(short[] pcm, int n, long ptsUs) {
        if (failed || !audio) return;
        final short[] copy = new short[n];
        System.arraycopy(pcm, 0, copy, 0, n);
        h.post(() -> {
            if (failed || !audio || aCodec == null) return;
            try {
                int off = 0;
                long pts = ptsUs;
                while (off < copy.length) {
                    int idx = aCodec.dequeueInputBuffer(5000);
                    if (idx < 0) break;
                    ByteBuffer ib = aCodec.getInputBuffer(idx);
                    if (ib == null) break;
                    ib.clear();
                    int count = Math.min(copy.length - off, ib.remaining() / 2);
                    ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(copy, off, count);
                    if (pts <= lastAPts) pts = lastAPts + 1;
                    lastAPts = pts;
                    aCodec.queueInputBuffer(idx, 0, count * 2, pts, 0);
                    off += count;
                    pts += count * 1_000_000L / AUDIO_RATE;
                }
                drain(aCodec, aInfo, false, false);
            } catch (Exception e) {
                audio = false;
            }
        });
    }

    void stop(Done done) {
        h.post(() -> {
            boolean ok = false;
            try {
                if (vCodec != null && !failed) {
                    vCodec.signalEndOfInputStream();
                    drain(vCodec, vInfo, true, true);
                }
                if (aCodec != null && audio) {
                    int idx = aCodec.dequeueInputBuffer(10000);
                    if (idx >= 0) aCodec.queueInputBuffer(idx, 0, 0, lastAPts + 1, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    drain(aCodec, aInfo, false, true);
                }
            } catch (Exception e) {
                failed = true;
            }
            release(vCodec);
            release(aCodec);
            if (surface != null) surface.release();
            try {
                if (muxing) {
                    mux.stop();
                    ok = !failed && frames > 0;
                }
            } catch (Exception e) {
                ok = false;
            }
            try { if (mux != null) mux.release(); } catch (Exception ignored) { }
            final boolean r = ok;
            new Handler(Looper.getMainLooper()).post(() -> done.onDone(r));
            th.quitSafely();
        });
    }

    private static void release(MediaCodec c) {
        if (c == null) return;
        try { c.stop(); } catch (Exception ignored) { }
        try { c.release(); } catch (Exception ignored) { }
    }

    private void maybeStartMux() {
        if (muxing || vFmt == null) return;
        boolean audioReady = !audio || aFmt != null;
        if (!audioReady && System.currentTimeMillis() - vFmtAt > 1500) {
            audio = false;
            audioReady = true;
        }
        if (!audioReady) return;
        vTrack = mux.addTrack(vFmt);
        if (audio && aFmt != null) aTrack = mux.addTrack(aFmt);
        mux.start();
        muxing = true;
    }

    private void drain(MediaCodec codec, MediaCodec.BufferInfo info, boolean video, boolean end) {
        int tries = 0;
        while (true) {
            int idx = codec.dequeueOutputBuffer(info, end ? 10000 : 0);
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end || ++tries > 100) break;
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (video) {
                    vFmt = codec.getOutputFormat();
                    vFmtAt = System.currentTimeMillis();
                } else aFmt = codec.getOutputFormat();
                maybeStartMux();
            } else if (idx >= 0) {
                maybeStartMux();
                ByteBuffer bb = codec.getOutputBuffer(idx);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                int track = video ? vTrack : aTrack;
                if (info.size > 0 && muxing && track >= 0 && bb != null) {
                    bb.position(info.offset);
                    bb.limit(info.offset + info.size);
                    mux.writeSampleData(track, bb, info);
                }
                codec.releaseOutputBuffer(idx, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
    }
}
