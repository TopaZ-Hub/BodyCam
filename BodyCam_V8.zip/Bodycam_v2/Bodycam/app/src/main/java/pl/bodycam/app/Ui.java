package pl.bodycam.app;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Wygląd: ciemny, "sprzętowy", żółty akcent, czcionka o stałej szerokości. */
final class Ui {

    static final int BG = 0xFF0A0B0C, PANEL = 0xE6141619, PANEL_SOLID = 0xFF15171A, LINE = 0xFF2B2F35,
            TEXT = 0xFFECEAE4, DIM = 0xFF8C9199, ACC = 0xFFF5C400, RED = 0xFFE5322D, OK = 0xFF46C46E;
    static Typeface MONO, COND;
    static float d = 3;

    static void init(Context c) {
        d = c.getResources().getDisplayMetrics().density;
        MONO = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
        COND = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    }

    static int dp(float v) {
        return Math.round(v * d);
    }

    static GradientDrawable box(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(Math.max(1, dp(1)), stroke);
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, Typeface tf) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(tf);
        return t;
    }

    static TextView btn(Context c, String s) {
        TextView t = text(c, s, 13, TEXT, MONO);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setLetterSpacing(0.06f);
        t.setBackground(box(0xCC1B1E22, LINE, 6));
        t.setClickable(true);
        return t;
    }

    static void on(TextView b, boolean on) {
        b.setBackground(box(on ? ACC : 0xCC1B1E22, on ? ACC : LINE, 6));
        b.setTextColor(on ? 0xFF111111 : TEXT);
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams lpm(int w, int h, float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    static View gap(Context c, int dpW) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(dpW), dp(dpW)));
        return v;
    }
}
