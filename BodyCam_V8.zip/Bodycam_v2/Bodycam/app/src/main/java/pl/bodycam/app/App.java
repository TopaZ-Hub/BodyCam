package pl.bodycam.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;

/** Ustawienia aplikacji. */
final class App {

    static SharedPreferences p;

    static void init(Context c) {
        if (p != null) return;
        p = c.getApplicationContext().getSharedPreferences("bodycam", Context.MODE_PRIVATE);
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(
                c.getAssets().open("nakladka.txt"), java.nio.charset.StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("MODEL=")) assetModel = line.substring(6).trim();
                else if (line.startsWith("NUMER=") && line.length() > 6) p.edit().putString("dev", line.substring(6).trim()).apply();
            }
        } catch (Exception ignored) { }
        if (!p.contains("dev")) {
            SecureRandom r = new SecureRandom();
            String al = "0123456789ABCDEFGHJKLMNPRSTUVWXYZ";
            StringBuilder d = new StringBuilder("X");
            for (int i = 0; i < 8; i++) d.append(i < 4 ? (char) ('0' + r.nextInt(10)) : al.charAt(r.nextInt(al.length())));
            p.edit().putString("dev", d.toString()).putString("code", Link.newCode()).apply();
        }
    }

    static String s(String k, String d) { return p.getString(k, d); }
    static int i(String k, int d) { return p.getInt(k, d); }
    static boolean b(String k, boolean d) { return p.getBoolean(k, d); }
    static void put(String k, String v) { p.edit().putString(k, v).apply(); }
    static void put(String k, int v) { p.edit().putInt(k, v).apply(); }
    static void put(String k, boolean v) { p.edit().putBoolean(k, v).apply(); }

    // --- nakładka
    static int style() { return i("style", 0); }                     // 0 = Body 3 (prawy górny róg), 1 = klasyczny
    /** Domyślny tekst z pliku assets/nakladka.txt (MODEL=...), {NR} = numer urządzenia. Ustawienia mają pierwszeństwo. */
    static String assetModel = "BODY CAM 3 {NR}";

    static String model() {
        String m = s("model", "");
        if (m.trim().isEmpty()) m = assetModel;
        return m.replace("{NR}", s("dev", "X000000000"));
    }
    static String name() { return s("name", "FUNKCJONARIUSZ"); }
    static String callsign() { return s("callsign", "B-01"); }
    static String unit() { return s("unit", "JEDNOSTKA"); }
    static boolean gps() { return b("gps", false); }

    // --- obraz
    static int quality() { return i("quality", 0); }                 // 0 = 720p, 1 = 1080p
    static boolean fisheye() { return b("fisheye", true); }
    static int fishStrength() { return i("fishk", 40); }             // 0..100
    static int green() { return i("green", 40); }                    // 0..100
    static boolean wide() { return b("wide", true); }

    // --- dźwięki i sterowanie
    static boolean voice() { return b("voice", true); }
    static boolean beep2() { return b("beep2", true); }
    static boolean volKeys() { return b("volkeys", true); }

    // --- łączność
    static String code() { return s("code", "AAAAAAAA"); }
    static int server() { return i("server", 0); }
    static String custom() { return s("custom", ""); }
    static int streamQ() { return i("streamq", 1); }                 // 0 = oszczędny, 1 = normalny, 2 = wysoki
}
