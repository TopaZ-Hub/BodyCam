package pl.bodycam.app;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Połączenia bezpośrednie (bez serwera pośredniczącego):
 *  LAN     – ta sama sieć Wi-Fi albo hotspot jednego z telefonów. Bodycam rozgłasza się w sieci,
 *            podgląd sam go znajduje (albo łączy się po wpisanym adresie IP). Najmniejsze opóźnienie.
 *  P2P     – bezpośrednio przez internet (UDP z "przebijaniem" NAT, adresy ustalane przez STUN).
 *            Działa w wielu sieciach domowych i części komórkowych; gdy się nie da – zostaje serwer.
 * Wszystkie dane są już zaszyfrowane (Link.seal) – tu tylko je przenosimy.
 */
final class Direct {

    static final int TCP_PORT = 47900, BEACON_PORT = 47901;
    static final byte K_VIDEO = 'v', K_AUDIO = 'a', K_STATUS = 's', K_CTL = 'c', K_PUNCH = 'p';
    static final String[][] STUN = {{"stun.l.google.com", "19302"}, {"stun1.l.google.com", "19302"}, {"stun.cloudflare.com", "3478"}};
    private static final int FRAG = 1150;
    private static final long TCP_MAX_QUEUE = 350_000;
    static volatile double testLoss = 0;

    interface Sink {
        /** via: "lan" albo "p2p"; peer: identyfikator połączenia (do odpowiedzi). */
        void onPacket(byte kind, byte[] sealed, String via, Object peer);
    }

    // ======================================================================= wspólne

    static List<String> localIps() {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) out.add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static List<InetAddress> broadcasts() {
        List<InetAddress> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses())
                    if (ia.getBroadcast() != null) out.add(ia.getBroadcast());
            }
        } catch (Exception ignored) { }
        try {
            out.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) { }
        return out;
    }

    static void writeFrame(DataOutputStream o, byte kind, byte[] p) throws IOException {
        o.writeByte(kind);
        o.writeInt(p.length);
        o.write(p);
    }

    /** Ramki TCP z kolejką i odrzucaniem danych "na żywo", gdy łącze nie nadąża. */
    static final class TcpConn {
        final Socket s;
        private final DataOutputStream out;
        private final LinkedBlockingQueue<Object[]> q = new LinkedBlockingQueue<>();
        final AtomicLong queued = new AtomicLong();
        volatile boolean alive = true, dropToKey = false;
        volatile boolean wanted = true;   // czy widz ogląda tą drogą (inaczej tylko klatki kluczowe)
        volatile long lastIn = System.currentTimeMillis();
        final String addr;

        TcpConn(Socket s, Sink sink, String via, Runnable onDrop) throws IOException {
            this.s = s;
            s.setTcpNoDelay(true);
            s.setSoTimeout(15000);
            addr = s.getInetAddress().getHostAddress();
            out = new DataOutputStream(new java.io.BufferedOutputStream(s.getOutputStream(), 65536));
            DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(s.getInputStream()));
            Thread r = new Thread(() -> {
                try {
                    while (alive) {
                        byte k = in.readByte();
                        int len = in.readInt();
                        if (len < 0 || len > 8_000_000) throw new IOException("zła ramka");
                        byte[] p = new byte[len];
                        in.readFully(p);
                        lastIn = System.currentTimeMillis();
                        sink.onPacket(k, p, via, this);
                    }
                } catch (Exception e) {
                    close();
                }
            }, "lan-in");
            r.setDaemon(true);
            r.start();
            Thread w = new Thread(() -> {
                try {
                    while (alive) {
                        Object[] f = q.poll(5, TimeUnit.SECONDS);
                        if (f == null) continue;
                        byte[] p = (byte[]) f[1];
                        if (p.length == 0 && (Byte) f[0] == 0) break;
                        writeFrame(out, (Byte) f[0], p);
                        queued.addAndGet(-p.length);
                        if (q.isEmpty()) out.flush();
                    }
                } catch (Exception e) {
                    close();
                }
            }, "lan-out");
            w.setDaemon(true);
            w.start();
            this.onDrop = onDrop;
        }

        private final Runnable onDrop;

        /** live = obraz/dźwięk (można odrzucić). key = klatka kluczowa. */
        void send(byte kind, byte[] p, boolean live, boolean key) {
            if (!alive) return;
            if (live) {
                if (kind == K_VIDEO) {
                    if (dropToKey && !key) return;
                    if (queued.get() > TCP_MAX_QUEUE) {
                        dropToKey = true;
                        if (onDrop != null) onDrop.run();
                        return;
                    }
                    if (key) dropToKey = false;
                } else if (queued.get() > TCP_MAX_QUEUE) return;
            }
            queued.addAndGet(p.length);
            q.offer(new Object[]{kind, p});
        }

        void close() {
            if (!alive) return;
            alive = false;
            try { s.close(); } catch (Exception ignored) { }
            q.offer(new Object[]{(byte) 0, new byte[0]});
        }
    }

    /** UDP: dzielenie na kawałki, składanie, STUN. */
    static final class Udp {
        final DatagramSocket sock;
        private final Sink sink;
        private final Map<Integer, byte[][]> parts = new ConcurrentHashMap<>();
        private final Map<Integer, Byte> partKind = new ConcurrentHashMap<>();
        private int newest = Integer.MIN_VALUE;
        private int msgId = new SecureRandom().nextInt();
        volatile String publicEp;
        volatile boolean alive = true;
        final Map<String, Long> lastFrom = new ConcurrentHashMap<>();

        Udp(Sink sink, int port) throws IOException {
            this.sink = sink;
            DatagramSocket s;
            try {
                s = new DatagramSocket(port);
            } catch (Exception e) {
                s = new DatagramSocket();
            }
            sock = s;
            try { sock.setReceiveBufferSize(1 << 20); } catch (Exception ignored) { }
            try { sock.setSendBufferSize(1 << 20); } catch (Exception ignored) { }
            Thread t = new Thread(this::recvLoop, "udp-in");
            t.setDaemon(true);
            t.start();
        }

        void stun() {
            for (String[] s : STUN) {
                try {
                    byte[] req = new byte[20];
                    req[1] = 1;                                   // Binding Request
                    req[4] = 0x21; req[5] = 0x12; req[6] = (byte) 0xA4; req[7] = 0x42;
                    for (int i = 8; i < 20; i++) req[i] = (byte) (Math.random() * 256);
                    sock.send(new DatagramPacket(req, req.length, new InetSocketAddress(s[0], Integer.parseInt(s[1]))));
                } catch (Exception ignored) { }
            }
        }

        private void recvLoop() {
            byte[] buf = new byte[2048];
            while (alive) {
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    sock.receive(p);
                    int n = p.getLength();
                    if (n >= 20 && buf[0] == 0x01 && buf[1] == 0x01) {   // odpowiedź STUN
                        String ep = parseStun(buf, n);
                        if (ep != null) publicEp = ep;
                        continue;
                    }
                    if (n < 11 || buf[0] != 'B' || buf[1] != 'C') continue;
                    byte kind = buf[2];
                    String from = p.getAddress().getHostAddress() + ":" + p.getPort();
                    lastFrom.put(from, System.currentTimeMillis());
                    SocketAddress sa = p.getSocketAddress();
                    if (kind == K_PUNCH) {
                        sink.onPacket(K_PUNCH, new byte[0], "p2p", sa);
                        continue;
                    }
                    ByteBuffer b = ByteBuffer.wrap(buf, 3, n - 3);
                    int id = b.getInt();
                    int idx = b.getShort() & 0xFFFF, cnt = b.getShort() & 0xFFFF;
                    byte[] data = java.util.Arrays.copyOfRange(buf, 11, n);
                    if (cnt <= 1) {
                        sink.onPacket(kind, data, "p2p", sa);
                        continue;
                    }
                    if (cnt > 4000 || idx >= cnt) continue;
                    byte[][] arr = parts.get(id);
                    if (arr == null) {
                        arr = new byte[cnt][];
                        parts.put(id, arr);
                        partKind.put(id, kind);
                        if (newest == Integer.MIN_VALUE || id - newest > 0) newest = id;
                        if (parts.size() > 48) {   // stare niedokończone – wyrzuć
                            Iterator<Integer> it = parts.keySet().iterator();
                            while (it.hasNext()) {
                                int k = it.next();
                                if (newest - k > 40) { it.remove(); partKind.remove(k); }
                            }
                        }
                    }
                    if (arr.length != cnt) continue;
                    arr[idx] = data;
                    boolean full = true;
                    int total = 0;
                    for (byte[] x : arr) {
                        if (x == null) { full = false; break; }
                        total += x.length;
                    }
                    if (!full) continue;
                    parts.remove(id);
                    Byte k = partKind.remove(id);
                    byte[] all = new byte[total];
                    int o = 0;
                    for (byte[] x : arr) {
                        System.arraycopy(x, 0, all, o, x.length);
                        o += x.length;
                    }
                    sink.onPacket(k == null ? kind : k, all, "p2p", sa);
                } catch (Exception e) {
                    if (sock.isClosed()) break;
                }
            }
        }

        static String parseStun(byte[] b, int n) {
            int i = 20;
            while (i + 4 <= n) {
                int type = (b[i] & 0xFF) << 8 | (b[i + 1] & 0xFF);
                int len = (b[i + 2] & 0xFF) << 8 | (b[i + 3] & 0xFF);
                int v = i + 4;
                if ((type == 0x0020 || type == 0x0001) && len >= 8 && b[v + 1] == 0x01) {
                    int port = (b[v + 2] & 0xFF) << 8 | (b[v + 3] & 0xFF);
                    byte[] ip = {b[v + 4], b[v + 5], b[v + 6], b[v + 7]};
                    if (type == 0x0020) {
                        port ^= 0x2112;
                        ip[0] ^= 0x21; ip[1] ^= 0x12; ip[2] ^= (byte) 0xA4; ip[3] ^= 0x42;
                    }
                    return (ip[0] & 0xFF) + "." + (ip[1] & 0xFF) + "." + (ip[2] & 0xFF) + "." + (ip[3] & 0xFF) + ":" + port;
                }
                i = v + ((len + 3) & ~3);
            }
            return null;
        }

        void send(SocketAddress to, byte kind, byte[] data) {
            if (to == null || !alive) return;
            try {
                if (kind == K_PUNCH) {
                    byte[] p = {'B', 'C', K_PUNCH, 0, 0, 0, 0, 0, 0, 0, 1};
                    sock.send(new DatagramPacket(p, p.length, to));
                    return;
                }
                if (testLoss > 0 && Math.random() < testLoss) return;   // tylko do testów
                int cnt = Math.max(1, (data.length + FRAG - 1) / FRAG);
                int id;
                synchronized (this) { id = msgId++; }
                for (int i = 0; i < cnt; i++) {
                    int off = i * FRAG, len = Math.min(FRAG, data.length - off);
                    ByteBuffer b = ByteBuffer.allocate(11 + len);
                    b.put((byte) 'B').put((byte) 'C').put(kind).putInt(id).putShort((short) i).putShort((short) cnt);
                    b.put(data, off, len);
                    sock.send(new DatagramPacket(b.array(), b.position(), to));
                    if ((i & 15) == 15) Thread.sleep(1);   // lekkie rozłożenie dużych klatek w czasie
                }
            } catch (Exception ignored) { }
        }

        void close() {
            alive = false;
            sock.close();
        }
    }

    static SocketAddress parseEp(String ep) {
        try {
            int c = ep.lastIndexOf(':');
            return new InetSocketAddress(InetAddress.getByName(ep.substring(0, c)), Integer.parseInt(ep.substring(c + 1)));
        } catch (Exception e) {
            return null;
        }
    }

    // ======================================================================= BODYCAM

    static final class Server {
        private final String base;
        private final Sink sink;
        private final Runnable onDrop;
        private ServerSocket ss;
        private Udp udp;
        volatile boolean running = true;
        final List<TcpConn> tcp = new CopyOnWriteArrayList<>();
        final Map<String, Object[]> udpPeers = new ConcurrentHashMap<>();   // "ip:port" -> {SocketAddress, lastSeen}
        private final Map<String, Long> punching = new ConcurrentHashMap<>();
        int tcpPort = TCP_PORT;

        Server(String base, Sink sink, Runnable onDrop) {
            this.base = base;
            this.onDrop = onDrop;
            this.sink = (k, p, via, peer) -> {
                if (via.equals("p2p") && peer instanceof SocketAddress && k != K_PUNCH) {
                    String key = peer.toString();
                    Object[] old = udpPeers.get(key);
                    udpPeers.put(key, new Object[]{peer, System.currentTimeMillis(), old != null && old.length > 2 ? old[2] : Boolean.TRUE});
                }
                if (k == K_PUNCH) return;
                sink.onPacket(k, p, via, peer);
            };
            Thread t = new Thread(this::run, "direct-srv");
            t.setDaemon(true);
            t.start();
        }

        private void run() {
            try {
                ss = new ServerSocket();
                ss.setReuseAddress(true);
                try {
                    ss.bind(new InetSocketAddress(TCP_PORT));
                } catch (Exception e) {
                    ss.bind(new InetSocketAddress(0));
                }
                tcpPort = ss.getLocalPort();
            } catch (Exception e) {
                ss = null;
            }
            try {
                udp = new Udp(sink, 0);
                udp.stun();
            } catch (Exception ignored) { }
            Thread b = new Thread(this::beaconLoop, "beacon");
            b.setDaemon(true);
            b.start();
            while (running && ss != null) {
                try {
                    Socket s = ss.accept();
                    tcp.add(new TcpConn(s, sink, "lan", onDrop));
                } catch (Exception e) {
                    if (!running) break;
                }
            }
        }

        private void beaconLoop() {
            DatagramSocket ds = null;
            long lastStun = System.currentTimeMillis();
            try {
                ds = new DatagramSocket();
                ds.setBroadcast(true);
                while (running) {
                    byte[] msg = ("BCAM1 " + base + " " + tcpPort).getBytes(StandardCharsets.UTF_8);
                    for (InetAddress a : broadcasts()) {
                        try { ds.send(new DatagramPacket(msg, msg.length, a, BEACON_PORT)); } catch (Exception ignored) { }
                    }
                    long now = System.currentTimeMillis();
                    // przebijanie NAT do widzów, którzy podali swój adres
                    for (Map.Entry<String, Long> e : punching.entrySet()) {
                        if (now - e.getValue() > 15000) punching.remove(e.getKey());
                        else if (udp != null) udp.send(parseEp(e.getKey()), K_PUNCH, null);
                    }
                    for (Map.Entry<String, Object[]> e : udpPeers.entrySet())
                        if (now - (Long) e.getValue()[1] > 9000) udpPeers.remove(e.getKey());
                    for (TcpConn c : tcp) if (!c.alive || now - c.lastIn > 12000) { c.close(); tcp.remove(c); }
                    if (udp != null && now - lastStun > 20000) {
                        udp.stun();
                        lastStun = now;
                    }
                    Thread.sleep(punching.isEmpty() ? 1000 : 300);
                }
            } catch (Exception ignored) {
            } finally {
                if (ds != null) ds.close();
            }
        }

        String publicEp() {
            return udp == null ? null : udp.publicEp;
        }

        int udpPort() {
            return udp == null ? -1 : udp.sock.getLocalPort();
        }

        void punch(String ep) {
            if (ep != null && ep.contains(":") && !punching.containsKey(ep)) punching.put(ep, System.currentTimeMillis());
        }

        int peers() {
            return tcp.size() + udpPeers.size();
        }

        boolean congested() {
            for (TcpConn c : tcp) if (c.queued.get() > 120_000) return true;
            return false;
        }

        void send(byte kind, byte[] sealed, boolean live, boolean key) {
            boolean onlyWanted = live && !key;      // klatki kluczowe idą wszędzie – widz wie, że droga działa
            for (TcpConn c : tcp) if (!onlyWanted || c.wanted) c.send(kind, sealed, live, key);
            Udp u = udp;
            if (u != null) for (Object[] p : udpPeers.values())
                if (!onlyWanted || p.length < 3 || Boolean.TRUE.equals(p[2])) u.send((SocketAddress) p[0], kind, sealed);
        }

        /** Widz powiedział, którą drogą ogląda – na pozostałych tylko klatki kluczowe. */
        void setWanted(Object peer, boolean w) {
            if (peer instanceof TcpConn) ((TcpConn) peer).wanted = w;
            else if (peer instanceof SocketAddress) {
                Object[] p = udpPeers.get(peer.toString());
                if (p != null) udpPeers.put(peer.toString(), new Object[]{p[0], p[1], w});
            }
        }

        void reply(Object peer, byte kind, byte[] sealed) {
            if (peer instanceof TcpConn) ((TcpConn) peer).send(kind, sealed, false, false);
            else if (peer instanceof SocketAddress && udp != null) udp.send((SocketAddress) peer, kind, sealed);
        }

        void stop() {
            running = false;
            try { if (ss != null) ss.close(); } catch (Exception ignored) { }
            for (TcpConn c : tcp) c.close();
            if (udp != null) udp.close();
        }
    }

    // ======================================================================= PODGLĄD

    static final class Client {
        private final String base;
        private final Sink sink;
        private final boolean lan, p2p;
        private final String manualIp;
        private volatile TcpConn conn;
        private Udp udp;
        private volatile SocketAddress camEp;
        private volatile String camEpStr;
        private volatile boolean running = true;
        private DatagramSocket beacon;
        volatile String lanAddr = null;

        Client(String base, Sink sink, boolean lan, boolean p2p, String manualIp) {
            this.base = base;
            this.sink = sink;
            this.lan = lan;
            this.p2p = p2p;
            this.manualIp = manualIp == null ? "" : manualIp.trim();
            if (lan) {
                Thread t = new Thread(this::beaconLoop, "beacon-rx");
                t.setDaemon(true);
                t.start();
                if (!this.manualIp.isEmpty()) {
                    Thread m = new Thread(this::manualLoop, "manual");
                    m.setDaemon(true);
                    m.start();
                }
            }
            if (p2p) {
                try {
                    udp = new Udp(sink, 0);
                    udp.stun();
                } catch (Exception ignored) { }
            }
        }

        private void beaconLoop() {
            try {
                beacon = new DatagramSocket(null);
                beacon.setReuseAddress(true);
                beacon.setBroadcast(true);
                beacon.bind(new InetSocketAddress(BEACON_PORT));
                byte[] buf = new byte[512];
                while (running) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    beacon.receive(p);
                    String[] s = new String(buf, 0, p.getLength(), StandardCharsets.UTF_8).split(" ");
                    if (s.length == 3 && s[0].equals("BCAM1") && s[1].equals(base) && conn == null)
                        connect(p.getAddress().getHostAddress(), Integer.parseInt(s[2]));
                }
            } catch (Exception ignored) { }
        }

        private void manualLoop() {
            while (running) {
                if (conn == null) {
                    String ip = manualIp;
                    int port = TCP_PORT;
                    if (ip.contains(":")) {
                        port = Integer.parseInt(ip.substring(ip.indexOf(':') + 1).trim());
                        ip = ip.substring(0, ip.indexOf(':'));
                    }
                    connect(ip, port);
                }
                Link.sleep(3000);
            }
        }

        private synchronized void connect(String ip, int port) {
            if (conn != null || !running) return;
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, port), 3000);
                TcpConn c = new TcpConn(s, (k, p, via, peer) -> sink.onPacket(k, p, via, peer), "lan", null);
                conn = c;
                lanAddr = ip;
                Thread watch = new Thread(() -> {
                    while (running && c.alive) Link.sleep(500);
                    if (conn == c) { conn = null; lanAddr = null; }
                }, "lan-watch");
                watch.setDaemon(true);
                watch.start();
            } catch (Exception ignored) { }
        }

        boolean lanUp() {
            TcpConn c = conn;
            return c != null && c.alive;
        }

        String publicEp() {
            return udp == null ? null : udp.publicEp;
        }

        /** Adres P2P bodycama (z jego statusu) – zaczynamy przebijać NAT. */
        void camEndpoint(String ep) {
            if (!p2p || ep == null || ep.equals(camEpStr)) return;
            camEpStr = ep;
            camEp = parseEp(ep);
        }

        void restun() {
            if (udp != null) udp.stun();
        }

        /** Hello (sterowanie) wysyłane wszystkimi drogami bezpośrednimi + przebijanie NAT. */
        void sendCtl(byte[] sealed) {
            TcpConn c = conn;
            if (c != null) c.send(K_CTL, sealed, false, false);
            Udp u = udp;
            SocketAddress ep = camEp;
            if (u != null && ep != null) {
                u.send(ep, K_PUNCH, null);
                u.send(ep, K_CTL, sealed);
            }
        }

        void stop() {
            running = false;
            TcpConn c = conn;
            if (c != null) c.close();
            if (udp != null) udp.close();
            if (beacon != null) beacon.close();
        }
    }
}
