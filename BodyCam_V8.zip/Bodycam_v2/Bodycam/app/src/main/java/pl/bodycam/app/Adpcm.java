package pl.bodycam.app;

/** IMA ADPCM 4 bity/próbkę. Każdy pakiet niezależny (nagłówek: predyktor + indeks) – zgubiony pakiet nie psuje kolejnych. */
final class Adpcm {

    private static final int[] IDX = {-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8};
    private static final int[] STEP = {7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
            50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371,
            408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
            2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493,
            10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767};

    private int pred = 0, index = 0;

    /** Zwraca: [pred lo, pred hi, index, n lo, n hi] + n/2 bajtów. */
    byte[] encode(short[] pcm, int n) {
        byte[] out = new byte[5 + (n + 1) / 2];
        out[0] = (byte) pred;
        out[1] = (byte) (pred >> 8);
        out[2] = (byte) index;
        out[3] = (byte) n;
        out[4] = (byte) (n >> 8);
        for (int i = 0; i < n; i++) {
            int step = STEP[index];
            int diff = pcm[i] - pred, code = 0;
            if (diff < 0) {
                code = 8;
                diff = -diff;
            }
            int dq = step >> 3;
            if (diff >= step) { code |= 4; diff -= step; dq += step; }
            step >>= 1;
            if (diff >= step) { code |= 2; diff -= step; dq += step; }
            step >>= 1;
            if (diff >= step) { code |= 1; dq += step; }
            pred += (code & 8) != 0 ? -dq : dq;
            if (pred > 32767) pred = 32767;
            else if (pred < -32768) pred = -32768;
            index += IDX[code];
            if (index < 0) index = 0;
            else if (index > 88) index = 88;
            if ((i & 1) == 0) out[5 + i / 2] = (byte) code;
            else out[5 + i / 2] |= (byte) (code << 4);
        }
        return out;
    }

    static short[] decode(byte[] in, int off, int len) {
        if (len < 5) return new short[0];
        int pred = (short) ((in[off] & 0xFF) | (in[off + 1] << 8));
        int index = Math.max(0, Math.min(88, in[off + 2] & 0xFF));
        int n = (in[off + 3] & 0xFF) | (in[off + 4] & 0xFF) << 8;
        n = Math.min(n, (len - 5) * 2);
        short[] out = new short[n];
        for (int i = 0; i < n; i++) {
            int b = in[off + 5 + i / 2] & 0xFF;
            int code = (i & 1) == 0 ? b & 15 : b >> 4;
            int step = STEP[index];
            int dq = step >> 3;
            if ((code & 4) != 0) dq += step;
            if ((code & 2) != 0) dq += step >> 1;
            if ((code & 1) != 0) dq += step >> 2;
            pred += (code & 8) != 0 ? -dq : dq;
            if (pred > 32767) pred = 32767;
            else if (pred < -32768) pred = -32768;
            index += IDX[code];
            if (index < 0) index = 0;
            else if (index > 88) index = 88;
            out[i] = (short) pred;
        }
        return out;
    }
}
