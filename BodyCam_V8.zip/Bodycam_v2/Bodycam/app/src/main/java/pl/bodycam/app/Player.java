package pl.bodycam.app;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Build;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Odtwarzanie podglądu: dekoder H.264 prosto na ekran (bez buforowania – minimalne opóźnienie)
 * i dźwięk z małym buforem. Gdy coś się spóźnia, odrzucamy zaległości zamiast narastającego opóźnienia.
 */
final class Player {

    interface Events {
        void onSize(int w, int h);
        void needKey();
    }

    private static final class Pkt {
        boolean key;
        int seq, w, h;
        long pts;
        byte[] d;
    }

    private final Events ev;
    private final LinkedBlockingQueue<Pkt> vq = new LinkedBlockingQueue<>();
    private final LinkedBlockingQueue<short[]> aq = new LinkedBlockingQueue<>();
    private volatile Surface surface;
    private volatile boolean running = true;
    private MediaCodec dec;
    private int dw, dh, lastSeq = -1;
    private byte[] sps;
    private boolean waitKey = true;
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    volatile boolean muted = false;
    volatile int fpsCount;
    volatile long delayMs = -1;

    Player(Events e) {
        ev = e;
        Thread v = new Thread(this::videoLoop, "dec");
        v.setDaemon(true);
        v.start();
        Thread a = new Thread(this::audioLoop, "play");
        a.setDaemon(true);
        a.start();
    }

    void setSurface(Surface s) {
        surface = s;
        vq.clear();
        Pkt reset = new Pkt();
        reset.seq = Integer.MIN_VALUE;
        vq.offer(reset);
    }

    void video(boolean key, int seq, long pts, int w, int h, byte[] d, int off, int len) {
        Pkt p = new Pkt();
        p.key = key;
        p.seq = seq;
        p.pts = pts;
        p.w = w;
        p.h = h;
        p.d = Arrays.copyOfRange(d, off, off + len);
        if (vq.size() > 10) {      // zaległości – zaczynamy od najbliższej klatki kluczowej
            vq.clear();
            ev.needKey();
        }
        vq.offer(p);
    }

    void audio(byte[] d, int off, int len) {
        short[] s = Adpcm.decode(d, off, len);
        if (aq.size() > 8) while (aq.size() > 3) aq.poll();   // dogonienie na żywo
        aq.offer(s);
    }

    private void videoLoop() {
        while (running) {
            Pkt p;
            try {
                p = vq.poll(300, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                break;
            }
            if (p == null) {
                if (dec != null) drain();
                continue;
            }
            if (p.seq == Integer.MIN_VALUE) {   // nowa powierzchnia
                releaseDec();
                waitKey = true;
                continue;
            }
            if (lastSeq >= 0 && p.seq != lastSeq + 1 && !p.key) waitKey = true;  // dziura w strumieniu
            lastSeq = p.seq;
            if (waitKey && !p.key) {
                continue;
            }
            try {
                if (p.key) {
                    byte[] nSps = nal(p.d, 7);
                    if (dec == null || p.w != dw || p.h != dh || (nSps != null && !Arrays.equals(nSps, sps))) {
                        releaseDec();
                        startDec(p, nSps);
                    }
                }
                if (dec == null) continue;
                waitKey = false;
                int idx = dec.dequeueInputBuffer(20000);
                if (idx >= 0) {
                    ByteBuffer ib = dec.getInputBuffer(idx);
                    if (ib != null) {
                        ib.clear();
                        ib.put(p.d);
                        dec.queueInputBuffer(idx, 0, p.d.length, p.pts * 1000, 0);
                    }
                }
                delayMs = System.currentTimeMillis() - p.pts;
                drain();
            } catch (Exception e) {
                releaseDec();
                waitKey = true;
                ev.needKey();
            }
        }
        releaseDec();
    }

    private void startDec(Pkt p, byte[] nSps) throws Exception {
        Surface s = surface;
        if (s == null) return;
        byte[] pps = nal(p.d, 8);
        MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, p.w, p.h);
        if (nSps != null) f.setByteBuffer("csd-0", ByteBuffer.wrap(withStart(nSps)));
        if (pps != null) f.setByteBuffer("csd-1", ByteBuffer.wrap(withStart(pps)));
        if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
        f.setInteger(MediaFormat.KEY_PRIORITY, 0);
        dec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        dec.configure(f, s, null, 0);
        dec.start();
        dw = p.w;
        dh = p.h;
        sps = nSps;
        ev.onSize(p.w, p.h);
    }

    private void drain() {
        while (true) {
            int o = dec.dequeueOutputBuffer(info, 0);
            if (o >= 0) {
                dec.releaseOutputBuffer(o, true);
                fpsCount++;
            } else if (o == MediaCodec.INFO_TRY_AGAIN_LATER) break;
        }
    }

    private void releaseDec() {
        if (dec == null) return;
        try { dec.stop(); } catch (Exception ignored) { }
        try { dec.release(); } catch (Exception ignored) { }
        dec = null;
        sps = null;
    }

    /** Wyciąga jednostkę NAL danego typu (bez kodu startu) z Annex B. */
    static byte[] nal(byte[] d, int type) {
        int n = d.length, i = 0;
        while (i + 3 < n) {
            int sc = startCode(d, i);
            if (sc == 0) { i++; continue; }
            int s = i + sc;
            int j = s;
            while (j + 3 < n && startCode(d, j) == 0) j++;
            int e = j + 3 < n ? j : n;
            if (s < n && (d[s] & 0x1F) == type) return Arrays.copyOfRange(d, s, e);
            i = e;
        }
        return null;
    }

    private static int startCode(byte[] d, int i) {
        if (d[i] == 0 && d[i + 1] == 0) {
            if (d[i + 2] == 1) return 3;
            if (d[i + 2] == 0 && i + 3 < d.length && d[i + 3] == 1) return 4;
        }
        return 0;
    }

    private static byte[] withStart(byte[] n) {
        byte[] o = new byte[n.length + 4];
        o[3] = 1;
        System.arraycopy(n, 0, o, 4, n.length);
        return o;
    }

    private void audioLoop() {
        AudioTrack t = null;
        try {
            int min = AudioTrack.getMinBufferSize(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(16000)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(Math.max(min, 6400)).build();
            t.play();
            boolean primed = false;
            while (running) {
                if (!primed) {         // mały zapas na nierówne przychodzenie pakietów
                    if (aq.size() < 3) { Thread.sleep(20); continue; }
                    primed = true;
                }
                short[] s = aq.poll(400, TimeUnit.MILLISECONDS);
                if (s == null) { primed = false; continue; }
                if (muted) java.util.Arrays.fill(s, (short) 0);
                t.write(s, 0, s.length);
            }
        } catch (Exception ignored) {
        } finally {
            if (t != null) {
                try { t.stop(); } catch (Exception ignored) { }
                t.release();
            }
        }
    }

    void stop() {
        running = false;
        vq.offer(new Pkt());
    }
}
