package pl.bodycam.app;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Minimalny klient MQTT 3.1.1 (QoS 0) po TLS. Serwer pośredniczący przekazuje dane między telefonami,
 * więc nie trzeba być w tej samej sieci ani nic konfigurować. Treść jest dodatkowo szyfrowana (Link).
 */
final class Mqtt {

    interface Listener {
        void onMessage(String topic, byte[] payload);
        void onLost();
    }

    static final long MAX_QUEUE = 450_000; // bajtów w kolejce – powyżej odrzucamy dane "na żywo"

    private final Socket sock;
    private final InputStream in;
    private final OutputStream out;
    private final Listener listener;
    private final LinkedBlockingDeque<byte[]> q = new LinkedBlockingDeque<>();
    private final AtomicLong queued = new AtomicLong();
    private volatile boolean alive = true;
    private int nextId = 1;
    final String server;

    private Mqtt(Socket s, Listener l, String server) throws IOException {
        sock = s;
        in = s.getInputStream();
        out = s.getOutputStream();
        listener = l;
        this.server = server;
    }

    static Mqtt connect(String host, int port, boolean tls, String clientId, String willTopic, byte[] will,
                        Listener l, int timeoutMs) throws IOException {
        Socket s;
        if (tls) {
            Socket raw = new Socket();
            raw.connect(new InetSocketAddress(host, port), timeoutMs);
            SSLSocket ss = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(raw, host, port, true);
            ss.setSoTimeout(timeoutMs);
            ss.startHandshake();
            if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ss.getSession())) {
                ss.close();
                throw new IOException("zły certyfikat serwera");
            }
            s = ss;
        } else {
            s = new Socket();
            s.connect(new InetSocketAddress(host, port), timeoutMs);
        }
        s.setTcpNoDelay(true);
        s.setSoTimeout(timeoutMs);
        Mqtt m = new Mqtt(s, l, host);
        try {
            m.handshake(clientId, willTopic, will);
        } catch (IOException e) {
            m.close();
            throw e;
        }
        s.setSoTimeout(65_000);
        Thread r = new Thread(m::readLoop, "mqtt-in");
        r.setDaemon(true);
        r.start();
        Thread w = new Thread(m::writeLoop, "mqtt-out");
        w.setDaemon(true);
        w.start();
        return m;
    }

    private void handshake(String clientId, String willTopic, byte[] will) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        str(b, "MQTT");
        b.write(4);
        int flags = 0x02;
        if (willTopic != null) flags |= 0x04 | 0x20;
        b.write(flags);
        b.write(0);
        b.write(30); // keepalive 30 s
        str(b, clientId);
        if (willTopic != null) {
            str(b, willTopic);
            bin(b, will);
        }
        out.write(packet(0x10, b.toByteArray()));
        out.flush();
        DataInputStream d = new DataInputStream(in);
        int h = d.readUnsignedByte();
        int len = readLen(d);
        byte[] body = new byte[len];
        d.readFully(body);
        if ((h & 0xF0) != 0x20 || len < 2 || body[1] != 0) throw new IOException("serwer odrzucił połączenie");
    }

    boolean alive() {
        return alive;
    }

    long queuedBytes() {
        return queued.get();
    }

    /** droppable = dane na żywo; gdy łącze nie nadąża, zwraca false zamiast zapychać kolejkę. */
    boolean publish(String topic, byte[] data, boolean retain, boolean droppable) {
        if (!alive) return false;
        if (droppable && queued.get() > MAX_QUEUE) return false;
        ByteArrayOutputStream b = new ByteArrayOutputStream(data.length + topic.length() + 8);
        str(b, topic);
        b.write(data, 0, data.length);
        byte[] p = packet(0x30 | (retain ? 1 : 0), b.toByteArray());
        queued.addAndGet(p.length);
        q.offer(p);
        return true;
    }

    void subscribe(String... topics) {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int id = nextId++;
        b.write(id >> 8);
        b.write(id);
        for (String t : topics) {
            str(b, t);
            b.write(0);
        }
        byte[] p = packet(0x82, b.toByteArray());
        queued.addAndGet(p.length);
        q.offerFirst(p);
    }

    void close() {
        if (!alive) return;
        alive = false;
        try {
            out.write(new byte[]{(byte) 0xE0, 0});
            out.flush();
        } catch (Exception ignored) { }
        try { sock.close(); } catch (Exception ignored) { }
        q.offer(new byte[0]);
    }

    private void lost() {
        boolean was = alive;
        alive = false;
        try { sock.close(); } catch (Exception ignored) { }
        q.offer(new byte[0]);
        if (was) listener.onLost();
    }

    private void writeLoop() {
        long lastSend = System.currentTimeMillis();
        try {
            while (alive) {
                byte[] p = q.poll(5, TimeUnit.SECONDS);
                long now = System.currentTimeMillis();
                if (p == null) {
                    if (now - lastSend > 15_000) {
                        out.write(new byte[]{(byte) 0xC0, 0});
                        out.flush();
                        lastSend = now;
                    }
                    continue;
                }
                if (p.length == 0) break;
                out.write(p);
                queued.addAndGet(-p.length);
                if (q.isEmpty()) out.flush();
                lastSend = now;
            }
        } catch (Exception e) {
            lost();
        }
    }

    private void readLoop() {
        DataInputStream d = new DataInputStream(in);
        try {
            while (alive) {
                int h = d.readUnsignedByte();
                int len = readLen(d);
                if (len > 8_000_000) throw new IOException("za duży pakiet");
                byte[] body = new byte[len];
                d.readFully(body);
                if ((h & 0xF0) == 0x30) {
                    int tl = (body[0] & 0xFF) << 8 | (body[1] & 0xFF);
                    String topic = new String(body, 2, tl, StandardCharsets.UTF_8);
                    int off = 2 + tl;
                    if (((h >> 1) & 3) > 0) off += 2;
                    byte[] payload = new byte[len - off];
                    System.arraycopy(body, off, payload, 0, payload.length);
                    try {
                        listener.onMessage(topic, payload);
                    } catch (Exception ignored) { }
                }
            }
        } catch (Exception e) {
            lost();
        }
    }

    private static int readLen(DataInputStream d) throws IOException {
        int mul = 1, v = 0, b;
        do {
            b = d.readUnsignedByte();
            v += (b & 127) * mul;
            mul *= 128;
            if (mul > 128 * 128 * 128 * 128) throw new IOException("zła długość");
        } while ((b & 128) != 0);
        return v;
    }

    private static byte[] packet(int header, byte[] body) {
        ByteArrayOutputStream b = new ByteArrayOutputStream(body.length + 5);
        b.write(header);
        int len = body.length;
        do {
            int d = len % 128;
            len /= 128;
            if (len > 0) d |= 128;
            b.write(d);
        } while (len > 0);
        b.write(body, 0, body.length);
        return b.toByteArray();
    }

    private static void str(ByteArrayOutputStream b, String s) {
        bin(b, s.getBytes(StandardCharsets.UTF_8));
    }

    private static void bin(ByteArrayOutputStream b, byte[] x) {
        b.write(x.length >> 8);
        b.write(x.length);
        b.write(x, 0, x.length);
    }
}
