package pl.bodycam.app;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Dźwięki bodycama.
 *  start: dwa krótkie piki + "Nagrywanie rozpoczęte"
 *  stop:  długi pik + "Nagrywanie zakończone"
 *  przytrzymanie "głośniej": "Nagrywam" / "Nie nagrywam"
 *  co 2 minuty w trakcie nagrywania: assets/beep.mp3
 * Głos: żeński polski głos syntezatora, przepuszczony przez filtr "małego głośniczka" jak w kamerze.
 * Własne nagrania głosu (mp3/wav) w assets mają pierwszeństwo – patrz assets/GLOS_INSTRUKCJA.txt.
 */
final class Sound {

    static final String START = "start", STOP = "stop", ON = "on", OFF = "off";
    private static final String[][] PHRASES = {
            {START, "Nagrywanie rozpoczęte"}, {STOP, "Nagrywanie zakończone"},
            {ON, "Nagrywam"}, {OFF, "Nie nagrywam"}};

    private static Sound inst;
    private final Context ctx;
    private TextToSpeech tts;
    private volatile boolean ttsOk;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, short[]> pcm = new ConcurrentHashMap<>();
    private volatile int pcmRate = 22050;
    private final List<Voice> plVoices = new ArrayList<>();
    private MediaPlayer mp;

    static synchronized Sound get(Context c) {
        if (inst == null) inst = new Sound(c);
        return inst;
    }

    /** Napis na ekranie przy każdym komunikacie (ustawia ekran bodycama). */
    interface Banner { void show(String text); }

    static volatile Banner banner;

    private static void showText(String t) {
        Banner b = banner;
        if (b != null) b.show(t);
    }

    // silniki mowy próbowane po kolei: domyślny, Google, Samsung
    private static final String[] ENGINES = {null, "com.google.android.tts", "com.samsung.SMT"};
    private int engineIdx = 0;
    private volatile String pending;   // komunikat czekający, aż syntezator będzie gotowy

    private Sound(Context c) {
        ctx = c.getApplicationContext();
        initTts();
    }

    private void initTts() {
        if (engineIdx >= ENGINES.length) return;
        final String eng = ENGINES[engineIdx];
        try {
            TextToSpeech.OnInitListener l = status -> {
                boolean ok = false;
                if (status == TextToSpeech.SUCCESS) {
                    int r = tts.setLanguage(new Locale("pl", "PL"));
                    ok = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                }
                if (!ok) {     // ten silnik nie umie po polsku – następny
                    try { tts.shutdown(); } catch (Exception ignored) { }
                    tts = null;
                    engineIdx++;
                    main.post(this::initTts);
                    return;
                }
                ttsOk = true;
                pickVoice();
                prerender();
                String p = pending;
                pending = null;
                if (p != null) main.post(() -> say(p));
            };
            tts = eng == null ? new TextToSpeech(ctx, l) : new TextToSpeech(ctx, l, eng);
        } catch (Exception e) {
            engineIdx++;
            main.post(this::initTts);
        }
    }

    // =========================================================== zdarzenia (jak Axon Body 3 / 4)
    // Wszystkie sygnały są składane z Twojego piknięcia: assets/beep_1.wav (wycięte z beep.mp3).

    private static boolean muted() {
        return App.b("mute", false);
    }

    /** Włączenie: dwa krótkie, rosnąco + długa wibracja. */
    void powerOn() {
        showText("KAMERA WŁĄCZONA");
        vibrate(new long[]{0, 500});
        if (!muted()) play(seq(80, shortBeep(0.94f), shortBeep(1f)));
    }

    /** Wyłączenie: trzy krótkie, opadająco + długa wibracja. */
    void powerOff() {
        showText("KAMERA WYŁĄCZONA");
        vibrate(new long[]{0, 500});
        if (!muted()) play(seq(80, shortBeep(1f), shortBeep(0.94f), shortBeep(0.89f)));
    }

    /** Start nagrywania: dwa krótkie + dwie krótkie wibracje, potem "Nagrywanie rozpoczęte". */
    void recStart() {
        showText("● NAGRYWANIE ROZPOCZĘTE");
        vibrate(new long[]{0, 90, 80, 90});
        if (muted()) return;
        int ms = play(seq(35, fullBeep(1f), fullBeep(1f)));
        if (App.voice()) main.postDelayed(() -> say(START), ms + 120);
    }

    /** Stop / gotowość: jeden długi + długa wibracja, potem "Nagrywanie zakończone". */
    void recStop() {
        showText("■ NAGRYWANIE ZAKOŃCZONE");
        vibrate(new long[]{0, 600});
        if (muted()) return;
        int ms = play(longBeep(750, 1f));
        if (App.voice()) main.postDelayed(() -> say(STOP), ms + 120);
    }

    /** Co 2 minuty w trakcie nagrywania: dwa krótkie + krótka wibracja. */
    void reminder() {
        showText("● NAGRYWANIE TRWA");
        vibrate(new long[]{0, 120});
        if (!muted()) play(seq(35, fullBeep(1f), fullBeep(1f)));
    }

    /** Tryb wyciszenia (wejście/wyjście): jeden krótki + dwie długie wibracje. Ten pik gra zawsze. */
    void muteToggle() {
        showText(App.b("mute", false) ? "TRYB WYCISZENIA WŁ." : "TRYB WYCISZENIA WYŁ.");
        vibrate(new long[]{0, 400, 250, 400});
        play(shortBeep(1f));
    }

    /** Niski poziom baterii (10 % i 5 %): cztery szybkie, wysokie + cztery krótkie wibracje. */
    void lowBattery() {
        showText("NISKI POZIOM BATERII");
        vibrate(new long[]{0, 70, 70, 70, 70, 70, 70, 70});
        if (!muted()) play(seq(50, cut(shortBeep(1f), 80), cut(shortBeep(1f), 80), cut(shortBeep(1f), 80), cut(shortBeep(1f), 80)));
    }

    /** Parowanie (ktoś zaczął oglądać podgląd): trzy krótkie rosnąco, bez wibracji. */
    void pairing() {
        showText("PODGLĄD POŁĄCZONY");
        if (!muted()) play(seq(70, shortBeep(0.89f), shortBeep(0.94f), shortBeep(1f)));
    }

    /** Przytrzymanie przycisku: czy kamera nagrywa. W wyciszeniu – tylko wibracje. */
    void status(boolean rec) {
        showText(rec ? "● NAGRYWAM" : "NIE NAGRYWAM");
        vibrate(rec ? new long[]{0, 90, 80, 90} : new long[]{0, 600});
        if (!muted()) say(rec ? ON : OFF);
    }

    /** Krótki dźwięk migawki przy zdjęciu. */
    void click() {
        if (!muted()) play(cut(shortBeep(1f), 45));
    }

    // =========================================================== składanie piknięć

    private static final int SR = 44100;
    private short[] beep;

    private short[] base() {
        if (beep != null) return beep;
        try (java.io.InputStream in = ctx.getAssets().open("beep_1.wav")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            beep = parseWav(bo.toByteArray(), null);
        } catch (Exception ignored) { }
        if (beep == null || beep.length < SR / 10) {   // brak pliku – podobny ton 4 kHz
            int n = (int) (SR * 0.3);
            beep = new short[n];
            for (int i = 0; i < n; i++) {
                double t = (double) i / SR, env = Math.min(1, i / (SR * 0.01)) * Math.min(1, (n - i) / (SR * 0.02));
                beep[i] = (short) (env * 8000 * (Math.sin(2 * Math.PI * 4000 * t) * 0.7 + 0.3 * Math.sin(2 * Math.PI * 8000 * t)));
            }
        }
        return beep;
    }

    private short[] fullBeep(float pitch) {
        return resample(base(), pitch);
    }

    private short[] shortBeep(float pitch) {
        return resample(cut(base(), 140), pitch);
    }

    /** Długi pik: początek + powtarzany środek (441 próbek = pełne okresy tonu, bez trzasków) + koniec. */
    private short[] longBeep(int ms, float pitch) {
        short[] b = base();
        int att = Math.min(b.length / 3, SR * 60 / 1000), rel = Math.min(b.length / 3, SR * 50 / 1000);
        int loopAt = Math.min(b.length - rel - 441, SR / 10);
        int total = SR * ms / 1000;
        short[] out = new short[total];
        System.arraycopy(b, 0, out, 0, Math.min(att, total));
        int pos = att;
        while (pos < total - rel) {
            int k = loopAt + ((pos - att) % 441);
            out[pos++] = b[Math.max(0, Math.min(b.length - 1, k))];
        }
        for (int i = 0; i < rel && pos < total; i++) out[pos++] = b[b.length - rel + i];
        return resample(out, pitch);
    }

    private static short[] cut(short[] s, int ms) {
        int n = Math.min(s.length, SR * ms / 1000), f = Math.min(n, SR * 12 / 1000);
        short[] o = java.util.Arrays.copyOf(s, n);
        for (int i = 0; i < f; i++) o[n - 1 - i] = (short) (o[n - 1 - i] * i / f);
        return o;
    }

    private static short[] resample(short[] s, float p) {
        if (Math.abs(p - 1f) < 0.001f) return s;
        int n = (int) (s.length / p);
        short[] o = new short[n];
        for (int i = 0; i < n; i++) {
            float x = i * p;
            int a = (int) x;
            float t = x - a;
            int b2 = Math.min(s.length - 1, a + 1);
            o[i] = (short) (s[Math.min(a, s.length - 1)] * (1 - t) + s[b2] * t);
        }
        return o;
    }

    private static short[] seq(int gapMs, short[]... parts) {
        int gap = SR * gapMs / 1000, n = 0;
        for (short[] p : parts) n += p.length + gap;
        short[] o = new short[n];
        int pos = 0;
        for (short[] p : parts) {
            System.arraycopy(p, 0, o, pos, p.length);
            pos += p.length + gap;
        }
        return o;
    }

    /** Odtwarza i zwraca czas trwania w ms. */
    private int play(short[] p) {
        playPcm(p, SR);
        return p.length * 1000 / SR;
    }

    // =========================================================== głos

    void say(String key) {
        if (playAsset("glos_" + key)) return;
        short[] p = pcm.get(key);
        if (p != null) {
            playPcm(p, pcmRate);
            return;
        }
        if (tts != null && ttsOk) {   // jeszcze nieprzygotowane – zwykła mowa
            Bundle b = new Bundle();
            b.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_ALARM);
            int r = tts.speak(text(key), TextToSpeech.QUEUE_FLUSH, b, "bc");
            if (r == TextToSpeech.ERROR) pending = key;
        } else {
            pending = key;          // powie, gdy syntezator się uruchomi
            if (tts == null && engineIdx >= ENGINES.length) {   // spróbuj od nowa
                engineIdx = 0;
                initTts();
            }
        }
    }

    private static String text(String key) {
        for (String[] p : PHRASES) if (p[0].equals(key)) return p[1];
        return key;
    }

    /** Polskie głosy w telefonie (do wyboru w ustawieniach). */
    List<String> voices() {
        List<String> out = new ArrayList<>();
        for (Voice v : plVoices) out.add(v.getName());
        return out;
    }

    String currentVoice() {
        try {
            Voice v = tts == null ? null : tts.getVoice();
            return v == null ? "domyślny" : v.getName();
        } catch (Exception e) {
            return "domyślny";
        }
    }

    /** Zmiana wysokości głosu / efektu – nagrywa komunikaty od nowa. */
    void refresh() {
        pickVoice();
        prerender();
    }

    void setVoice(String name) {
        App.put("voicename", name);
        pickVoice();
        prerender();
    }

    private void pickVoice() {
        if (tts == null) return;
        plVoices.clear();
        try {
            for (Voice v : tts.getVoices()) {
                Locale l = v.getLocale();
                if (l == null || !"pl".equals(l.getLanguage())) continue;
                if (v.isNetworkConnectionRequired()) continue;                       // bez sieci by milczał
                java.util.Set<String> f = v.getFeatures();
                if (f != null && f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                plVoices.add(v);
            }
        } catch (Exception ignored) { }
        java.util.Collections.sort(plVoices, (x, y) -> Integer.compare(score(y), score(x)));
        String want = App.s("voicename", "");
        Voice pick = null;
        for (Voice v : plVoices) if (v.getName().equals(want)) pick = v;
        if (pick == null && !plVoices.isEmpty()) pick = plVoices.get(0);
        try {
            if (pick != null) tts.setVoice(pick);
        } catch (Exception ignored) { }
        tts.setPitch(App.i("vpitch", 88) / 100f);   // niżej = mniej piskliwie
        tts.setSpeechRate(0.92f);
    }

    /** Wybór głosu żeńskiego z nazw (Samsung: "...f00", Google: oda/afb/zfg). */
    private static int score(Voice v) {
        String n = v.getName().toLowerCase(Locale.ROOT);
        int s = 0;
        if (n.contains("female") || n.contains("smtf") || n.matches(".*-f0\\d.*")) s += 10;
        if (n.contains("smtm") || (n.contains("male") && !n.contains("female")) || n.matches(".*-m0\\d.*")) s -= 10;
        for (String f : new String[]{"-x-oda", "-x-afb", "-x-zfg"}) if (n.contains(f)) s += 8;
        for (String m : new String[]{"-x-bmg", "-x-jmk"}) if (n.contains(m)) s -= 8;
        try {
            if (!v.isNetworkConnectionRequired()) s += 3;
            if (v.getQuality() >= Voice.QUALITY_HIGH) s += 1;
        } catch (Exception ignored) { }
        return s;
    }

    /** Nagrywa wszystkie komunikaty do plików i nakłada filtr głośniczka – potem odtwarza bez opóźnienia. */
    private void prerender() {
        if (tts == null || !ttsOk) return;
        pcm.clear();
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String id) { }

            @Override
            public void onDone(String id) {
                if (!id.startsWith("r_")) return;
                String key = id.substring(2);
                File f = new File(ctx.getCacheDir(), "tts_" + key + ".wav");
                short[] p = loadWav(f);
                if (p != null && p.length > 0) pcm.put(key, speaker(p, pcmRate));
            }

            @Override
            public void onError(String id) { }
        });
        for (String[] p : PHRASES) {
            File f = new File(ctx.getCacheDir(), "tts_" + p[0] + ".wav");
            try {
                tts.synthesizeToFile(p[1], new Bundle(), f, "r_" + p[0]);
            } catch (Exception ignored) { }
        }
    }

    private short[] loadWav(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] all = new byte[(int) f.length()];
            int o = 0, r;
            while (o < all.length && (r = in.read(all, o, all.length - o)) > 0) o += r;
            int[] rate = new int[1];
            short[] p = parseWav(all, rate);
            if (p != null) pcmRate = rate[0];
            return p;
        } catch (Exception ignored) { }
        return null;
    }

    private static short[] parseWav(byte[] all, int[] rateOut) {
        try {
            ByteBuffer b = ByteBuffer.wrap(all).order(ByteOrder.LITTLE_ENDIAN);
            if (all.length < 44 || b.getInt(0) != 0x46464952) return null;   // "RIFF"
            int pos = 12, rate = 22050, ch = 1, bits = 16;
            while (pos + 8 <= all.length) {
                int id = b.getInt(pos), len = b.getInt(pos + 4);
                if (id == 0x20746d66) {            // "fmt "
                    ch = b.getShort(pos + 10);
                    rate = b.getInt(pos + 12);
                    bits = b.getShort(pos + 22);
                } else if (id == 0x61746164) {     // "data"
                    if (bits != 16) return null;
                    int n = Math.min(len, all.length - pos - 8) / 2 / Math.max(1, ch);
                    short[] out = new short[n];
                    for (int i = 0; i < n; i++) out[i] = b.getShort(pos + 8 + i * 2 * ch);
                    if (rateOut != null) rateOut[0] = rate;
                    return out;
                }
                pos += 8 + len + (len & 1);
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Brzmienie małego głośnika kamery: pasmo 400 Hz–4 kHz, lekkie przesterowanie, podbita prezencja. */
    static short[] speaker(short[] in, int rate) {
        if (!App.b("radiofx", true)) return in;
        double[] hp = biquad(rate, 200, 0.707, true), lp = biquad(rate, 5500, 0.707, false), pk = peak(rate, 1200, 0.9, 2.5);
        double[] s1 = new double[4], s2 = new double[4], s3 = new double[4];
        short[] out = new short[in.length];
        double peakAbs = 0;
        double[] tmp = new double[in.length];
        for (int i = 0; i < in.length; i++) {
            double x = in[i] / 32768.0;
            x = run(hp, s1, x);
            x = run(lp, s2, x);
            x = run(pk, s3, x);
            x = Math.tanh(x * 1.3) / Math.tanh(1.3);
            tmp[i] = x;
            peakAbs = Math.max(peakAbs, Math.abs(x));
        }
        double g = peakAbs > 0 ? 0.9 / peakAbs : 1;
        for (int i = 0; i < in.length; i++) out[i] = (short) Math.max(-32767, Math.min(32767, tmp[i] * g * 32767));
        return out;
    }

    private static double run(double[] c, double[] s, double x) {
        double y = c[0] * x + c[1] * s[0] + c[2] * s[1] - c[3] * s[2] - c[4] * s[3];
        s[1] = s[0];
        s[0] = x;
        s[3] = s[2];
        s[2] = y;
        return y;
    }

    private static double[] biquad(int rate, double f, double q, boolean high) {
        double w = 2 * Math.PI * f / rate, cs = Math.cos(w), al = Math.sin(w) / (2 * q), a0 = 1 + al;
        double b0 = high ? (1 + cs) / 2 : (1 - cs) / 2, b1 = high ? -(1 + cs) : 1 - cs;
        return new double[]{b0 / a0, b1 / a0, b0 / a0, -2 * cs / a0, (1 - al) / a0};
    }

    private static double[] peak(int rate, double f, double q, double db) {
        double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / rate, al = Math.sin(w) / (2 * q), cs = Math.cos(w);
        double a0 = 1 + al / A;
        return new double[]{(1 + al * A) / a0, -2 * cs / a0, (1 - al * A) / a0, -2 * cs / a0, (1 - al / A) / a0};
    }

    // =========================================================== odtwarzanie

    /** Odtwarza assets/<nazwa>.mp3 albo .wav, jeśli jest. */
    private boolean playAsset(String name) {
        for (String ext : new String[]{".mp3", ".wav", ".ogg", ".m4a"}) {
            try {
                AssetFileDescriptor fd = ctx.getAssets().openFd(name + ext);
                main.post(() -> {
                    try {
                        if (mp != null) mp.release();
                        mp = new MediaPlayer();
                        mp.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ALARM)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                        mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
                        fd.close();
                        mp.prepare();
                        mp.start();
                    } catch (Exception ignored) { }
                });
                return true;
            } catch (Exception ignored) { }
        }
        return false;
    }

    // Jeden stały odtwarzacz (44,1 kHz) z kolejką: nic się nie nakłada, a na początek idzie chwila ciszy,
    // żeby telefon "obudził" głośnik i nie zjadł początku krótkiego piknięcia.
    private final java.util.concurrent.LinkedBlockingQueue<short[]> queue = new java.util.concurrent.LinkedBlockingQueue<>();
    private Thread player;

    private synchronized void playPcm(short[] p, int rate) {
        if (rate != SR) p = resample(p, rate / (float) SR);   // wszystko w 44,1 kHz – bez zmiany wysokości
        queue.offer(p);
        if (player == null || !player.isAlive()) {
            player = new Thread(this::playerLoop, "snd");
            player.start();
        }
    }

    private void playerLoop() {
        AudioTrack t = null;
        try {
            int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(SR)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(Math.max(min, SR / 5)).build();
            short[] warm = new short[SR / 8];        // 125 ms ciszy na rozgrzanie
            boolean playing = false;
            long idleSince = System.currentTimeMillis();
            while (true) {
                short[] p = queue.poll(250, java.util.concurrent.TimeUnit.MILLISECONDS);
                if (p == null) {
                    if (playing && System.currentTimeMillis() - idleSince > 4000) {
                        t.write(new short[SR / 10], 0, SR / 10);
                        t.stop();
                        playing = false;
                    }
                    if (!playing && System.currentTimeMillis() - idleSince > 30_000) break;
                    continue;
                }
                if (!playing) {
                    t.play();
                    t.write(warm, 0, warm.length);
                    playing = true;
                }
                t.write(p, 0, p.length);
                idleSince = System.currentTimeMillis();
            }
        } catch (Exception ignored) {
        } finally {
            if (t != null) {
                try { t.stop(); } catch (Exception ignored) { }
                t.release();
            }
        }
    }

    private void vibrate(long[] p) {
        try {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(p, -1));
        } catch (Exception ignored) { }
    }

    void release() {
        // singleton – zostaje na cały czas działania aplikacji
    }
}
