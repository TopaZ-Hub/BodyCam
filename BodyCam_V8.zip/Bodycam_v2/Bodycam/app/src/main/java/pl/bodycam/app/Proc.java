package pl.bodycam.app;

/**
 * Obróbka klatki NV21 -> ARGB.
 *  DZIEŃ  – zwykła konwersja kolorów.
 *  NOC    – uśrednianie w czasie (mniej szumu), automatyczne podbicie jasności krzywą tonalną
 *           bez przepalania świateł, przygaszony szum kolorów, lekki zielony odcień.
 *  NOKTO  – to samo mocniej + obraz monochromatyczny w odcieniu zieleni (ilość zieleni z ustawień).
 */
final class Proc {

    static final int DAY = 0, NIGHT = 1, NV = 2;

    int w, h;
    int[] out;
    private int[] acc;      // uśredniona jasność, stałoprzecinkowo (<<4)
    private int[] tmp;      // do wygładzania w trybie NOKTO
    private final int[] lut = new int[256];
    private final int[] hist = new int[256];
    private final int[] clip = new int[1024];
    private boolean accValid = false;
    private int lastMode = -1;

    /** Średnia jasność surowej klatki (0..255) – do trybu AUTO. */
    volatile float rawMean = 128;
    /** Ile zieleni 0..1, korekta jasności -2..+2 EV. */
    volatile float green = 0.4f, ev = 0f;

    Proc() {
        for (int i = 0; i < 1024; i++) clip[i] = Math.max(0, Math.min(255, i - 384));
    }

    void run(byte[] nv, int w, int h, int mode) {
        if (out == null || this.w != w || this.h != h) {
            this.w = w;
            this.h = h;
            out = new int[w * h];
            acc = new int[w * h];
            tmp = new int[w * h];
            accValid = false;
        }
        if (mode != lastMode) accValid = false;
        lastMode = mode;
        measure(nv);
        if (mode == DAY) day(nv);
        else dark(nv, mode == NV);
    }

    private void measure(byte[] nv) {
        long s = 0;
        int n = 0;
        for (int y = 0; y < h; y += 8) {
            int r = y * w;
            for (int x = 0; x < w; x += 8) {
                s += nv[r + x] & 0xFF;
                n++;
            }
        }
        rawMean = n == 0 ? 0 : (float) s / n;
    }

    private void day(byte[] nv) {
        final int[] o = out, cl = clip;
        final int W = w, H = h, uvBase = w * h;
        for (int y = 0; y < H; y++) {
            int yi = y * W, uvi = uvBase + (y >> 1) * W;
            for (int x = 0; x < W; x += 2) {
                int vv = (nv[uvi + x] & 0xFF) - 128, uu = (nv[uvi + x + 1] & 0xFF) - 128;
                int rd = (359 * vv) >> 8, gd = (88 * uu + 183 * vv) >> 8, bd = (454 * uu) >> 8;
                int y0 = nv[yi + x] & 0xFF, y1 = nv[yi + x + 1] & 0xFF;
                o[yi + x] = 0xFF000000 | cl[y0 + rd + 384] << 16 | cl[y0 - gd + 384] << 8 | cl[y0 + bd + 384];
                o[yi + x + 1] = 0xFF000000 | cl[y1 + rd + 384] << 16 | cl[y1 - gd + 384] << 8 | cl[y1 + bd + 384];
            }
        }
    }

    private void dark(byte[] nv, boolean mono) {
        final int N = w * h;
        final int[] a = acc;
        // 1) uśrednianie w czasie z wykrywaniem ruchu (ruch = bierzemy nową klatkę, bez smug)
        int keep = mono ? 166 : 140;       // ile starej klatki zostaje (/256)
        int thr = (mono ? 30 : 24) << 4;
        if (!accValid) {
            for (int i = 0; i < N; i++) a[i] = (nv[i] & 0xFF) << 4;
            accValid = true;
        } else {
            for (int i = 0; i < N; i++) {
                int y = (nv[i] & 0xFF) << 4, d = y - a[i];
                if (d > thr || d < -thr) a[i] = y;
                else a[i] = y + (((a[i] - y) * keep) >> 8);
            }
        }
        // 2) histogram -> punkt czerni i krzywa jasności
        java.util.Arrays.fill(hist, 0);
        int cnt = 0;
        for (int i = 0; i < N; i += 7) {
            hist[a[i] >> 4]++;
            cnt++;
        }
        int bp = 0, run = 0, lim = cnt / 200;
        while (bp < 200 && run + hist[bp] <= lim) run += hist[bp++];
        float target = (mono ? 112f : 98f) * (float) Math.pow(2, ev * 0.5);
        target = Math.max(40, Math.min(175, target));
        float maxA = mono ? 26f : 14f;
        float aLo = 0.01f, aHi = maxA;
        for (int it = 0; it < 18; it++) {
            float am = (aLo + aHi) * 0.5f;
            if (meanWith(am, bp, cnt) < target) aLo = am;
            else aHi = am;
        }
        fillLut((aLo + aHi) * 0.5f, bp);
        // 3) wyjście
        final int[] o = out, cl = clip, L = lut;
        final int W = w, H = h, uvBase = W * H;
        float g = Math.max(0, Math.min(1, green));
        if (mono) {
            // wygładzenie [1 2 1] poziomo + pionowo (mniej "piasku")
            final int[] t = tmp;
            for (int y = 0; y < H; y++) {
                int r = y * W;
                t[r] = L[a[r] >> 4];
                for (int x = 1; x < W - 1; x++)
                    t[r + x] = (L[a[r + x - 1] >> 4] + 2 * L[a[r + x] >> 4] + L[a[r + x + 1] >> 4]) >> 2;
                t[r + W - 1] = L[a[r + W - 1] >> 4];
            }
            int rm = (int) (256 * (1 - 0.6f * g)), bm = (int) (256 * (1 - 0.5f * g));
            int gm = (int) (256 * (1 + 0.04f * g));
            for (int y = 0; y < H; y++) {
                int r = y * W, up = y > 0 ? r - W : r, dn = y < H - 1 ? r + W : r;
                for (int x = 0; x < W; x++) {
                    int v = (t[up + x] + 2 * t[r + x] + t[dn + x]) >> 2;
                    o[r + x] = 0xFF000000 | cl[((v * rm) >> 8) + 384] << 16 | cl[((v * gm) >> 8) + 384] << 8 | cl[((v * bm) >> 8) + 384];
                }
            }
        } else {
            int rm = (int) (256 * (1 - 0.35f * g)), bm = (int) (256 * (1 - 0.42f * g));
            for (int y = 0; y < H; y++) {
                int yi = y * W, uvi = uvBase + (y >> 1) * W;
                for (int x = 0; x < W; x++) {
                    int raw = a[yi + x] >> 4, v = L[raw];
                    // nasycenie rośnie razem z jasnością, ale przygaszone (szum kolorów w ciemności)
                    int ratio = Math.min(3 << 8, (v << 8) / Math.max(raw, 6));
                    int cs = (ratio * 140) >> 8; // /256 = siła koloru
                    int xx = x & ~1;
                    int vv = (((nv[uvi + xx] & 0xFF) - 128) * cs) >> 8, uu = (((nv[uvi + xx + 1] & 0xFF) - 128) * cs) >> 8;
                    int rr = cl[v + ((359 * vv) >> 8) + 384], gg = cl[v - ((88 * uu + 183 * vv) >> 8) + 384], bb = cl[v + ((454 * uu) >> 8) + 384];
                    o[yi + x] = 0xFF000000 | ((rr * rm) >> 8) << 16 | gg << 8 | ((bb * bm) >> 8);
                }
            }
        }
    }

    private float meanWith(float a, int bp, int cnt) {
        double norm = 1 - Math.exp(-a), s = 0;
        float span = Math.max(1, 255 - bp);
        for (int v = 0; v < 256; v++) {
            if (hist[v] == 0) continue;
            float x = Math.max(0, v - bp) / span;
            s += hist[v] * 255 * (1 - Math.exp(-a * x)) / norm;
        }
        return (float) (s / Math.max(1, cnt));
    }

    private void fillLut(float a, int bp) {
        double norm = 1 - Math.exp(-a);
        float span = Math.max(1, 255 - bp);
        for (int v = 0; v < 256; v++) {
            float x = Math.min(1, Math.max(0, v - bp) / span);
            lut[v] = (int) Math.round(255 * (1 - Math.exp(-a * x)) / norm);
        }
    }

    /** Współczynnik wzmocnienia w cieniach (do podglądu w UI). */
    float shadowGain() {
        return lut[Math.min(255, 20)] / 20f;
    }
}
